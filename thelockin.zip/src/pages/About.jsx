import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, ShieldCheck } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-background text-foreground px-5 py-8">
      <div className="max-w-lg mx-auto space-y-8">
        <header className="flex items-center justify-between gap-4">
          <Link to="/" className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4" /> Home
          </Link>
          <Link to="/contact" className="text-sm font-semibold text-primary hover:text-primary/80">Contact</Link>
        </header>

        <main className="rounded-[28px] border border-border bg-card/90 p-6 shadow-lg shadow-black/10 space-y-5">
          <div className="w-12 h-12 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div className="space-y-3">
            <p className="premium-label">About Lockin</p>
            <h1 className="text-3xl font-heading font-bold tracking-[-0.04em]">About</h1>
          </div>
          <div className="space-y-4 text-sm leading-7 text-muted-foreground">
            <p>
              Lockin is a focused self-control app built to help people follow through on the version of themselves they already planned to become. Instead of acting like a generic habit tracker, Lockin helps users create clear focus sessions, block distracting apps, schedule recurring commitments, and stay accountable through supportive circles. The app is designed for students, professionals, creators, athletes, and anyone who wants fewer impulsive digital detours during the moments that matter most.
            </p>
            <p>
              The experience is mobile-first, fast, and intentionally simple. Users can start a quick Lockin, plan weekly sessions, choose what apps to block, review progress, and invite trusted friends into shared accountability without turning productivity into punishment. Lockin is built by an independent product team focused on thoughtful software, behavioral design, privacy-conscious accountability, and premium user experience. Our goal is to make digital discipline feel less like restriction and more like investing in your future self, one completed session at a time.
            </p>
          </div>
        </main>

        <footer className="flex items-center justify-center gap-5 text-xs text-muted-foreground pb-4">
          <Link to="/about" className="font-semibold text-foreground">About</Link>
          <Link to="/contact" className="hover:text-foreground">Contact</Link>
        </footer>
      </div>
    </div>
  );
}