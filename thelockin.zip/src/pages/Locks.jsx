import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useLocation } from "react-router-dom";
import { formatDuration } from "@/lib/freedomLockData";
import { Lock, Unlock, Trash2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";

const SEVERITY_OPTIONS = [
  { value: "just_lock_me_in", label: "Just Lock Me In" },
  { value: "stay_focused", label: "Stay Focused" },
  { value: "no_excuses", label: "No Excuses" },
  { value: "beast_mode", label: "Beast Mode" },
  { value: "nuclear", label: "Nuclear" },
];

function formatSeverity(value) {
  return SEVERITY_OPTIONS.find(option => option.value === value)?.label || value?.replaceAll("_", " ") || "Standard";
}

function getSessionDate(lock) {
  return new Date(lock.locked_at || lock.created_date);
}

function isActiveLock(lock) {
  return lock.status === "active" && new Date(lock.unlocks_at) > new Date();
}

function isCompletedLock(lock) {
  return lock.status === "completed" || (lock.status === "active" && new Date(lock.unlocks_at) <= new Date());
}

function isBrokenLock(lock) {
  return lock.status === "emergency_unlocked";
}

function matchesHistoryFilters(lock, filters) {
  const sessionDate = getSessionDate(lock);
  if (filters.startDate && sessionDate < new Date(`${filters.startDate}T00:00:00`)) return false;
  if (filters.endDate && sessionDate > new Date(`${filters.endDate}T23:59:59`)) return false;
  if (filters.severity !== "all" && lock.severity_level !== filters.severity) return false;
  return true;
}

function sortSessions(items, sortBy) {
  return [...items].sort((a, b) => {
    if (sortBy === "oldest") return getSessionDate(a) - getSessionDate(b);
    if (sortBy === "longest") return (b.duration_minutes || 0) - (a.duration_minutes || 0);
    if (sortBy === "shortest") return (a.duration_minutes || 0) - (b.duration_minutes || 0);
    return getSessionDate(b) - getSessionDate(a);
  });
}

export default function Locks() {
  const location = useLocation();
  const [locks, setLocks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [severity, setSeverity] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const { toast } = useToast();

  const fetchLocks = async () => {
    const data = await base44.entities.AppLock.list("-created_date", 200);
    setLocks(data);
    setLoading(false);
  };

  useEffect(() => {
    if (location.pathname === "/locks") fetchLocks();
  }, [location.pathname]);

  const handleArchive = async (id) => {
    await base44.entities.AppLock.update(id, { archived_at: new Date().toISOString() });
    toast({ title: "Session hidden", description: "The record was kept safely in the background." });
    fetchLocks();
  };

  const filters = useMemo(() => ({ startDate, endDate, severity }), [startDate, endDate, severity]);
  const hasFilters = startDate || endDate || severity !== "all";

  const visibleLocks = useMemo(() => locks.filter(lock => !lock.archived_at), [locks]);
  const active = useMemo(() => sortSessions(visibleLocks.filter(isActiveLock), sortBy), [visibleLocks, sortBy]);
  const completed = useMemo(() => sortSessions(
    visibleLocks.filter(isCompletedLock).filter(lock => matchesHistoryFilters(lock, filters)),
    sortBy
  ), [visibleLocks, filters, sortBy]);
  const broken = useMemo(() => sortSessions(
    visibleLocks.filter(isBrokenLock).filter(lock => matchesHistoryFilters(lock, filters)),
    sortBy
  ), [visibleLocks, filters, sortBy]);

  const clearFilters = () => {
    setStartDate("");
    setEndDate("");
    setSeverity("all");
    setSortBy("newest");
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-6 space-y-6">
      <div>
        <h1 className="font-heading font-bold text-xl text-foreground">Lock History</h1>
        <p className="text-sm text-muted-foreground">{visibleLocks.length} total sessions</p>
      </div>

      <div className="rounded-2xl bg-card border border-border p-4 space-y-3">
        <p className="text-xs text-muted-foreground">Filters apply to done and broken sessions.</p>
        <div className="grid grid-cols-2 gap-3">
          <label className="space-y-1.5">
            <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-widest">From</span>
            <input
              type="date"
              value={startDate}
              onChange={e => setStartDate(e.target.value)}
              className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm text-foreground"
            />
          </label>
          <label className="space-y-1.5">
            <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-widest">To</span>
            <input
              type="date"
              value={endDate}
              onChange={e => setEndDate(e.target.value)}
              className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm text-foreground"
            />
          </label>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <label className="space-y-1.5">
            <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-widest">Severity</span>
            <select
              value={severity}
              onChange={e => setSeverity(e.target.value)}
              className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm text-foreground"
            >
              <option value="all">All levels</option>
              {SEVERITY_OPTIONS.map(option => (
                <option key={option.value} value={option.value}>{option.label}</option>
              ))}
            </select>
          </label>
          <label className="space-y-1.5">
            <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-widest">Sort</span>
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value)}
              className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm text-foreground"
            >
              <option value="newest">Newest first</option>
              <option value="oldest">Oldest first</option>
              <option value="longest">Longest first</option>
              <option value="shortest">Shortest first</option>
            </select>
          </label>
        </div>

        {hasFilters && (
          <button onClick={clearFilters} className="text-xs font-semibold text-primary">
            Clear filters
          </button>
        )}
      </div>

      <Tabs defaultValue="active">
        <TabsList className="w-full">
          <TabsTrigger value="active" className="flex-1">Active ({active.length})</TabsTrigger>
          <TabsTrigger value="completed" className="flex-1">Done ({completed.length})</TabsTrigger>
          <TabsTrigger value="broken" className="flex-1">Broken ({broken.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-2 mt-4">
          {active.length === 0 && <EmptyState text="No active locks right now." />}
          {active.map(lock => <LockRow key={lock.id} lock={lock} icon={<Lock className="w-4 h-4 text-primary" />} />)}
        </TabsContent>

        <TabsContent value="completed" className="space-y-2 mt-4">
          {completed.length === 0 && <EmptyState text={hasFilters ? "No completed sessions match these filters." : "No completed sessions yet."} />}
          {completed.map(lock => (
            <LockRow
              key={lock.id}
              lock={lock}
              icon={<Unlock className="w-4 h-4 text-accent" />}
            />
          ))}
        </TabsContent>

        <TabsContent value="broken" className="space-y-2 mt-4">
          {broken.length === 0 && <EmptyState text={hasFilters ? "No broken sessions match these filters." : "No broken sessions yet."} />}
          {broken.map(lock => (
            <LockRow
              key={lock.id}
              lock={lock}
              icon={<Unlock className="w-4 h-4 text-destructive" />}
              onDelete={() => handleArchive(lock.id)}
            />
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function LockRow({ lock, icon, onDelete }) {
  const broken = isBrokenLock(lock);

  return (
    <div className="flex items-center gap-3 rounded-xl bg-card border border-border p-3">
      <span className="text-lg">{lock.app_icon || "📱"}</span>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-medium text-sm text-foreground truncate">{lock.app_name}</span>
          {icon}
          {broken && <span className="text-[10px] font-semibold text-destructive bg-destructive/10 px-1.5 py-0.5 rounded-full">Broken</span>}
        </div>
        {lock.goal_name && <p className="text-xs text-foreground/80 truncate">{lock.goal_name}</p>}
        <p className="text-xs text-muted-foreground">
          {formatDuration(lock.duration_minutes)} · {getSessionDate(lock).toLocaleDateString("en", { month: "short", day: "numeric", year: "numeric" })} · {formatSeverity(lock.severity_level)}
        </p>
      </div>
      {onDelete && (
        <button onClick={onDelete} className="text-muted-foreground hover:text-destructive transition-colors p-1" aria-label="Hide session">
          <Trash2 className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}

function EmptyState({ text }) {
  return (
    <div className="text-center py-10">
      <p className="text-sm text-muted-foreground">{text}</p>
    </div>
  );
}