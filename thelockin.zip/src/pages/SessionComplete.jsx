import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Clock, Shield, Flame, CheckCircle2, RotateCcw } from "lucide-react";
import { motion } from "framer-motion";
import { calculateStreak, formatDuration } from "@/lib/freedomLockData";
import { fireConfetti } from "@/components/Celebration";
import AnimatedCheckmark from "@/components/AnimatedCheckmark";
import { circleAction } from "@/lib/circlesApi";
import { lockinFriendsAction } from "@/lib/lockinFriendsApi";

export default function SessionComplete() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [locks, setLocks] = useState([]);
  const [allLocks, setAllLocks] = useState([]);
  const [selectedOutcome, setSelectedOutcome] = useState(null);
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  const sessionId = searchParams.get("session");

  useEffect(() => {
    base44.entities.AppLock.list("-created_date", 200).then(async all => {
      setAllLocks(all);
      let sessionLocks = [];
      if (sessionId) {
        const anchor = all.find(l => l.id === sessionId);
        if (anchor) {
          const sameSession = all.filter(l =>
            l.goal_name === anchor.goal_name &&
            Math.abs(new Date(l.locked_at) - new Date(anchor.locked_at)) < 60000
          );
          sessionLocks = sameSession.length > 0 ? sameSession : [anchor];
        }
      } else {
        const expired = all.filter(l => l.status === "active" && new Date(l.unlocks_at) <= new Date());
        sessionLocks = expired.slice(0, 3);
      }
      setLocks(sessionLocks);
      const toComplete = sessionLocks.filter(l => l.status === "active");
      if (toComplete.length > 0) {
        await Promise.all(toComplete.map(l => base44.entities.AppLock.update(l.id, { status: "completed" })));
        if (navigator.vibrate) navigator.vibrate([30, 25, 60]);
        fireConfetti();
      }
    });
  }, [sessionId]);

  const primaryLock = locks[0];
  const totalMinutes = locks.reduce((s, l) => s + (l.duration_minutes || 0), 0);
  const streak = calculateStreak(allLocks);

  // Today's completed goals (excluding current session)
  const todayCompleted = useMemo(() => {
    const today = new Date().toDateString();
    return allLocks.filter(l =>
      l.status === "completed" &&
      new Date(l.locked_at).toDateString() === today &&
      l.goal_outcome === "yes" &&
      !locks.find(cl => cl.id === l.id)
    );
  }, [allLocks, locks]);

  const handleOutcome = async (outcome) => {
    setSelectedOutcome(outcome);
    setSaving(true);
    await Promise.all(
      locks.map(l => base44.entities.AppLock.update(l.id, { goal_outcome: outcome }))
    );
    if (outcome === "yes" && primaryLock) {
      await circleAction("shareLockinCompleted", { lockId: primaryLock.id, lock_session_key: primaryLock.lock_session_key, shared_lockin_id: primaryLock.shared_lockin_id, template_name: primaryLock.lockin_category || "Lockin", focus: primaryLock.goal_name, duration_minutes: primaryLock.duration_minutes, started_at: primaryLock.locked_at, unlocks_at: primaryLock.unlocks_at, goal_outcome: outcome });
      await lockinFriendsAction("notifyCompleted", { lockSessionKey: primaryLock.lock_session_key, scheduleId: primaryLock.schedule_id, goalName: primaryLock.goal_name }).catch(() => null);
      if (primaryLock.shared_lockin_id) await circleAction("completeSharedLockinParticipant", { sharedLockinId: primaryLock.shared_lockin_id, lock_session_key: primaryLock.lock_session_key, focus: primaryLock.goal_name }).catch(() => null);
    }
    setSaving(false);
    setDone(true);
    if (outcome === "yes" && navigator.vibrate) navigator.vibrate([30, 25, 60]);
  };

  if (!primaryLock) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto px-5 py-12 min-h-screen flex flex-col items-center justify-center space-y-8">

      {/* Celebration header */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="text-center space-y-4"
      >
        {done && selectedOutcome === "yes" ? (
          <AnimatedCheckmark size={80} delay={0.1} />
        ) : done ? (
          <div className="text-5xl">🌿</div>
        ) : (
          <AnimatedCheckmark size={80} delay={0.15} />
        )}
        <div className="space-y-1">
          <h1 className="font-heading font-bold text-3xl text-foreground">
            {done
              ? selectedOutcome === "yes"
                ? "Session Complete"
                : "You showed up today."
              : "Session Complete"}
          </h1>
          {done && selectedOutcome === "yes" ? (
            <p className="text-muted-foreground text-sm">
              Nice work. You completed your {primaryLock.goal_name || "Focus"} Lockin.
            </p>
          ) : !done ? (
            <p className="text-muted-foreground text-sm">
              You completed your {primaryLock.goal_name || "Focus"} Lockin.
            </p>
          ) : null}
        </div>
      </motion.div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 w-full">
        <div className="rounded-2xl bg-card border border-border p-4 text-center">
          <Clock className="w-5 h-5 text-primary mx-auto mb-2" />
          <p className="font-heading font-bold text-lg text-foreground">{formatDuration(totalMinutes)}</p>
          <p className="text-[11px] text-muted-foreground">Reclaimed</p>
        </div>
        <div className="rounded-2xl bg-card border border-border p-4 text-center">
          <Shield className="w-5 h-5 text-accent mx-auto mb-2" />
          <p className="font-heading font-bold text-lg text-foreground">{locks.length}</p>
          <p className="text-[11px] text-muted-foreground">App{locks.length > 1 ? "s" : ""} resisted</p>
        </div>
        <div className="rounded-2xl bg-card border border-border p-4 text-center">
          <Flame className="w-5 h-5 text-amber-500 mx-auto mb-2" />
          <p className="font-heading font-bold text-lg text-foreground">{streak}</p>
          <p className="text-[11px] text-muted-foreground">Day streak</p>
        </div>
      </div>

      {/* Goal check or completion */}
      {!done ? (
        <div className="w-full space-y-4">
          <p className="text-center font-semibold text-foreground">
            Did you complete what you planned?
          </p>
          <div className="grid grid-cols-2 gap-3">
            <motion.button
              whileTap={{ scale: 0.96 }}
              onClick={() => handleOutcome("yes")}
              disabled={saving}
              className="flex flex-col items-center gap-2 rounded-2xl border border-primary/30 bg-primary/5 p-5 text-center active:scale-[0.96] transition-all"
            >
              <CheckCircle2 className="w-7 h-7 text-primary" />
              <span className="text-sm font-semibold text-primary">Complete</span>
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.96 }}
              onClick={() => handleOutcome("not_quite")}
              disabled={saving}
              className="flex flex-col items-center gap-2 rounded-2xl border border-border bg-card p-5 text-center active:scale-[0.96] transition-all"
            >
              <span className="w-7 h-7 rounded-full border-2 border-muted-foreground/40 flex items-center justify-center">
                <span className="text-xs text-muted-foreground">—</span>
              </span>
              <span className="text-sm font-semibold text-foreground">Not Complete</span>
            </motion.button>
          </div>
          <button onClick={() => navigate("/")} className="w-full text-center text-sm text-muted-foreground hover:text-foreground transition-colors pt-2">
            Skip for now
          </button>
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full space-y-4"
        >
          {selectedOutcome === "yes" ? (
            <>
              {/* Today's wins */}
              {todayCompleted.length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-2">Today's Wins</p>
                  <div className="space-y-2">
                    {todayCompleted.map((l, i) => (
                      <div key={i} className="rounded-2xl bg-card border border-border p-3 flex items-center gap-2">
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ delay: i * 0.1, type: "spring", stiffness: 400, damping: 20 }}
                          className="w-5 h-5 rounded-full bg-primary flex items-center justify-center"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5 text-primary-foreground" strokeWidth={3} />
                        </motion.div>
                        <span className="text-sm font-medium text-foreground">
                          {l.goal_emoji} {l.goal_name}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              <Button
                onClick={() => navigate("/")}
                className="w-full rounded-2xl h-13 font-bold text-base py-3 shadow-md shadow-primary/20"
              >
               Continue
              </Button>
            </>
          ) : (
            <div className="w-full space-y-4">
              <div className="rounded-2xl bg-muted/50 border border-border px-6 py-5 text-center">
                <p className="text-sm text-muted-foreground">No worries. Want to give it another shot?</p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="outline"
                  onClick={() => navigate("/lockin-setup")}
                  className="rounded-2xl h-12 font-semibold"
                >
                  <RotateCcw className="w-4 h-4 mr-1" /> Try Again
                </Button>
                <Button
                  onClick={() => navigate("/")}
                  className="rounded-2xl h-12 font-semibold"
                >
                  Skip Today
                </Button>
              </div>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
}