import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UserPlus, Mail, Lock, Loader2, User, AtSign } from "lucide-react";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import AuthLayout from "@/components/AuthLayout";
import GoogleIcon from "@/components/GoogleIcon";
import { toast } from "@/components/ui/use-toast";
import { circleAction } from "@/lib/circlesApi";

export default function Register() {
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [usernameStatus, setUsernameStatus] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showOtp, setShowOtp] = useState(false);
  const [otpCode, setOtpCode] = useState("");

  useEffect(() => {
    if (username.length < 3) { setUsernameStatus(null); return; }
    const id = setTimeout(async () => {
      try { setUsernameStatus(await circleAction("checkUsernameAvailability", { username })); }
      catch { setUsernameStatus(null); }
    }, 350);
    return () => clearTimeout(id);
  }, [username]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (!name.trim()) return setError("Name is required");
    if (!usernameStatus?.available) return setError(usernameStatus?.reason || "Choose an available username");
    if (password !== confirmPassword) return setError("Passwords do not match");
    setLoading(true);
    try {
      await base44.auth.register({ email, password });
      setShowOtp(true);
    } catch (err) {
      setError(err.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    setError("");
    setLoading(true);
    try {
      const result = await base44.auth.verifyOtp({ email, otpCode });
      if (result?.access_token) base44.auth.setToken(result.access_token);
      await circleAction("updateUsername", { username, name });
      window.location.href = "/onboarding";
    } catch (err) {
      setError(err.message || "Invalid verification code");
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    setError("");
    try {
      await base44.auth.resendOtp(email);
      toast({ title: "Code sent", description: "Check your email for the new code." });
    } catch (err) {
      setError(err.message || "Failed to resend code");
    }
  };

  const handleGoogle = () => base44.auth.loginWithProvider("google", "/onboarding");
  const handleUsername = (value) => setUsername(value.toLowerCase().replace(/^@/, "").replace(/[^a-z0-9._]/g, "").slice(0, 20));

  if (showOtp) {
    return (
      <AuthLayout icon={Mail} title="Verify your email" subtitle={`We sent a code to ${email}`}>
        {error && <div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">{error}</div>}
        <div className="flex justify-center mb-6">
          <InputOTP maxLength={6} value={otpCode} onChange={setOtpCode} autoFocus autoComplete="one-time-code">
            <InputOTPGroup>{[0, 1, 2, 3, 4, 5].map(i => <InputOTPSlot key={i} index={i} />)}</InputOTPGroup>
          </InputOTP>
        </div>
        <Button className="w-full h-12 font-medium" onClick={handleVerify} disabled={loading || otpCode.length < 6}>{loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Verifying...</> : "Verify"}</Button>
        <p className="text-center text-sm text-muted-foreground mt-4">Didn't receive the code? <button onClick={handleResend} className="text-primary font-medium hover:underline">Resend</button></p>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout icon={UserPlus} title="Create your account" subtitle="Choose your Lockin identity" footer={<>Already have an account? <Link to="/login" className="text-primary font-medium hover:underline">Log in</Link></>}>
      <Button variant="outline" className="w-full h-12 text-sm font-medium mb-6" onClick={handleGoogle}><GoogleIcon className="w-5 h-5 mr-2" />Continue with Google</Button>
      <div className="relative mb-6"><div className="absolute inset-0 flex items-center"><div className="w-full border-t border-border" /></div><div className="relative flex justify-center text-xs uppercase"><span className="bg-card px-3 text-muted-foreground">or</span></div></div>
      {error && <div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">{error}</div>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <Field label="Name" id="name" icon={User}><Input id="name" autoComplete="name" autoFocus placeholder="James McQuay" value={name} onChange={e => setName(e.target.value)} className="pl-10 h-12" required /></Field>
        <div className="space-y-2">
          <Label htmlFor="username">Username</Label>
          <div className="relative"><AtSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><Input id="username" autoComplete="username" placeholder="jameslocks" value={username} onChange={e => handleUsername(e.target.value)} className="pl-10 h-12" required /></div>
          {usernameStatus && <p className={`text-xs ${usernameStatus.available ? "text-success" : "text-destructive"}`}>{usernameStatus.available ? "Username available." : usernameStatus.reason || "That username is already taken."}</p>}
          {usernameStatus?.suggestions?.length > 0 && <div className="flex flex-wrap gap-2">{usernameStatus.suggestions.map(s => <button type="button" key={s} onClick={() => handleUsername(s)} className="rounded-full bg-muted px-3 py-1 text-xs text-foreground">@{s}</button>)}</div>}
        </div>
        <Field label="Email" id="email" icon={Mail}><Input id="email" type="email" autoComplete="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} className="pl-10 h-12" required /></Field>
        <Field label="Password" id="password" icon={Lock}><Input id="password" type="password" autoComplete="new-password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} className="pl-10 h-12" required /></Field>
        <Field label="Confirm Password" id="confirm" icon={Lock}><Input id="confirm" type="password" autoComplete="new-password" placeholder="••••••••" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className="pl-10 h-12" required /></Field>
        <Button type="submit" className="w-full h-12 font-medium" disabled={loading || !usernameStatus?.available}>{loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Creating account...</> : "Create account"}</Button>
      </form>
    </AuthLayout>
  );
}

function Field({ label, id, icon: Icon, children }) {
  return <div className="space-y-2"><Label htmlFor={id}>{label}</Label><div className="relative"><Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />{children}</div></div>;
}