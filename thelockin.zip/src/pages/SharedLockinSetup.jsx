import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { ArrowLeft, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import DateOptionSelector from "@/components/circles/DateOptionSelector";
import TimeChoicePicker from "@/components/circles/TimeChoicePicker";
import SharedLockinReview from "@/components/circles/SharedLockinReview";
import { circleAction } from "@/lib/circlesApi";

const TYPES = ["Homework", "Work", "Gym", "Sleep", "Custom"];
const PRESET_DURATIONS = [15, 30, 45, 60, 90, 120];
const DATE_LABELS = { today: "Today", tomorrow: "Tomorrow", weekdays: "Weekdays", weekend: "Weekend", specific: "Specific Date" };

function ymd(date) { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`; }
function partsFromDate(date) { const hours = date.getHours(); return { hour: String(hours % 12 || 12), minute: String(Math.round(date.getMinutes() / 15) * 15).padStart(2, "0").replace("60", "00"), period: hours >= 12 ? "PM" : "AM" }; }
function nextWholeHour() { const date = new Date(Date.now() + 60 * 60000); date.setMinutes(0, 0, 0); return date; }
function dateForOption(form) {
  if (form.dateOption === "tomorrow") return new Date(Date.now() + 86400000);
  if (form.dateOption === "specific") return new Date(`${form.specificDate}T12:00`);
  if (["weekdays", "weekend"].includes(form.dateOption)) {
    const target = new Set(form.selectedDays);
    for (let offset = 0; offset < 14; offset++) { const day = new Date(Date.now() + offset * 86400000); if (target.has(day.getDay())) return day; }
  }
  return new Date();
}
function combine(date, time) { let hour = Number(time.hour) % 12; if (time.period === "PM") hour += 12; return new Date(date.getFullYear(), date.getMonth(), date.getDate(), hour, Number(time.minute), 0, 0); }
function formatTime(date) { return date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }); }

export default function SharedLockinSetup() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const { toast } = useToast();
  const defaultStart = useMemo(() => params.get("start") ? new Date(params.get("start")) : nextWholeHour(), [params]);
  const defaultDuration = Number(params.get("duration") || 60);
  const defaultEnd = useMemo(() => params.get("end") ? new Date(params.get("end")) : new Date(defaultStart.getTime() + defaultDuration * 60000), [params, defaultStart, defaultDuration]);
  const [context, setContext] = useState(null);
  const [preview, setPreview] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    circleId: params.get("circleId") || "", category: TYPES.includes(params.get("category")) ? params.get("category") : "Homework", focus: params.get("focus") || "",
    dateOption: "today", specificDate: ymd(defaultStart), selectedDays: [defaultStart.getDay()], repeatMode: "one_time",
    startTime: partsFromDate(defaultStart), endTime: partsFromDate(defaultEnd), timeMode: "duration", durationMinutes: defaultDuration, customDuration: !PRESET_DURATIONS.includes(defaultDuration),
    selectedMemberIds: [], lateJoining: params.get("late") === "true"
  });

  useEffect(() => { circleAction("inviteLockinContext", { circleId: form.circleId }).then(data => { setContext(data); if (!form.circleId && data.circles?.[0]) setForm(prev => ({ ...prev, circleId: data.circles[0].id })); }).catch(e => toast({ title: e?.response?.data?.error || "Could not load circles", variant: "destructive" })); }, []);

  const baseDate = dateForOption(form);
  const start = combine(baseDate, form.startTime);
  const end = form.timeMode === "duration" ? new Date(start.getTime() + Number(form.durationMinutes || 0) * 60000) : combine(baseDate, form.endTime);
  const circle = context?.circles?.find(c => c.id === form.circleId);
  const invited = circle?.members?.filter(m => form.selectedMemberIds.includes(m.user_id)) || [];
  const title = `${form.category} Lockin`;
  const canPreview = form.circleId && form.selectedMemberIds.length > 0 && form.selectedDays.length > 0 && end > start;
  const timeLabel = `${formatTime(start)} – ${formatTime(end)}`;
  const dateLabel = DATE_LABELS[form.dateOption] || "Selected date";
  const toggleMember = id => setForm(prev => ({ ...prev, selectedMemberIds: prev.selectedMemberIds.includes(id) ? prev.selectedMemberIds.filter(x => x !== id) : [...prev.selectedMemberIds, id].slice(0, 7) }));
  const send = async () => {
    if (!canPreview) return toast({ title: "Choose a valid schedule and at least one member.", variant: "destructive" });
    setSaving(true);
    try {
      const result = await circleAction("createSharedLockin", { ...form, title, date: ymd(baseDate), startAt: start.toISOString(), endAt: end.toISOString() });
      toast({ title: "Lockin invite sent." });
      navigate(`/shared-lockin/${result.sharedLockin.id}`);
    } catch (e) { toast({ title: e?.response?.data?.error || "Could not send invite", variant: "destructive" }); } finally { setSaving(false); }
  };

  if (!context) return <div className="min-h-screen flex items-center justify-center"><div className="w-8 h-8 rounded-full border-4 border-muted border-t-primary animate-spin" /></div>;

  return <div className="max-w-lg mx-auto px-5 py-6 space-y-5">
    <button onClick={() => navigate(-1)} className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground"><ArrowLeft className="w-4 h-4" /> Back</button>
    <div><h1 className="font-heading font-bold text-2xl text-foreground">Invite to Lockin</h1><p className="text-sm text-muted-foreground">Simple shared scheduling — tap, review, send.</p></div>
    {preview ? <SharedLockinReview title={title} form={form} circle={circle} invited={invited} timeLabel={timeLabel} dateLabel={dateLabel} saving={saving} onEdit={() => setPreview(false)} onSend={send} /> : <div className="space-y-4">
      <section className="rounded-3xl border border-border bg-card p-4 space-y-3"><p className="text-xs font-semibold uppercase tracking-widest text-primary">1. Choose template</p><div className="grid grid-cols-3 gap-2">{TYPES.map(type => <button key={type} onClick={() => setForm(prev => ({ ...prev, category: type }))} className={`rounded-2xl px-3 py-3 text-sm font-semibold ${form.category === type ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>{type}</button>)}</div></section>
      <section className="rounded-3xl border border-border bg-card p-4 space-y-3"><p className="text-xs font-semibold uppercase tracking-widest text-primary">2. Optional goal</p><Input value={form.focus} onChange={e => setForm(prev => ({ ...prev, focus: e.target.value }))} placeholder="Finish SQL Assignment" className="rounded-2xl" /></section>
      <DateOptionSelector form={form} setForm={setForm} />
      <TimeChoicePicker form={form} setForm={setForm} />
      <section className="rounded-3xl border border-border bg-card p-4 space-y-3"><p className="text-xs font-semibold uppercase tracking-widest text-primary">7. Choose Circle</p><select value={form.circleId} onChange={e => setForm(prev => ({ ...prev, circleId: e.target.value, selectedMemberIds: [] }))} className="w-full rounded-2xl border border-input bg-background px-3 py-3 text-sm text-foreground">{context.circles.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></section>
      <section className="rounded-3xl border border-border bg-card p-4 space-y-3"><p className="text-xs font-semibold uppercase tracking-widest text-primary">8. Choose members</p>{circle?.members?.length ? circle.members.map(m => <button key={m.id} onClick={() => toggleMember(m.user_id)} className="w-full flex items-center justify-between rounded-2xl bg-muted/50 p-3 text-left"><span><span className="block text-sm font-semibold text-foreground">{m.display_name}</span><span className="block text-xs text-muted-foreground">@{m.username}</span></span>{form.selectedMemberIds.includes(m.user_id) && <Check className="w-4 h-4 text-primary" />}</button>) : <p className="text-sm text-muted-foreground">No other members yet.</p>}</section>
      <button onClick={() => setForm(prev => ({ ...prev, lateJoining: !prev.lateJoining }))} className={`w-full rounded-2xl px-4 py-3 text-sm font-semibold ${form.lateJoining ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>Late Joining: {form.lateJoining ? "Allowed" : "Not Allowed"}</button>
      <Button onClick={() => setPreview(true)} disabled={!canPreview} className="w-full rounded-2xl">Review Invite</Button>
    </div>}
  </div>;
}