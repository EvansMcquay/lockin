import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import AppSearchPicker from "@/components/AppSearchPicker";
import ScheduleIcon from "@/components/schedules/ScheduleIcon";
import ScheduleIconPicker from "@/components/schedules/ScheduleIconPicker";
import { DEFAULT_ICON_STYLE } from "@/lib/scheduleIcons";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";
import { ArrowRight, CalendarDays, Check, Sparkles } from "lucide-react";

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export default function Onboarding() {
  const navigate = useNavigate();
  const { user, checkUserAuth } = useAuth();
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [firstName, setFirstName] = useState(user?.first_name || "");
  const [lastName, setLastName] = useState(user?.last_name || "");
  const [label, setLabel] = useState("");
  const [days, setDays] = useState([1, 2, 3, 4, 5]);
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("10:00");
  const [icon, setIcon] = useState("🎯");
  const [iconStyle, setIconStyle] = useState(DEFAULT_ICON_STYLE);
  const [selectedApps, setSelectedApps] = useState([]);
  const [saving, setSaving] = useState(false);

  const toggleDay = (day) => {
    setDays(prev => prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]);
  };

  const toggleMainDistraction = (app) => {
    setSelectedApps(prev => prev.some(item => item.name === app.name) ? [] : [app]);
  };

  const saveName = async () => {
    const cleanFirst = firstName.trim();
    const cleanLast = lastName.trim();
    if (!cleanFirst) {
      toast({ title: "Add your first name", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await base44.auth.updateMe({ first_name: cleanFirst, last_name: cleanLast });
      await checkUserAuth();
      setStep(2);
    } catch {
      toast({ title: "Could not save your name", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const saveSchedule = async () => {
    if (!label.trim() || days.length === 0 || selectedApps.length === 0) {
      toast({ title: "Complete the schedule fields", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await base44.entities.RecurringSchedule.create({
        label: label.trim(),
        goal_name: label.trim(),
        goal_emoji: icon,
        icon_style: iconStyle,
        apps: selectedApps.map(app => ({ name: app.name, domain: app.domain })),
        days_of_week: days,
        start_time: startTime,
        end_time: endTime,
        reminder_enabled: true,
        is_active: true,
      });
      await base44.auth.updateMe({ onboarding_completed: true, onboarding_schedule_skipped: false });
      await checkUserAuth();
      setStep(3);
    } catch {
      toast({ title: "Could not save your schedule", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const skipSchedule = async () => {
    setSaving(true);
    try {
      await base44.auth.updateMe({ onboarding_completed: true, onboarding_schedule_skipped: true });
      await checkUserAuth();
      navigate("/");
    } catch {
      toast({ title: "Could not finish setup", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-background px-5 py-8" style={{ paddingTop: "calc(var(--safe-area-top) + 2rem)", paddingBottom: "calc(var(--safe-area-bottom) + 2rem)" }}>
      <div className="max-w-lg mx-auto space-y-6">
        <div className="flex items-center gap-2 text-primary">
          <Sparkles className="w-4 h-4" />
          <p className="text-xs font-bold uppercase tracking-[0.16em]">Setup</p>
        </div>

        {step === 1 && (
          <section className="space-y-6">
            <div>
              <h1 className="font-heading font-bold text-3xl text-foreground">What should we call you?</h1>
              <p className="text-sm text-muted-foreground mt-2">We'll use your first name to make Lockin feel personal.</p>
            </div>
            <div className="rounded-3xl bg-card border border-border p-4 space-y-4">
              <Input value={firstName} onChange={e => setFirstName(e.target.value)} placeholder="First name" className="h-12 rounded-2xl" autoFocus />
              <Input value={lastName} onChange={e => setLastName(e.target.value)} placeholder="Last name (optional)" className="h-12 rounded-2xl" />
            </div>
            <Button onClick={saveName} disabled={saving} className="w-full h-12 rounded-2xl font-semibold">
              {saving ? "Saving..." : "Continue"} <ArrowRight className="w-4 h-4" />
            </Button>
          </section>
        )}

        {step === 2 && (
          <section className="space-y-5">
            <div>
              <h1 className="font-heading font-bold text-3xl text-foreground">Create your first schedule</h1>
              <p className="text-sm text-muted-foreground mt-2">Plan one session you want to follow through on.</p>
            </div>

            <div className="space-y-5 rounded-3xl bg-card border border-border p-4">
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-2">Session name</p>
                <div className="flex items-center gap-2">
                  <ScheduleIcon icon={icon} styleName={iconStyle} size="sm" />
                  <Input value={label} onChange={e => setLabel(e.target.value)} placeholder="e.g. Morning study" className="h-11 rounded-2xl" />
                </div>
              </div>

              <ScheduleIconPicker value={icon} styleName={iconStyle} onIconChange={setIcon} onStyleChange={setIconStyle} />

              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-2">Days</p>
                <div className="grid grid-cols-7 gap-1.5">
                  {DAYS.map((day, index) => (
                    <button key={day} onClick={() => toggleDay(index)} className={`rounded-xl py-2.5 text-xs font-semibold active:scale-95 transition-all ${days.includes(index) ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                      {day}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-2">Time</p>
                <div className="grid grid-cols-2 gap-3">
                  <Input type="time" value={startTime} onChange={e => setStartTime(e.target.value)} className="h-12 rounded-2xl font-semibold" />
                  <Input type="time" value={endTime} onChange={e => setEndTime(e.target.value)} className="h-12 rounded-2xl font-semibold" />
                </div>
              </div>

              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-2">Main distraction to avoid</p>
                <AppSearchPicker selected={selectedApps} onToggle={toggleMainDistraction} maxHeight="220px" />
              </div>
            </div>

            <div className="space-y-2">
              <Button onClick={saveSchedule} disabled={saving || !label.trim() || days.length === 0 || selectedApps.length === 0} className="w-full h-12 rounded-2xl font-semibold">
                {saving ? "Saving..." : "Save schedule"}
              </Button>
              <button onClick={skipSchedule} disabled={saving} className="w-full h-11 rounded-2xl text-sm font-semibold text-muted-foreground">
                Skip for now
              </button>
            </div>
          </section>
        )}

        {step === 3 && (
          <section className="space-y-6 text-center">
            <div className="w-16 h-16 rounded-3xl bg-primary/10 text-primary flex items-center justify-center mx-auto">
              <Check className="w-8 h-8" />
            </div>
            <div>
              <h1 className="font-heading font-bold text-3xl text-foreground">You’re ready to lock in.</h1>
              <p className="text-sm text-muted-foreground mt-2">Your first schedule is saved to your personal workspace.</p>
            </div>
            <div className="space-y-3">
              <Button onClick={() => navigate("/lockin-setup")} className="w-full h-12 rounded-2xl font-semibold">Start Lockin</Button>
              <Button onClick={() => navigate("/schedule-builder")} variant="outline" className="w-full h-12 rounded-2xl font-semibold">
                <CalendarDays className="w-4 h-4" /> Add Another Schedule
              </Button>
              <button onClick={() => navigate("/")} className="w-full h-11 rounded-2xl text-sm font-semibold text-muted-foreground">Go to Home</button>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}