import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Ban, Crown, Flag, MoreHorizontal, Trash2, UserMinus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { circleAction } from "@/lib/circlesApi";
import AccountabilitySettings from "@/components/circles/AccountabilitySettings";
import CircleActionRow from "@/components/circles/CircleActionRow";
import CircleActivityCard from "@/components/circles/CircleActivityCard";
import CircleGoalCard from "@/components/circles/CircleGoalCard";
import CircleLivingHero from "@/components/circles/CircleLivingHero";
import CircleMoreDialog from "@/components/circles/CircleMoreDialog";
import CircleSharingSettings from "@/components/circles/CircleSharingSettings";
import CreateCircleGoalDialog from "@/components/circles/CreateCircleGoalDialog";
import InviteCircleDialog from "@/components/circles/InviteCircleDialog";
import { sharedLockinSetupUrl } from "@/lib/sharedLockinLinks";

function formatTime(iso) { return new Date(iso).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }); }
function formatDay(iso) { const date = new Date(iso); return date.toDateString() === new Date().toDateString() ? "Today" : date.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" }); }
function timeRemaining(endAt) { const ms = Math.max(0, new Date(endAt) - new Date()); const hours = Math.floor(ms / 3600000); const minutes = Math.floor((ms % 3600000) / 60000); return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`; }
function joinedCount(item) { return (item?.participants || []).filter(p => ["joined", "ready", "locked_in", "completed"].includes(p.status)).length; }
function lockedCount(item) { return (item?.participants || []).filter(p => p.status === "locked_in").length; }

export default function CircleDetail() {
  const circleId = window.location.pathname.split("/").pop();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [data, setData] = useState(null);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [profileUserId, setProfileUserId] = useState(null);
  const [goalOpen, setGoalOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [moreView, setMoreView] = useState(null);

  const load = async () => setData(await circleAction("getCircleDetail", { circleId }));
  useEffect(() => { load(); }, [circleId]);

  if (!data) return <div className="min-h-screen flex items-center justify-center"><div className="w-8 h-8 rounded-full border-4 border-muted border-t-primary animate-spin" /></div>;

  const { circle, membership, requests, activity, sharedLockins, spotlightSharedLockin, activeGoal, goalPreference, sharing, accountability, activeStatuses, positiveReactions } = data;
  const isOwner = membership.role === "owner";
  const isFull = circle.member_count >= 8;
  const profileMember = circle.members.find(m => m.user_id === profileUserId);
  const otherMembers = circle.members.filter(m => m.user_id !== membership.user_id);
  const sessions = [spotlightSharedLockin, ...(sharedLockins || [])].filter(Boolean).filter((item, index, arr) => arr.findIndex(match => match.id === item.id) === index);
  const now = new Date();
  const activeSession = sessions.find(item => item.status === "active" || (new Date(item.start_at) <= now && new Date(item.end_at) > now && !["completed", "cancelled"].includes(item.status)));
  const upcomingSession = sessions.filter(item => item.status === "scheduled" && new Date(item.start_at) > now).sort((a, b) => new Date(a.start_at) - new Date(b.start_at))[0];
  const completedSession = sessions.filter(item => item.status === "completed" && item.end_at && new Date(item.end_at).toDateString() === now.toDateString()).sort((a, b) => new Date(b.end_at) - new Date(a.end_at))[0];
  const circleState = otherMembers.length === 0 ? "empty" : activeSession ? "active" : upcomingSession ? "upcoming" : completedSession ? "completed" : "ready";

  const updateCircle = async (updates) => { setSaving(true); await circleAction("updateCircle", { circleId, ...updates }); await load(); setSaving(false); };
  const updateSharing = async (updates) => { setSaving(true); await circleAction("updateSharingPreference", { circleId, ...updates }); await load(); setSaving(false); };
  const leave = async () => { if (isOwner && circle.member_count > 1 && !window.confirm("If you leave, ownership will transfer to the longest-standing member.")) return; await circleAction("leaveCircle", { circleId }); navigate("/circles"); };
  const copyCode = async () => { await navigator.clipboard.writeText(circle.code); toast({ title: "Circle code copied" }); };
  const inviteSent = async (message = "Circle invite sent.") => { toast({ title: message }); await load(); };
  const createGoal = async (form) => { await circleAction("createCircleGoal", { circleId, ...form }); toast({ title: "Circle goal created." }); await load(); };
  const toggleGoalPrivacy = async (show) => { await circleAction("updateCircleGoalPrivacy", { circleId, show_contributions: show }); await load(); };
  const refreshActivity = (result) => setData(prev => ({ ...prev, activity: prev.activity.map(item => item.id === result.activity.id ? result.activity : item) }));
  const openMore = (view = null) => { setMoreView(view); setMoreOpen(true); };
  const startTogether = () => navigate(sharedLockinSetupUrl({ circleId }));
  const startEarly = async () => { await circleAction("startSharedLockinEarly", { sharedLockinId: upcomingSession.id }); toast({ title: "Lockin started early." }); await load(); };

  const hero = getHeroState({ circleState, circle, activeSession, upcomingSession, completedSession, joined: joinedCount, locked: lockedCount, setInviteOpen, startTogether, startEarly, toast });
  const showActionRow = ["ready", "upcoming"].includes(circleState);

  const moreItems = [
    requests?.length > 0 && { id: "requests", title: "Join Requests", content: <JoinRequests requests={requests} circleId={circleId} onChange={load} /> },
    { id: "members", title: "Members", content: <MembersPanel circle={circle} membership={membership} activeStatuses={activeStatuses} isOwner={isOwner} circleId={circleId} onProfile={setProfileUserId} onChange={load} /> },
    { id: "goal", title: "Circle Goal", content: <CircleGoalCard goal={activeGoal} isOwner={isOwner} preference={goalPreference} onCreate={() => setGoalOpen(true)} onTogglePrivacy={toggleGoalPrivacy} /> },
    { id: "activity", title: "Recent Activity", content: <ActivityPanel activity={activity} positiveReactions={positiveReactions} membership={membership} onProfile={setProfileUserId} navigate={navigate} refreshActivity={refreshActivity} load={load} toast={toast} /> },
    { id: "privacy", title: "Privacy", content: <PrivacyPanel circle={circle} onCopyCode={copyCode} /> },
    { id: "sharing", title: "Sharing", content: <CircleSharingSettings members={circle.members} currentUserId={membership.user_id} sharing={sharing} saving={saving} onSave={updateSharing} /> },
    { id: "accountability", title: "Accountability", content: <AccountabilitySettings members={circle.members} circles={[circle]} currentUserId={membership.user_id} value={accountability} onSaved={load} onError={(message) => toast({ title: message, variant: "destructive" })} /> },
    isOwner && { id: "settings", title: "Circle Settings", content: <OwnerEditor circle={circle} saving={saving} onSave={updateCircle} /> },
    { id: "leave", title: "Leave Circle", danger: true, onClick: leave },
    isOwner && { id: "delete", title: "Delete Circle", danger: true, onClick: () => window.confirm("Delete this circle for everyone?") && circleAction("deleteCircle", { circleId }).then(() => navigate("/circles")) },
  ].filter(Boolean);

  return (
    <div className="max-w-lg mx-auto px-5 py-6 space-y-4" style={{ paddingBottom: "calc(var(--safe-area-bottom) + 6rem)" }}>
      <Link to="/circles" className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground"><ArrowLeft className="w-4 h-4" /> Circles</Link>
      <CircleLivingHero circle={circle} {...hero} />

      {showActionRow && <CircleActionRow inviteDisabled={isFull} onAction={(action) => action === "invite" ? setInviteOpen(true) : action === "members" ? openMore("members") : startTogether()} />}
      {showActionRow && <button onClick={() => openMore()} className="w-full inline-flex items-center justify-center gap-2 rounded-2xl py-2 text-sm font-semibold text-muted-foreground"><MoreHorizontal className="w-4 h-4" /> More</button>}

      <InviteCircleDialog open={inviteOpen} onOpenChange={setInviteOpen} circle={circle} circleId={circleId} onSent={inviteSent} onError={(message) => toast({ title: message, variant: "destructive" })} />
      <CreateCircleGoalDialog open={goalOpen} onOpenChange={setGoalOpen} onCreate={createGoal} />
      <CircleMoreDialog open={moreOpen} onOpenChange={setMoreOpen} items={moreItems} activeId={moreView} onSelect={setMoreView} />

      <Dialog open={!!profileMember} onOpenChange={() => setProfileUserId(null)}>
        <DialogContent className="rounded-3xl">
          <DialogHeader><DialogTitle>Member Preview</DialogTitle></DialogHeader>
          {profileMember && <div className="flex items-center gap-3"><div className="w-12 h-12 rounded-full bg-primary/15 flex items-center justify-center text-lg font-bold">{(profileMember.display_name || "M").slice(0, 1).toUpperCase()}</div><div><p className="font-semibold text-foreground">{profileMember.display_name}</p><p className="text-sm text-muted-foreground">@{profileMember.username}</p><p className="text-xs text-muted-foreground mt-1">Shared Circle · {activeStatuses?.[profileMember.user_id] === "locked_in" ? "🟢 Locked In" : "⚪ Joined"}</p></div></div>}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function getHeroState({ circleState, circle, activeSession, upcomingSession, completedSession, joined, locked, setInviteOpen, startTogether, startEarly, toast }) {
  if (circleState === "empty") return { eyebrow: circle.name, title: "Your Circle is ready.", description: "Invite someone to begin locking in together.", primaryLabel: "Invite People", onPrimary: () => setInviteOpen(true) };
  if (circleState === "active") return { eyebrow: "Active Lockin", title: activeSession.title, description: `${timeRemaining(activeSession.end_at)} remaining`, summary: [{ label: "Locked In", value: locked(activeSession) }, { label: "Joined", value: joined(activeSession) }, { label: "Ends", value: formatTime(activeSession.end_at) }], primaryLabel: "Resume Session", primaryTo: `/shared-lockin/${activeSession.id}` };
  if (circleState === "upcoming") return { eyebrow: "Upcoming Lockin", title: upcomingSession.title, description: upcomingSession.focus || "Get ready to lock in together.", summary: [{ label: "Day", value: formatDay(upcomingSession.start_at) }, { label: "Time", value: formatTime(upcomingSession.start_at) }, { label: "Joined", value: joined(upcomingSession) }], primaryLabel: "Open Session", primaryTo: `/shared-lockin/${upcomingSession.id}`, secondaryLabel: upcomingSession.allow_early_start === false ? null : "Start Early", onSecondary: startEarly };
  if (circleState === "completed") return { eyebrow: "Completed", title: `${completedSession.title} Complete`, description: "Everyone followed through.", primaryLabel: "Celebrate", onPrimary: () => toast({ title: "Celebrated quietly." }), secondaryLabel: "Plan Another", onSecondary: startTogether };
  return { eyebrow: circle.name, title: "Ready to Lock In Together?", description: `${circle.member_count}/8 members are ready when you are.`, primaryLabel: "Start Together", onPrimary: startTogether, secondaryLabel: "Schedule Lockin", onSecondary: startTogether };
}

function JoinRequests({ requests, circleId, onChange }) {
  return <div className="space-y-2">{requests.map(req => <div key={req.id} className="flex items-center justify-between gap-3 rounded-2xl bg-muted/40 p-3"><p className="text-sm font-medium text-foreground">@{req.username}</p><div className="flex gap-2"><Button size="sm" onClick={() => circleAction("reviewJoinRequest", { circleId, requestId: req.id, decision: "approve" }).then(onChange)} className="rounded-full">Approve</Button><Button size="sm" variant="outline" onClick={() => circleAction("reviewJoinRequest", { circleId, requestId: req.id, decision: "decline" }).then(onChange)} className="rounded-full">Decline</Button></div></div>)}</div>;
}

function MembersPanel({ circle, membership, activeStatuses, isOwner, circleId, onProfile, onChange }) {
  return <div className="space-y-2">{circle.members.map(member => <MemberRow key={member.id} member={member} status={activeStatuses?.[member.user_id]} isOwner={isOwner} currentUserId={membership.user_id} circleId={circleId} onProfile={() => onProfile(member.user_id)} onChange={onChange} />)}</div>;
}

function PrivacyPanel({ circle, onCopyCode }) {
  return <div className="rounded-3xl bg-muted/30 border border-border p-4 space-y-3"><p className="text-sm font-semibold text-foreground">{circle.privacy === "private" ? "Private Circle" : "Public Circle"}</p><p className="text-sm text-muted-foreground">Only people with access can participate. Use the invite flow for trusted members.</p>{circle.code && <Button variant="outline" onClick={onCopyCode} className="w-full rounded-2xl">Copy Code · {circle.code}</Button>}</div>;
}

function ActivityPanel({ activity, positiveReactions, membership, onProfile, navigate, refreshActivity, load, toast }) {
  if (activity.length === 0) return <div className="rounded-3xl bg-muted/30 border border-border p-5 text-center"><p className="text-sm text-muted-foreground">No shared Lockins yet.</p></div>;
  return <section className="space-y-3">{activity.map(item => <CircleActivityCard key={item.id} item={item} reactions={positiveReactions} currentUserId={membership.user_id} onProfile={onProfile} onStartYours={() => navigate("/lockin-setup")} onReact={(activityId, emoji) => circleAction("toggleReaction", { activityId, emoji }).then(refreshActivity)} onMessage={(activityId, message) => circleAction("addEncouragement", { activityId, message }).then(refreshActivity).catch(error => toast({ title: error?.response?.data?.error || "Could not send message", variant: "destructive" }))} onDeleteMessage={(messageId) => circleAction("deleteEncouragement", { messageId }).then(load)} onReportMessage={(messageId) => circleAction("reportEncouragement", { messageId }).then(load)} />)}</section>;
}

function OwnerEditor({ circle, saving, onSave }) {
  const [form, setForm] = useState({ name: circle.name, icon: circle.icon, purpose: circle.purpose || "", privacy: circle.privacy });
  return <div className="rounded-3xl bg-muted/30 border border-border p-4 space-y-2"><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="rounded-2xl" /><div className="grid grid-cols-2 gap-2"><Input value={form.icon} onChange={e => setForm({ ...form, icon: e.target.value })} className="rounded-2xl" /><select value={form.privacy} onChange={e => setForm({ ...form, privacy: e.target.value })} className="rounded-2xl border border-input bg-background px-3 text-sm text-foreground"><option value="private">Private</option><option value="public">Public</option></select></div><Input value={form.purpose} onChange={e => setForm({ ...form, purpose: e.target.value })} placeholder="Purpose" className="rounded-2xl" /><Button onClick={() => onSave(form)} disabled={saving || !form.name.trim()} className="w-full rounded-2xl">{saving ? "Saving..." : "Save Changes"}</Button></div>;
}

function MemberRow({ member, status, isOwner, currentUserId, circleId, onProfile, onChange }) {
  const isSelf = member.user_id === currentUserId;
  return <div className="rounded-2xl bg-muted/50 p-3 space-y-2"><div className="flex items-center justify-between gap-3"><button onClick={onProfile} className="flex items-center gap-3 min-w-0 text-left"><div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-sm font-bold">{(member.display_name || "M").slice(0, 1).toUpperCase()}</div><div className="min-w-0"><p className="text-sm font-semibold text-foreground truncate">{member.display_name} {isSelf && "(you)"}</p><p className="text-xs text-muted-foreground">@{member.username} · {status === "locked_in" ? "🟢 Locked In" : "⚪ Joined"}</p></div></button>{member.role === "owner" && <span className="text-xs font-semibold text-primary flex items-center gap-1"><Crown className="w-3 h-3" /> Owner</span>}</div>{!isSelf && <div className="flex flex-wrap gap-2"><Button size="sm" variant="outline" onClick={() => circleAction("reportMember", { circleId, targetUserId: member.user_id }).then(onChange)} className="rounded-full"><Flag className="w-3 h-3" /> Report</Button><Button size="sm" variant="outline" onClick={() => circleAction("blockMember", { circleId, targetUserId: member.user_id }).then(onChange)} className="rounded-full"><Ban className="w-3 h-3" /> Block</Button>{isOwner && member.role !== "owner" && <Button size="sm" variant="outline" onClick={() => circleAction("removeMember", { circleId, memberUserId: member.user_id }).then(onChange)} className="rounded-full text-destructive"><UserMinus className="w-3 h-3" /> Remove</Button>}</div>}</div>;
}