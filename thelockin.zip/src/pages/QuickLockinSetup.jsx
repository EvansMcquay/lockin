import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, ChevronRight, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { LOCK_TEMPLATES } from "@/lib/lockTemplates";
import { getFaviconUrl } from "@/lib/appLibrary";
import AppSearchPicker from "@/components/AppSearchPicker";
import { useToast } from "@/components/ui/use-toast";
import { formatDuration } from "@/lib/freedomLockData";
import LockTransition from "@/components/LockTransition";
import ScheduleIcon from "@/components/schedules/ScheduleIcon";
import ScheduleIconPicker from "@/components/schedules/ScheduleIconPicker";
import { hasActiveLockSession } from "@/lib/activeSessions";
import { DEFAULT_ICON_STYLE } from "@/lib/scheduleIcons";
import { circleAction } from "@/lib/circlesApi";
import { lockinFriendsAction } from "@/lib/lockinFriendsApi";
import { sharedLockinSetupUrl } from "@/lib/sharedLockinLinks";
import LockinFriendsStep from "@/components/lockinFriends/LockinFriendsStep";

const DURATION_PRESETS = [30, 60, 90, 120, 180, 480];

export default function QuickLockinSetupContent() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [template, setTemplate] = useState(null);
  const [focus, setFocus] = useState("");
  const [icon, setIcon] = useState("✨");
  const [iconStyle, setIconStyle] = useState(DEFAULT_ICON_STYLE);
  const [selectedApps, setSelectedApps] = useState([]);
  const [durationMinutes, setDurationMinutes] = useState(60);
  const [lockinFriends, setLockinFriends] = useState({ targets: [], helpMode: "both" });
  const [saving, setSaving] = useState(false);
  const [showTransition, setShowTransition] = useState(false);

  const goalName = focus.trim() || (template?.id === "custom" ? "Custom" : template?.label);

  const selectTemplate = (tpl) => {
    if (navigator.vibrate) navigator.vibrate(8);
    setTemplate(tpl);
    setIcon(tpl.emoji || "✨");
    setIconStyle(tpl.icon_style || DEFAULT_ICON_STYLE);
    setSelectedApps(tpl.apps);
    setDurationMinutes(tpl.duration_minutes);
    setStep(2);
  };

  const toggleApp = (app) => {
    setSelectedApps(prev =>
      prev.find(a => a.name === app.name)
        ? prev.filter(a => a.name !== app.name)
        : [...prev, app]
    );
  };

  const handleSubmit = async () => {
    if (selectedApps.length === 0) {
      toast({ title: "Select at least one app", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const now = new Date();
      const recentLocks = await base44.entities.AppLock.list("-created_date", 50);
      if (hasActiveLockSession(recentLocks)) {
        toast({ title: "Lock-In already active", description: "Finish your current session before starting another." });
        setSaving(false);
        return;
      }
      const unlockTime = new Date(now.getTime() + durationMinutes * 60 * 1000);
      const lockSessionKey = `${now.toISOString()}-${goalName}`;
      const createdLocks = await Promise.all(selectedApps.map(app =>
        base44.entities.AppLock.create({
          app_name: app.name,
          app_icon: "📱",
          goal_name: goalName,
          goal_emoji: icon,
          lockin_category: template?.label || "Lockin",
          lock_session_key: lockSessionKey,
          icon_style: iconStyle,
          duration_minutes: durationMinutes,
          severity_level: "stay_focused",
          locked_at: now.toISOString(),
          unlocks_at: unlockTime.toISOString(),
          status: "active",
          hardcore_mode: false,
        })
      ));
      await circleAction("shareLockinStarted", { lockId: createdLocks[0]?.id, lock_session_key: lockSessionKey, template_name: template?.label || "Lockin", focus: focus.trim(), duration_minutes: durationMinutes, started_at: now.toISOString(), unlocks_at: unlockTime.toISOString() });
      if (lockinFriends.targets.length > 0) {
        await lockinFriendsAction("saveLockinFriends", { targets: lockinFriends.targets, helpMode: lockinFriends.helpMode, lockSessionKey, goalName, category: template?.label || "Lockin", startAt: now.toISOString(), timezone: Intl.DateTimeFormat().resolvedOptions().timeZone });
      }
      setSaving(false);
      setShowTransition(true);
    } catch {
      toast({ title: "Something went wrong", variant: "destructive" });
      setSaving(false);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
      if (step === 2) {
        setTemplate(null);
        setSelectedApps([]);
        setFocus("");
        setIcon("✨");
        setIconStyle(DEFAULT_ICON_STYLE);
      }
    } else {
      navigate("/");
    }
  };

  const stepTitles = ["Click", "Tap", "Lockin", "Apps", "Review"];
  const focusPlaceholders = {
    homework: "e.g. Finish SQL Assignment",
    work: "e.g. Complete Sprint Tasks",
    gym: "e.g. Leg Day",
    sleep: "e.g. Be asleep by 10:30 PM",
    custom: "e.g. Meditation, Project...",
  };

  return (
    <div className="max-w-lg mx-auto px-5 py-8 min-h-screen flex flex-col">
      <AnimatePresence>
        {showTransition && (
          <LockTransition
            emoji={icon}
            goalName={goalName}
            onComplete={() => {
              setShowTransition(false);
              setStep(1);
              setTemplate(null);
              setFocus("");
              setIcon("✨");
              setIconStyle(DEFAULT_ICON_STYLE);
              setSelectedApps([]);
              setLockinFriends({ targets: [], helpMode: "both" });
              setDurationMinutes(60);
              navigate("/");
            }}
          />
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={handleBack}
          className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-muted transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="font-heading font-bold text-xl text-foreground">{stepTitles[step - 1]}</h1>
      </div>

      <AnimatePresence mode="wait">
        {/* Step 1 — Choose Template */}
        {step === 1 && (
          <motion.div
            key="step1"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
            className="flex-1 flex flex-col"
          >
            <div className="mb-4">
              <h2 className="font-heading font-bold text-lg text-foreground mb-1">What kind of Lockin?</h2>
              <p className="text-sm text-muted-foreground">Choose a template, then make it yours.</p>
            </div>
            <div className="space-y-2.5 flex-1">
              {LOCK_TEMPLATES.map(tpl => (
                <motion.button
                  key={tpl.id}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => selectTemplate(tpl)}
                  className="w-full text-left rounded-2xl border border-border bg-card p-4 hover:border-primary/30 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <ScheduleIcon icon={tpl.emoji} styleName={tpl.icon_style || DEFAULT_ICON_STYLE} />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm text-foreground">{tpl.label}</p>
                      <p className="text-xs text-muted-foreground truncate">{tpl.description}</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  </div>

                </motion.button>
              ))}
            </div>


          </motion.div>
        )}

        {/* Step 2 — Add Focus (optional) */}
        {step === 2 && (
          <motion.div
            key="step2"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
            className="flex-1 space-y-6"
          >
            <div className="flex items-center gap-2">
              <ScheduleIcon icon={icon} styleName={iconStyle} size="sm" />
              <h2 className="font-heading font-bold text-lg text-foreground">{template?.label}</h2>
            </div>
            <div>
              <h2 className="font-heading font-bold text-lg text-foreground mb-1">What is your goal?</h2>
              <p className="text-sm text-muted-foreground">Optional — leave blank to skip.</p>
            </div>
            <Input
              placeholder={focusPlaceholders[template?.id] || "What's your goal?"}
              value={focus}
              onChange={e => setFocus(e.target.value)}
              onKeyDown={e => e.key === "Enter" && setStep(3)}
              className="h-12 rounded-2xl"
              autoFocus
            />
            <ScheduleIconPicker
              value={icon}
              styleName={iconStyle}
              onIconChange={setIcon}
              onStyleChange={setIconStyle}
            />
            <Button
              onClick={() => setStep(3)}
              className="w-full rounded-2xl h-12 font-semibold"
            >
              Continue →
            </Button>
          </motion.div>
        )}

        {/* Step 3 — Choose Duration */}
        {step === 3 && (
          <motion.div
            key="step3"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
            className="flex-1 space-y-6"
          >
            <div className="flex items-center gap-2">
              <ScheduleIcon icon={icon} styleName={iconStyle} size="sm" />
              <h2 className="font-heading font-bold text-lg text-foreground">{goalName}</h2>
            </div>
            <div>
              <h2 className="font-heading font-bold text-lg text-foreground mb-1">How long?</h2>
              <p className="text-sm text-muted-foreground">Pick the time you want protected.</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {DURATION_PRESETS.map(min => (
                <button
                  key={min}
                  onClick={() => setDurationMinutes(min)}
                  className={`rounded-2xl border py-5 text-center font-bold transition-all active:scale-[0.96] ${
                    durationMinutes === min
                      ? "bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/20"
                      : "bg-card border-border text-foreground"
                  }`}
                >
                  <span className="text-lg">{formatDuration(min)}</span>
                </button>
              ))}
            </div>
            <Button
              onClick={() => setStep(4)}
              className="w-full rounded-2xl h-12 font-semibold"
            >
              Continue →
            </Button>
          </motion.div>
        )}

        {/* Step 4 — Choose Locked Apps */}
        {step === 4 && (
          <motion.div
            key="step4"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
            className="flex-1 space-y-4"
          >
            <div className="flex items-center gap-2">
              <ScheduleIcon icon={icon} styleName={iconStyle} size="sm" />
              <h2 className="font-heading font-bold text-lg text-foreground">{goalName}</h2>
            </div>
            <div>
              <h2 className="font-heading font-bold text-lg text-foreground mb-1">Which apps should lock?</h2>
              <p className="text-sm text-muted-foreground">{selectedApps.length} selected</p>
            </div>
            <AppSearchPicker selected={selectedApps} onToggle={toggleApp} />
            <Button
              onClick={() => setStep(5)}
              disabled={selectedApps.length === 0}
              className="w-full rounded-2xl h-12 font-semibold"
            >
              Continue →
            </Button>
            {selectedApps.length === 0 && (
              <p className="text-center text-xs text-muted-foreground">Select at least one app to block.</p>
            )}
          </motion.div>
        )}

        {/* Step 5 — Review */}
        {step === 5 && (
          <motion.div
            key="step5"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
            className="flex-1 space-y-5"
          >
            <div className="flex items-center gap-2">
              <ScheduleIcon icon={icon} styleName={iconStyle} size="sm" />
              <h2 className="font-heading font-bold text-lg text-foreground">{goalName}</h2>
            </div>
            <div>
              <h2 className="font-heading font-bold text-lg text-foreground mb-1">Ready to start?</h2>
              <p className="text-sm text-muted-foreground">One tap locks this in.</p>
            </div>

            {/* Review cards */}
            <div className="space-y-2.5">
              <ReviewRow label="Focus" value={goalName} emoji={icon} styleName={iconStyle} onEdit={() => setStep(2)} />
              <ReviewRow label="Duration" value={formatDuration(durationMinutes)} onEdit={() => setStep(3)} />
              <ReviewRow
                label="Blocked Apps"
                value={`${selectedApps.length} app${selectedApps.length !== 1 ? "s" : ""}`}
                onEdit={() => setStep(4)}
              />
            </div>

            <Button
              type="button"
              variant="outline"
              onClick={() => navigate(sharedLockinSetupUrl({ category: template?.label || "Custom", focus: goalName, duration: durationMinutes }))}
              className="w-full rounded-2xl h-12 font-semibold"
            >
              Invite to Lockin
            </Button>

            <LockinFriendsStep value={lockinFriends} onChange={setLockinFriends} />

            {/* App list preview */}
            <div className="rounded-2xl border border-border bg-card p-4">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3">Apps being blocked</p>
              <div className="flex flex-wrap gap-2">
                {selectedApps.map(app => (
                  <div key={app.name} className="flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1">
                    <img
                      src={getFaviconUrl(app.domain)}
                      alt={app.name}
                      className="w-4 h-4 rounded"
                      onError={e => { e.target.style.display = "none"; }}
                    />
                    <span className="text-xs font-medium text-foreground">{app.name}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Final Start Lockin button */}
            <div className="pt-2">
              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={handleSubmit}
                disabled={saving}
                className="w-full rounded-2xl bg-primary text-primary-foreground font-bold text-base py-4 shadow-lg shadow-primary/25 disabled:opacity-60 flex items-center justify-center gap-2"
              >
                {saving ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Locking in...
                  </>
                ) : (
                  <>🔒 Start Lockin</>
                )}
              </motion.button>
              <p className="text-center text-xs text-muted-foreground mt-2">
                {formatDuration(durationMinutes)} · {selectedApps.length} apps blocked
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ReviewRow({ label, value, emoji, styleName, onEdit }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4 flex items-center justify-between">
      <div className="flex items-center gap-2 min-w-0">
        {emoji && <ScheduleIcon icon={emoji} styleName={styleName} size="sm" />}
        <div className="min-w-0">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">{label}</p>
          <p className="text-sm font-semibold text-foreground truncate">{value}</p>
        </div>
      </div>
      {onEdit && (
        <button
          onClick={onEdit}
          className="text-xs font-semibold text-primary flex-shrink-0"
        >
          Edit
        </button>
      )}
    </div>
  );
}