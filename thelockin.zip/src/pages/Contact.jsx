import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Mail, MessageCircle } from "lucide-react";

export default function Contact() {
  return (
    <div className="min-h-screen bg-background text-foreground px-5 py-8">
      <div className="max-w-lg mx-auto space-y-8">
        <header className="flex items-center justify-between gap-4">
          <Link to="/" className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4" /> Home
          </Link>
          <Link to="/about" className="text-sm font-semibold text-primary hover:text-primary/80">About</Link>
        </header>

        <main className="rounded-[28px] border border-border bg-card/90 p-6 shadow-lg shadow-black/10 space-y-5">
          <div className="w-12 h-12 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
            <MessageCircle className="w-6 h-6" />
          </div>
          <div className="space-y-3">
            <p className="premium-label">Get in touch</p>
            <h1 className="text-3xl font-heading font-bold tracking-[-0.04em]">Contact</h1>
            <p className="text-sm leading-6 text-muted-foreground">
              Have feedback, questions, or partnership ideas for Lockin? Reach out and we’ll review your message.
            </p>
          </div>
          <a
            href="mailto:hello@lockin.app"
            className="flex items-center gap-3 rounded-2xl border border-border bg-secondary/70 p-4 text-foreground hover:bg-secondary"
          >
            <span className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
              <Mail className="w-5 h-5" />
            </span>
            <span>
              <span className="block text-sm font-semibold">Email</span>
              <span className="block text-sm text-muted-foreground">hello@lockin.app</span>
            </span>
          </a>
        </main>

        <footer className="flex items-center justify-center gap-5 text-xs text-muted-foreground pb-4">
          <Link to="/about" className="hover:text-foreground">About</Link>
          <Link to="/contact" className="font-semibold text-foreground">Contact</Link>
        </footer>
      </div>
    </div>
  );
}