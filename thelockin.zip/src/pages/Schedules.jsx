import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Plus, Sparkles } from "lucide-react";
import { SCHEDULE_TEMPLATES } from "@/lib/scheduleTemplates";
import { useToast } from "@/components/ui/use-toast";
import RoutinePlanner from "@/components/schedules/RoutinePlanner";

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

function getDateKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatTime(timeStr) {
  const [h, m] = timeStr.split(":").map(Number);
  const date = new Date();
  date.setHours(h, m, 0, 0);
  return date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
}

export default function Schedules() {
  const location = useLocation();
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [applyingTemplate, setApplyingTemplate] = useState(null);
  const { toast } = useToast();

  const fetchSchedules = async () => {
    const data = await base44.entities.RecurringSchedule.list("-created_date", 50);
    setSchedules(data.filter(schedule => !schedule.deleted_at));
    setLoading(false);
  };

  useEffect(() => {
    if (location.pathname === "/schedules") fetchSchedules();
  }, [location.pathname]);

  const handleDelete = async (schedule) => {
    if (!window.confirm("Delete this schedule? Past sessions stay in your history.")) return;
    await base44.entities.RecurringSchedule.update(schedule.id, { deleted_at: new Date().toISOString(), is_active: false });
    toast({ title: "Schedule deleted", description: "Past sessions were kept in your history." });
    fetchSchedules();
  };

  const handleSkipToday = async (schedule) => {
    const skipDates = [...new Set([...(schedule.skip_dates || []), getDateKey()])];
    await base44.entities.RecurringSchedule.update(schedule.id, { skip_dates: skipDates });
    toast({ title: "Skipped for today", description: "This schedule will return on its next planned day." });
    fetchSchedules();
  };

  const handleToggleActive = async (schedule) => {
    const newValue = schedule.is_active === false ? true : false;
    // Optimistic update — toggle instantly, roll back only on error
    setSchedules(prev => prev.map(s => s.id === schedule.id ? { ...s, is_active: newValue } : s));
    try {
      await base44.entities.RecurringSchedule.update(schedule.id, { is_active: newValue });
    } catch {
      setSchedules(prev => prev.map(s => s.id === schedule.id ? { ...s, is_active: schedule.is_active } : s));
      toast({ title: "Failed to update schedule", variant: "destructive" });
    }
  };

  const applyTemplate = async (template) => {
    setApplyingTemplate(template.id);
    try {
      await base44.entities.RecurringSchedule.bulkCreate(
        template.schedules.map(s => ({ ...s, is_active: true }))
      );
      toast({ title: `${template.emoji} ${template.name} applied!`, description: `${template.schedules.length} schedules created. Edit any of them to customize.` });
      fetchSchedules();
    } catch {
      toast({ title: "Something went wrong", variant: "destructive" });
    } finally {
      setApplyingTemplate(null);
    }
  };

  const formatDays = (days) => {
    if (!days || days.length === 0) return "No days selected";
    if (days.length === 7) return "Every day";
    if (JSON.stringify([...days].sort()) === JSON.stringify([1, 2, 3, 4, 5])) return "Weekdays";
    if (JSON.stringify([...days].sort()) === JSON.stringify([0, 6])) return "Weekends";
    return days.map(d => DAYS[d]).join(", ");
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto px-5 py-8 space-y-6" style={{ paddingBottom: "calc(var(--safe-area-bottom) + 6rem)" }}>
      <div className="flex items-center justify-between gap-4">
        <div className="min-w-0">
          <p className="text-sm font-medium text-primary mb-1">Routine planner</p>
          <h1 className="font-heading font-bold text-2xl text-foreground">What’s coming up?</h1>
          <p className="text-sm text-muted-foreground">Compact groups for daily routines.</p>
        </div>
        <Link to="/schedule-builder" className="shrink-0">
          <Button size="sm" className="rounded-full gap-1">
            <Plus className="w-4 h-4" /> New
          </Button>
        </Link>
      </div>

      {/* Templates */}
      {schedules.length === 0 && (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4 text-accent" />
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Start with a routine</p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {SCHEDULE_TEMPLATES.map(tpl => (
              <button
                key={tpl.id}
                onClick={() => applyTemplate(tpl)}
                disabled={applyingTemplate !== null}
                className="flex flex-col items-start gap-1.5 rounded-2xl border border-border bg-card p-4 text-left active:scale-[0.97] transition-transform disabled:opacity-60"
              >
                <span className="text-2xl">{tpl.emoji}</span>
                <span className="text-sm font-semibold text-foreground">{tpl.name}</span>
                <span className="text-[11px] text-muted-foreground leading-tight">{tpl.description}</span>
                <span className="text-[11px] text-primary font-medium mt-1">
                  {applyingTemplate === tpl.id ? "Adding..." : "Tap to add →"}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Existing schedules */}
      {schedules.length > 0 && (
        <RoutinePlanner
          schedules={schedules}
          onToggleActive={handleToggleActive}
          onSkipToday={handleSkipToday}
          onDelete={handleDelete}
          formatTime={formatTime}
          formatDays={formatDays}
        />
      )}
    </div>
  );
}