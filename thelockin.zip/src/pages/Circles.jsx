import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import CircleCard from "@/components/circles/CircleCard";
import CircleProgressiveHeader from "@/components/circles/CircleProgressiveHeader";
import CreateCircleDialog from "@/components/circles/CreateCircleDialog";
import UsernamePromptDialog from "@/components/circles/UsernamePromptDialog";
import { circleAction } from "@/lib/circlesApi";

export default function Circles() {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [data, setData] = useState({ circles: [], invitations: [], publicCircles: [], username: "", requiresUsername: false });
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [joinOpen, setJoinOpen] = useState(false);
  const [inviteLinkOpen, setInviteLinkOpen] = useState(false);
  const [joinCode, setJoinCode] = useState("");
  const [joining, setJoining] = useState(false);
  const [inviteText, setInviteText] = useState("");
  const [invitePreview, setInvitePreview] = useState(null);

  const load = async () => {
    const result = await circleAction("listCircles");
    setData(result);
    setLoading(false);
  };

  useEffect(() => {
    if (location.pathname !== "/circles") return;
    load();
    const token = new URLSearchParams(location.search).get("invite");
    if (token) {
      circleAction("previewInvite", { token }).then(result => acceptInvite({ token: result.invite.token })).catch(() => toast({ title: "Invalid invitation", variant: "destructive" }));
    }
  }, [location.pathname, location.search]);

  const createCircle = async (form) => {
    setCreating(true);
    try {
      const circle = await circleAction("createCircle", form);
      setCreateOpen(false);
      navigate(`/circles/${circle.id}`);
    } catch (error) {
      toast({ title: error?.response?.data?.error || "Could not create circle", variant: "destructive" });
      throw error;
    } finally {
      setCreating(false);
    }
  };

  const joinByCode = async () => {
    const code = joinCode.trim();
    if (!code) return;
    setJoining(true);
    try {
      const result = await circleAction("joinByCircleCode", { code });
      setJoinOpen(false);
      navigate(`/circles/${result.circleId}`);
    } catch (error) {
      toast({ title: error?.response?.data?.error || "Could not join circle", variant: "destructive" });
    } finally {
      setJoining(false);
    }
  };

  const previewInvite = async () => {
    const token = inviteText.trim().split("invite=").pop();
    if (!token) return;
    try {
      setInvitePreview(await circleAction("previewInvite", { token }));
    } catch {
      toast({ title: "Invalid or expired invitation", variant: "destructive" });
    }
  };

  const acceptInvite = async (payload) => {
    const result = await circleAction("acceptInvite", payload);
    navigate(`/circles/${result.circleId}`);
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="w-8 h-8 rounded-full border-4 border-muted border-t-primary animate-spin" /></div>;

  return (
    <div className="max-w-lg mx-auto px-5 py-8 space-y-6" style={{ paddingBottom: "calc(var(--safe-area-bottom) + 6rem)" }}>
      <CircleProgressiveHeader
        username={data.username}
        onJoin={() => setJoinOpen(true)}
        onCreate={() => setCreateOpen(true)}
        onInviteLink={() => { setInvitePreview(null); setInviteLinkOpen(true); }}
      />


      {data.invitations.length > 0 && <section className="space-y-3"><h2 className="font-heading font-bold text-lg text-white">Invitations</h2>{data.invitations.map(invite => <InvitePreview key={invite.id} invite={invite} onAccept={() => acceptInvite({ inviteId: invite.id })} onDecline={() => circleAction("declineInvite", { inviteId: invite.id }).then(load)} />)}</section>}

      {data.circles.length > 0 && <section className="space-y-3"><h2 className="font-heading font-bold text-lg text-white">Your Circles</h2>{data.circles.map(circle => <CircleCard key={circle.id} circle={circle} />)}</section>}

      {data.publicCircles.length > 0 && <section className="space-y-3"><h2 className="font-heading font-bold text-lg text-white">Public Circles</h2>{data.publicCircles.map(circle => <PublicCircle key={circle.id} circle={circle} onRequest={() => circleAction("requestJoin", { circleId: circle.id }).then(() => toast({ title: "Request sent" }))} />)}</section>}

      <Dialog open={inviteLinkOpen} onOpenChange={setInviteLinkOpen}>
        <DialogContent className="rounded-3xl bg-card border-border">
          <DialogHeader><DialogTitle className="text-white">Paste Invitation Link</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Input value={inviteText} onChange={e => setInviteText(e.target.value)} placeholder="Paste invitation link" className="rounded-2xl" />
            <Button onClick={previewInvite} disabled={!inviteText.trim()} className="w-full rounded-2xl">Check Link</Button>
            {invitePreview && <InvitePreview invite={invitePreview} onAccept={() => acceptInvite({ token: invitePreview.invite.token })} onDecline={() => circleAction("declineInvite", { token: invitePreview.invite.token }).then(() => setInvitePreview(null))} />}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={joinOpen} onOpenChange={setJoinOpen}>
        <DialogContent className="rounded-3xl bg-card border-border">
          <DialogHeader><DialogTitle className="text-white">Enter Circle Code</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Input value={joinCode} onChange={e => setJoinCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ""))} placeholder="ABCDE" className="rounded-2xl tracking-[0.22em] font-mono uppercase text-center text-lg" autoFocus />
            <Button onClick={joinByCode} disabled={joining || !joinCode.trim()} className="w-full rounded-2xl">{joining ? "Joining..." : "Join Circle"}</Button>
          </div>
        </DialogContent>
      </Dialog>

      <UsernamePromptDialog open={data.requiresUsername} onCreated={() => load()} />
      <CreateCircleDialog open={createOpen} onOpenChange={setCreateOpen} onCreate={createCircle} saving={creating} />
    </div>
  );
}

function InvitePreview({ invite, onAccept, onDecline }) {
  const circle = invite.circle;
  return <div className="rounded-2xl bg-muted/50 p-3 space-y-3"><div className="flex gap-3"><span className="text-2xl">{circle.icon}</span><div><p className="font-semibold text-sm text-white">{circle.name}</p><p className="text-xs text-white">Owner: {circle.owner_name} · {circle.member_count}/8 members</p>{circle.purpose && <p className="text-xs text-white mt-1">{circle.purpose}</p>}</div></div><div className="grid grid-cols-2 gap-2"><Button onClick={onAccept} className="rounded-xl h-9"><Check className="w-4 h-4" /> Accept</Button><Button onClick={onDecline} variant="outline" className="rounded-xl h-9"><X className="w-4 h-4" /> Decline</Button></div></div>;
}

function PublicCircle({ circle, onRequest }) {
  return <div className="rounded-3xl border border-border bg-card p-4 flex items-center justify-between gap-3"><div className="flex items-center gap-3 min-w-0"><span className="text-2xl">{circle.icon}</span><div className="min-w-0"><p className="font-semibold text-sm text-white truncate">{circle.name}</p><p className="text-xs text-white">{circle.member_count}/8 members · public</p></div></div><Button size="sm" onClick={onRequest} disabled={circle.member_count >= 8} className="rounded-full">{circle.member_count >= 8 ? "Full" : "Request"}</Button></div>;
}