import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Bell, CalendarDays, Clock, Pencil, Share2, Users } from "lucide-react";
import { SCHEDULE_FORM_TEMPLATES } from "@/lib/lockTemplates";
import AppSearchPicker from "@/components/AppSearchPicker";
import ScheduleConflictWarning from "@/components/schedules/ScheduleConflictWarning";
import ScheduleFlowShell from "@/components/schedules/ScheduleFlowShell";
import ScheduleIcon from "@/components/schedules/ScheduleIcon";
import ScheduleIconPicker from "@/components/schedules/ScheduleIconPicker";
import ScheduleOptionButton from "@/components/schedules/ScheduleOptionButton";
import ScheduleSummaryCard from "@/components/schedules/ScheduleSummaryCard";
import { useToast } from "@/components/ui/use-toast";
import { findScheduleConflicts, getAdjustedScheduleTime } from "@/lib/scheduleConflicts";
import { DEFAULT_ICON_STYLE } from "@/lib/scheduleIcons";
import { sharedLockinSetupUrl } from "@/lib/sharedLockinLinks";
import { lockinFriendsAction } from "@/lib/lockinFriendsApi";
import LockinFriendsStep from "@/components/lockinFriends/LockinFriendsStep";

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const STEPS = ["template", "name", "days", "time", "apps", "friends", "review"];
const DAY_PRESETS = [
  { id: "weekdays", label: "Weekdays", days: [1, 2, 3, 4, 5], detail: "Monday through Friday" },
  { id: "everyday", label: "Every day", days: [0, 1, 2, 3, 4, 5, 6], detail: "A daily Lockin" },
  { id: "weekend", label: "Weekend", days: [0, 6], detail: "Saturday and Sunday" },
];
const TIME_PRESETS = [
  { id: "morning", label: "Morning", start: "08:00", end: "10:00", detail: "8:00 AM–10:00 AM" },
  { id: "workday", label: "Workday", start: "09:00", end: "17:00", detail: "9:00 AM–5:00 PM" },
  { id: "evening", label: "Evening", start: "18:00", end: "20:00", detail: "6:00 PM–8:00 PM" },
];

function formatTime(timeStr) {
  const [h, m] = timeStr.split(":").map(Number);
  const date = new Date();
  date.setHours(h, m, 0, 0);
  return date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
}

function formatDays(days) {
  if (!days || days.length === 0) return "No days";
  const sorted = [...days].sort((a, b) => a - b);
  if (sorted.length === 7) return "Every day";
  if (JSON.stringify(sorted) === JSON.stringify([1, 2, 3, 4, 5])) return "Weekdays";
  if (JSON.stringify(sorted) === JSON.stringify([0, 6])) return "Weekend";
  return sorted.map(d => DAYS[d]).join(", ");
}

function sameDays(a, b) {
  return JSON.stringify([...(a || [])].sort((x, y) => x - y)) === JSON.stringify([...(b || [])].sort((x, y) => x - y));
}

function dayModeFor(nextDays) {
  const match = DAY_PRESETS.find(preset => sameDays(preset.days, nextDays));
  return match?.id || "custom";
}

function timeModeFor(start, end) {
  const match = TIME_PRESETS.find(preset => preset.start === start && preset.end === end);
  return match?.id || "custom";
}

export default function ScheduleBuilderContent() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const editId = searchParams.get("edit");
  const { toast } = useToast();

  const [step, setStep] = useState("template");
  const [template, setTemplate] = useState(null);
  const [focus, setFocus] = useState("");
  const [label, setLabel] = useState("");
  const [emoji, setEmoji] = useState("➕");
  const [iconStyle, setIconStyle] = useState(DEFAULT_ICON_STYLE);
  const [days, setDays] = useState([1, 2, 3, 4, 5]);
  const [dayMode, setDayMode] = useState("weekdays");
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("17:00");
  const [timeMode, setTimeMode] = useState("workday");
  const [selectedApps, setSelectedApps] = useState([]);
  const [lockinFriends, setLockinFriends] = useState({ targets: [], helpMode: "both" });
  const [showFriendsPicker, setShowFriendsPicker] = useState(false);
  const [reminder, setReminder] = useState(true);
  const [customizing, setCustomizing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [existingSchedules, setExistingSchedules] = useState([]);

  useEffect(() => {
    base44.entities.RecurringSchedule.list("-created_date", 50).then(all => {
      setExistingSchedules(all);
      if (!editId) return;
      const sched = all.find(s => s.id === editId);
      if (!sched) return;
      setLabel(sched.label || "");
      setFocus(sched.goal_name || sched.label || "");
      setEmoji(sched.goal_emoji || "➕");
      setIconStyle(sched.icon_style || DEFAULT_ICON_STYLE);
      setDays(sched.days_of_week || [1, 2, 3, 4, 5]);
      setDayMode(dayModeFor(sched.days_of_week || [1, 2, 3, 4, 5]));
      setStartTime(sched.start_time || "09:00");
      setEndTime(sched.end_time || "17:00");
      setTimeMode(timeModeFor(sched.start_time || "09:00", sched.end_time || "17:00"));
      setSelectedApps(sched.apps || []);
      setReminder(sched.reminder_enabled !== false);
      setStep("review");
    });
  }, [editId]);

  const goalName = focus.trim() || label.trim();
  const stepIndex = Math.max(0, STEPS.indexOf(step));
  const progress = `${((stepIndex + 1) / STEPS.length) * 100}%`;

  const conflicts = useMemo(() => findScheduleConflicts({
    days_of_week: days,
    start_time: startTime,
    end_time: endTime,
  }, existingSchedules, editId), [days, startTime, endTime, existingSchedules, editId]);

  const chooseTemplate = (tpl) => {
    setTemplate(tpl);
    setLabel(tpl.label);
    setFocus(tpl.label);
    setEmoji(tpl.emoji);
    setIconStyle(tpl.icon_style || DEFAULT_ICON_STYLE);
    setDays(tpl.days_of_week);
    setDayMode(dayModeFor(tpl.days_of_week));
    setStartTime(tpl.start_time);
    setEndTime(tpl.end_time);
    setTimeMode(timeModeFor(tpl.start_time, tpl.end_time));
    setSelectedApps(tpl.apps);
    setStep("name");
  };

  const toggleDay = (day) => {
    setDayMode("custom");
    setDays(prev => prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]);
  };

  const toggleApp = (app) => {
    setSelectedApps(prev => prev.find(a => a.name === app.name) ? prev.filter(a => a.name !== app.name) : [...prev, app]);
  };

  const chooseDayPreset = (preset) => {
    setDayMode(preset.id);
    setDays(preset.days);
  };

  const chooseTimePreset = (preset) => {
    setTimeMode(preset.id);
    setStartTime(preset.start);
    setEndTime(preset.end);
  };

  const goNext = () => setStep(STEPS[Math.min(stepIndex + 1, STEPS.length - 1)]);

  const handleBack = () => {
    if (editId && step === "review") return navigate("/schedules");
    if (stepIndex <= 0) return navigate("/schedules");
    setStep(STEPS[stepIndex - 1]);
  };

  const adjustAfterConflict = () => {
    if (conflicts.length === 0) return;
    const adjusted = getAdjustedScheduleTime(conflicts[0], startTime, endTime);
    setStartTime(adjusted.start_time);
    setEndTime(adjusted.end_time);
    setTimeMode(timeModeFor(adjusted.start_time, adjusted.end_time));
    toast({ title: "Time adjusted" });
  };

  const handleSave = async (saveAnyway = false) => {
    if (!label.trim()) { setStep("name"); toast({ title: "Name this Lockin first", variant: "destructive" }); return; }
    if (days.length === 0) { setStep("days"); toast({ title: "Choose at least one day", variant: "destructive" }); return; }
    if (selectedApps.length === 0) { setStep("apps"); toast({ title: "Choose at least one app", variant: "destructive" }); return; }
    if (conflicts.length > 0 && saveAnyway !== true) { toast({ title: "Schedule overlap detected", description: "Adjust the time or choose Save anyway." }); return; }
    setSaving(true);
    try {
      const payload = {
        label: label.trim(),
        goal_name: goalName,
        goal_emoji: emoji,
        icon_style: iconStyle,
        apps: selectedApps.map(a => ({ name: a.name, domain: a.domain })),
        days_of_week: days,
        start_time: startTime,
        end_time: endTime,
        reminder_enabled: reminder,
        is_active: true,
      };
      if (editId) {
        await base44.entities.RecurringSchedule.update(editId, payload);
        toast({ title: "Schedule updated ✓" });
      } else {
        const schedule = await base44.entities.RecurringSchedule.create(payload);
        if (lockinFriends.targets.length > 0) {
          const startAt = new Date();
          const [h, m] = startTime.split(":").map(Number);
          startAt.setHours(h, m, 0, 0);
          await lockinFriendsAction("saveLockinFriends", { targets: lockinFriends.targets, helpMode: lockinFriends.helpMode, scheduleId: schedule.id, goalName, category: label || "Lockin", startAt: startAt.toISOString(), timezone: Intl.DateTimeFormat().resolvedOptions().timeZone });
        }
        toast({ title: "Schedule saved ✓" });
      }
      navigate("/schedules");
    } catch {
      toast({ title: "Something went wrong", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const footerButton = (labelText, onClick, disabled = false) => <Button onClick={onClick} disabled={disabled} className="h-12 w-full rounded-2xl font-bold">{labelText}</Button>;

  return (
    <div className="mx-auto flex min-h-screen max-w-lg flex-col px-5 pb-36 pt-8">
      <div className="mb-6 flex items-center gap-3">
        <button onClick={handleBack} className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-muted" aria-label="Go back"><ArrowLeft className="h-5 w-5" /></button>
        <div>
          <h1 className="text-xl font-bold text-foreground">{editId ? "Edit Schedule" : "New Schedule"}</h1>
          <p className="text-xs text-muted-foreground">One decision at a time</p>
        </div>
      </div>

      {step === "template" && (
        <ScheduleFlowShell eyebrow="Step 1" title="What should this Lockin protect?" subtitle="Pick the closest starting point. You can tune details only when they matter." progress={progress}>
          {SCHEDULE_FORM_TEMPLATES.map(tpl => <ScheduleOptionButton key={tpl.id} title={tpl.label} subtitle={tpl.description} onClick={() => chooseTemplate(tpl)} leading={<ScheduleIcon icon={tpl.emoji} styleName={tpl.icon_style || DEFAULT_ICON_STYLE} />} />)}
        </ScheduleFlowShell>
      )}

      {step === "name" && (
        <ScheduleFlowShell eyebrow="Name" title="What should we call this Lockin?" subtitle="A short name keeps it easy to recognize later." progress={progress} footer={footerButton("Continue", goNext, !label.trim())}>
          <div className="rounded-3xl border border-border bg-card p-4">
            <div className="mb-3 flex items-center gap-3"><ScheduleIcon icon={emoji} styleName={iconStyle} /><span className="text-sm font-semibold text-foreground">{template?.label || "Schedule"}</span></div>
            <Input value={label} onChange={e => { setLabel(e.target.value); setFocus(e.target.value); }} placeholder="e.g. Homework Lockin" className="h-12 rounded-2xl" autoFocus />
          </div>
        </ScheduleFlowShell>
      )}

      {step === "days" && (
        <ScheduleFlowShell eyebrow="Days" title="Which days should it run?" subtitle="Choose a simple rhythm. Custom days stay hidden until you need them." progress={progress} footer={footerButton("Continue", goNext, days.length === 0)}>
          {DAY_PRESETS.map(preset => <ScheduleOptionButton key={preset.id} title={preset.label} subtitle={preset.detail} selected={dayMode === preset.id} onClick={() => chooseDayPreset(preset)} leading={<CalendarDays className="h-5 w-5 text-primary" />} />)}
          <ScheduleOptionButton title="Custom days" subtitle={formatDays(days)} selected={dayMode === "custom"} onClick={() => setDayMode("custom")} leading={<Pencil className="h-5 w-5 text-primary" />}>
            {dayMode === "custom" && <div className="grid grid-cols-7 gap-1.5">{DAYS.map((d, i) => <button key={d} type="button" onClick={(event) => { event.stopPropagation(); toggleDay(i); }} className={`rounded-xl py-2.5 text-xs font-semibold transition-all ${days.includes(i) ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>{d}</button>)}</div>}
          </ScheduleOptionButton>
        </ScheduleFlowShell>
      )}

      {step === "time" && (
        <ScheduleFlowShell eyebrow="Time" title="When should it run?" subtitle="Start with a preset, or set an exact window." progress={progress} footer={footerButton("Continue", goNext, !startTime || !endTime)}>
          {TIME_PRESETS.map(preset => <ScheduleOptionButton key={preset.id} title={preset.label} subtitle={preset.detail} selected={timeMode === preset.id} onClick={() => chooseTimePreset(preset)} leading={<Clock className="h-5 w-5 text-primary" />} />)}
          <ScheduleOptionButton title="Custom time" subtitle={`${formatTime(startTime)}–${formatTime(endTime)}`} selected={timeMode === "custom"} onClick={() => setTimeMode("custom")} leading={<Pencil className="h-5 w-5 text-primary" />}>
            {timeMode === "custom" && <div className="grid grid-cols-2 gap-3"><Input type="time" value={startTime} onChange={e => setStartTime(e.target.value)} onClick={e => e.stopPropagation()} className="h-12 rounded-2xl font-semibold" /><Input type="time" value={endTime} onChange={e => setEndTime(e.target.value)} onClick={e => e.stopPropagation()} className="h-12 rounded-2xl font-semibold" /></div>}
          </ScheduleOptionButton>
        </ScheduleFlowShell>
      )}

      {step === "apps" && (
        <ScheduleFlowShell eyebrow="Apps" title="Which apps should be locked?" subtitle="Choose the distractions that get in the way of this Lockin." progress={progress} footer={footerButton(selectedApps.length > 0 ? `Continue with ${selectedApps.length} app${selectedApps.length === 1 ? "" : "s"}` : "Choose at least one app", goNext, selectedApps.length === 0)}>
          <div className="rounded-3xl border border-border bg-card p-4"><AppSearchPicker selected={selectedApps} onToggle={toggleApp} maxHeight="420px" /></div>
        </ScheduleFlowShell>
      )}

      {step === "friends" && (
        <ScheduleFlowShell eyebrow="Optional" title="Would you like Lockin Friends?" subtitle="Keep it private, or invite support when it actually helps." progress={progress} footer={footerButton(showFriendsPicker ? "Continue" : "Skip for now", goNext)}>
          {!showFriendsPicker ? <><ScheduleOptionButton title="Skip for now" subtitle="Fastest path. You can add support later." selected={lockinFriends.targets.length === 0} onClick={goNext} leading={<Users className="h-5 w-5 text-primary" />} /><ScheduleOptionButton title="Add Lockin Friends" subtitle="Private encouragement and celebrations." onClick={() => setShowFriendsPicker(true)} leading={<Users className="h-5 w-5 text-primary" />} /></> : <LockinFriendsStep value={lockinFriends} onChange={setLockinFriends} />}
        </ScheduleFlowShell>
      )}

      {step === "review" && (
        <ScheduleFlowShell eyebrow="Review" title="Ready to save this Lockin?" subtitle="Everything important is here. Customization stays optional." progress={progress} footer={<Button onClick={handleSave} disabled={saving || selectedApps.length === 0 || days.length === 0 || !label.trim()} className="h-12 w-full rounded-2xl font-bold shadow-lg shadow-primary/25">{saving ? "Saving..." : editId ? "Update Schedule" : "Save Schedule"}</Button>}>
          <div className="rounded-3xl border border-border bg-card p-4"><div className="flex items-center gap-3"><ScheduleIcon icon={emoji} styleName={iconStyle} size="lg" /><div><p className="text-lg font-bold text-foreground">{label || "Untitled Lockin"}</p><p className="text-sm text-muted-foreground">{formatDays(days)} · {formatTime(startTime)}–{formatTime(endTime)}</p></div></div></div>
          <ScheduleSummaryCard items={[{ label: "Name", value: label || "Untitled", onClick: () => setStep("name") }, { label: "Days", value: formatDays(days), onClick: () => setStep("days") }, { label: "Time", value: `${formatTime(startTime)}–${formatTime(endTime)}`, onClick: () => setStep("time") }, { label: "Apps", value: `${selectedApps.length} selected`, onClick: () => setStep("apps") }]} />
          <ScheduleConflictWarning conflicts={conflicts} onAdjust={adjustAfterConflict} onSaveAnyway={() => handleSave(true)} saving={saving} />
          <button type="button" onClick={() => setReminder(!reminder)} className="flex w-full items-center justify-between rounded-3xl border border-border bg-card p-4 text-left"><span className="flex items-center gap-3"><Bell className="h-5 w-5 text-primary" /><span><span className="block text-sm font-semibold text-foreground">Reminder</span><span className="block text-xs text-muted-foreground">Notify before it starts</span></span></span><span className={`h-6 w-11 rounded-full p-1 transition-colors ${reminder ? "bg-primary" : "bg-muted-foreground/30"}`}><span className={`block h-4 w-4 rounded-full bg-white transition-transform ${reminder ? "translate-x-5" : "translate-x-0"}`} /></span></button>
          <Button type="button" variant="outline" onClick={() => setCustomizing(!customizing)} className="h-12 w-full rounded-2xl font-semibold">{customizing ? "Hide customization" : "Customize icon"}</Button>
          {customizing && <ScheduleIconPicker value={emoji} styleName={iconStyle} onIconChange={setEmoji} onStyleChange={setIconStyle} />}
          <Button type="button" variant="outline" onClick={() => navigate(sharedLockinSetupUrl({ category: label || "Custom", focus: goalName, start: `${new Date().toISOString().slice(0, 10)}T${startTime}`, end: `${new Date().toISOString().slice(0, 10)}T${endTime}` }))} className="h-12 w-full rounded-2xl font-semibold"><Share2 className="h-4 w-4" /> Invite to Lockin</Button>
        </ScheduleFlowShell>
      )}
    </div>
  );
}