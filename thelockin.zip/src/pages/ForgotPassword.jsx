import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Mail, ArrowLeft, Loader2, InboxIcon } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [submittedEmail, setSubmittedEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const [resendCooldown, setResendCooldown] = useState(0);
  const [resending, setResending] = useState(false);

  useEffect(() => {
    if (!sent) return;
    if (resendCooldown <= 0) return;
    const timer = setInterval(() => {
      setResendCooldown(c => c - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [sent, resendCooldown]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const trimmed = email.trim();
    if (!trimmed) { setError("Please enter your email address."); return; }
    if (!isValidEmail(trimmed)) { setError("Please enter a valid email address."); return; }
    setError("");
    setLoading(true);
    try {
      await base44.auth.resetPasswordRequest(trimmed);
    } catch {
      // Always show success — enumeration protection
    } finally {
      setSubmittedEmail(trimmed);
      setLoading(false);
      setSent(true);
      setResendCooldown(60);
    }
  };

  const handleResend = async () => {
    if (!submittedEmail) return;
    setResending(true);
    try {
      await base44.auth.resetPasswordRequest(submittedEmail);
    } catch {
      // Always show success
    } finally {
      setResending(false);
      setResendCooldown(60);
    }
  };

  return (
    <AuthLayout
      icon={sent ? null : Mail}
      title={sent ? "" : "Reset password"}
      subtitle={sent ? "" : "We'll send you a link to reset it"}
      footer={sent ? null : (
        <Link to="/login" className="text-primary font-medium hover:underline text-sm">
          <ArrowLeft className="w-3 h-3 inline mr-1" />Back to log in
        </Link>
      )}
    >
      {sent ? (
        <div className="space-y-6 text-center animate-in fade-in slide-in-from-bottom-2 duration-300">
          {/* Icon */}
          <div className="relative mx-auto w-fit">
            <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center shadow-sm">
              <InboxIcon className="w-10 h-10 text-primary" />
            </div>
            <div className="absolute -top-1 -right-1 w-7 h-7 rounded-full bg-green-500 text-white flex items-center justify-center text-sm font-bold shadow-md">
              ✓
            </div>
          </div>

          {/* Messaging */}
          <div className="space-y-1.5">
            <h2 className="font-heading font-bold text-xl text-foreground">Almost there!</h2>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-xs mx-auto">
              If an account exists with that email, we'll send reset instructions shortly.
            </p>
          </div>

          {/* Tip cards */}
          <div className="space-y-2 text-left">
            <div className="rounded-xl bg-muted/50 border border-border p-3 flex items-start gap-3">
              <span className="text-lg">📨</span>
              <div>
                <p className="text-xs font-medium text-foreground">Check spam or junk</p>
                <p className="text-xs text-muted-foreground">Sometimes reset emails land there.</p>
              </div>
            </div>
            <div className="rounded-xl bg-muted/50 border border-border p-3 flex items-start gap-3">
              <span className="text-lg">⏳</span>
              <div>
                <p className="text-xs font-medium text-foreground">Give it a few minutes</p>
                <p className="text-xs text-muted-foreground">Delivery can take a little time.</p>
              </div>
            </div>
            <div className="rounded-xl bg-muted/50 border border-border p-3 flex items-start gap-3">
              <span className="text-lg">✏️</span>
              <div>
                <p className="text-xs font-medium text-foreground">Double-check your email</p>
                <p className="text-xs text-muted-foreground">Make sure you used the right address.</p>
              </div>
            </div>
          </div>

          {/* Button hierarchy */}
          <div className="space-y-3 flex flex-col items-center">
            {resendCooldown > 0 ? (
              <p className="text-xs text-muted-foreground">Resend available in {resendCooldown}s</p>
            ) : (
              <Button
                type="button"
                onClick={handleResend}
                disabled={resending || !submittedEmail}
                className="w-full h-12 font-medium rounded-full"
              >
                {resending ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Resending...</> : "Resend Link"}
              </Button>
            )}
            <Link to="/login" className="text-xs text-muted-foreground hover:text-primary transition-colors">
              Back to Login
            </Link>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email address</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
              <Input
                id="email"
                type="email"
                inputMode="email"
                autoComplete="email"
                autoFocus
                placeholder="you@example.com"
                value={email}
                onChange={(e) => { setEmail(e.target.value); if (error) setError(""); }}
                className="pl-10 h-12"
              />
            </div>
            {error && <p className="text-xs text-destructive">{error}</p>}
          </div>
          <Button type="submit" className="w-full h-12 font-medium" disabled={loading}>
            {loading ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Sending...</>
            ) : "Send reset link"}
          </Button>
        </form>
      )}
    </AuthLayout>
  );
}