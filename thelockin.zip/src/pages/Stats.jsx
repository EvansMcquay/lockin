import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useLocation } from "react-router-dom";
import { calculateStreak, calculateLongestStreak, formatDuration } from "@/lib/freedomLockData";
import { getFaviconUrl, findAppDomain } from "@/lib/appLibrary";
import { Flame, Clock, Trophy, Target, Calendar, CheckCircle2, XCircle, Award } from "lucide-react";
import { motion } from "framer-motion";
import EmptyState from "@/components/EmptyState";

export default function Stats() {
  const location = useLocation();
  const [locks, setLocks] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchStats = async () => {
    const data = await base44.entities.AppLock.list("-created_date", 500);
    setLocks(data);
    setLoading(false);
  };

  useEffect(() => {
    if (location.pathname === "/stats") fetchStats();
  }, [location.pathname]);

  const completed = useMemo(() => locks.filter(l => l.status === "completed"), [locks]);
  const streak = useMemo(() => calculateStreak(locks), [locks]);
  const longestStreak = useMemo(() => calculateLongestStreak(locks), [locks]);
  const totalHours = useMemo(() => completed.reduce((s, l) => s + (l.duration_minutes || 0), 0) / 60, [completed]);

  const todayCompleted = useMemo(() => {
    const today = new Date().toDateString();
    return completed.filter(l => new Date(l.locked_at).toDateString() === today);
  }, [completed]);

  const todayNotCompleted = useMemo(() => {
    const today = new Date().toDateString();
    return locks.filter(l =>
      l.status === "active" &&
      new Date(l.unlocks_at) < new Date() &&
      new Date(l.locked_at).toDateString() === today
    );
  }, [locks]);

  const weekCompleted = useMemo(() => {
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    return completed.filter(l => new Date(l.locked_at) >= weekAgo);
  }, [completed]);

  const weekMissed = useMemo(() => {
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    return locks.filter(l =>
      l.status === "active" &&
      new Date(l.unlocks_at) < new Date() &&
      new Date(l.locked_at) >= weekAgo
    );
  }, [locks]);

  const perfectDays = useMemo(() => {
    const today = new Date();
    const days = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const dayLocks = completed.filter(l => new Date(l.locked_at).toDateString() === d.toDateString());
      if (dayLocks.length > 0) days.push(d.toDateString());
    }
    return days.length;
  }, [completed]);

  const appBreakdown = useMemo(() => {
    const map = {};
    completed.forEach(l => {
      if (!map[l.app_name]) map[l.app_name] = { name: l.app_name, count: 0 };
      map[l.app_name].count++;
    });
    return Object.values(map).sort((a, b) => b.count - a.count).slice(0, 5);
  }, [completed]);

  const goalsCompleted = useMemo(() => {
    return completed.filter(l => l.goal_outcome === "yes" || l.goal_outcome === "mostly").length;
  }, [completed]);

  if (loading) {
    return (
      <div className="max-w-lg mx-auto px-5 py-8 space-y-4">
        <div className="h-8 w-40 rounded-lg bg-muted animate-pulse" />
        <div className="h-28 rounded-2xl bg-muted animate-pulse" />
        <div className="h-28 rounded-2xl bg-muted animate-pulse" />
        <div className="grid grid-cols-2 gap-3">
          <div className="h-24 rounded-2xl bg-muted animate-pulse" />
          <div className="h-24 rounded-2xl bg-muted animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto px-5 py-8 space-y-6" style={{ paddingBottom: "calc(var(--safe-area-bottom) + 2rem)" }}>
      <div>
        <h1 className="font-heading font-semibold text-[32px] text-foreground leading-tight">Your Progress</h1>
        <p className="text-sm text-muted-foreground">Your protected time at a glance.</p>
      </div>

      {completed.length === 0 ? (
        <EmptyState
          icon="🌱"
          title="No Progress Yet"
          message="Complete your first Lockin to begin tracking your accomplishments."
          actionLabel="Start a Lockin"
          actionTo="/lockin-setup"
        />
      ) : (
        <>
          {/* Streaks hero */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-2 gap-3"
          >
            <div className="rounded-[20px] bg-primary p-5 text-primary-foreground shadow-lg shadow-primary/20">
              <Flame className="w-6 h-6 mb-2" />
              <p className="text-3xl font-heading font-bold">{streak}</p>
              <p className="text-xs text-primary-foreground/80 mt-0.5">Current streak</p>
            </div>
            <div className="rounded-[20px] bg-card border border-border p-5 text-foreground shadow-sm">
              <Trophy className="w-6 h-6 mb-2" />
              <p className="text-3xl font-heading font-bold">{longestStreak}</p>
              <p className="text-xs text-accent-foreground/80 mt-0.5">Longest streak</p>
            </div>
          </motion.div>

          {/* Today */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3">Today</p>
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-2xl bg-card border border-border p-4">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                  <span className="text-xs text-muted-foreground">Completed</span>
                </div>
                <p className="text-2xl font-heading font-bold text-foreground">{todayCompleted.length}</p>
              </div>
              <div className="rounded-2xl bg-card border border-border p-4">
                <div className="flex items-center gap-2 mb-1">
                  <XCircle className="w-4 h-4 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">Not Completed</span>
                </div>
                <p className="text-2xl font-heading font-bold text-foreground">{todayNotCompleted.length}</p>
              </div>
            </div>
          </div>

          {/* This Week */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3">This Week</p>
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-2xl bg-card border border-border p-4">
                <div className="flex items-center gap-2 mb-1">
                  <Target className="w-4 h-4 text-primary" />
                  <span className="text-xs text-muted-foreground">Completed</span>
                </div>
                <p className="text-2xl font-heading font-bold text-foreground">{weekCompleted.length}</p>
              </div>
              <div className="rounded-2xl bg-card border border-border p-4">
                <div className="flex items-center gap-2 mb-1">
                  <XCircle className="w-4 h-4 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">Missed</span>
                </div>
                <p className="text-2xl font-heading font-bold text-foreground">{weekMissed.length}</p>
              </div>
              <div className="rounded-2xl bg-card border border-border p-4">
                <div className="flex items-center gap-2 mb-1">
                  <Calendar className="w-4 h-4 text-accent" />
                  <span className="text-xs text-muted-foreground">Perfect Days</span>
                </div>
                <p className="text-2xl font-heading font-bold text-foreground">{perfectDays}</p>
              </div>
              <div className="rounded-2xl bg-card border border-border p-4">
                <div className="flex items-center gap-2 mb-1">
                  <Flame className="w-4 h-4 text-amber-500" />
                  <span className="text-xs text-muted-foreground">Streak</span>
                </div>
                <p className="text-2xl font-heading font-bold text-foreground">{streak}</p>
              </div>
            </div>
          </div>

          {/* Hours reclaimed */}
          <div className="rounded-2xl bg-card border border-border p-5 flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Clock className="w-6 h-6 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-heading font-bold text-foreground">{totalHours.toFixed(1)}h</p>
              <p className="text-sm text-muted-foreground">Hours protected</p>
            </div>
          </div>

          {/* Most blocked apps */}
          {appBreakdown.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3">Most Blocked Apps</p>
              <div className="space-y-2">
                {appBreakdown.map((app, i) => {
                  const domain = findAppDomain(app.name);
                  return (
                    <div key={app.name} className="flex items-center gap-3 rounded-2xl bg-card border border-border p-3">
                      <span className="text-sm font-bold text-muted-foreground w-5">#{i + 1}</span>
                      {domain ? (
                        <img src={getFaviconUrl(domain)} alt="" className="w-7 h-7 rounded-lg" onError={e => { e.target.style.display = "none"; }} />
                      ) : (
                        <span className="w-7 h-7 rounded-lg bg-muted flex items-center justify-center text-sm">📱</span>
                      )}
                      <span className="text-sm font-medium text-foreground flex-1 truncate">{app.name}</span>
                      <span className="text-sm font-bold text-primary">{app.count}×</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Achievements */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3">Achievements</p>
            <div className="space-y-2">
              {ACHIEVEMENTS.map(achievement => {
                const earned = achievement.check(locks, streak, []);
                return (
                  <div
                    key={achievement.id}
                    className={`flex items-center gap-3 rounded-2xl border p-4 transition-all ${
                      earned ? "bg-card border-accent/30" : "bg-muted/30 border-border opacity-60"
                    }`}
                  >
                    <span className="text-2xl">{achievement.icon}</span>
                    <div className="flex-1">
                      <p className={`text-sm font-semibold ${earned ? "text-foreground" : "text-muted-foreground"}`}>
                        {achievement.name}
                      </p>
                      <p className="text-xs text-muted-foreground">{achievement.description}</p>
                    </div>
                    {earned && <Award className="w-4 h-4 text-accent" />}
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

const ACHIEVEMENTS = [
  { id: "first_lock", icon: "🔒", name: "First Lock", description: "Complete your first lock.", check: (locks) => locks.filter(l => l.status === "completed").length >= 1 },
  { id: "focus_apprentice", icon: "🎯", name: "Focus Apprentice", description: "10 successful locks.", check: (locks) => locks.filter(l => l.status === "completed").length >= 10 },
  { id: "discipline_builder", icon: "📅", name: "Discipline Builder", description: "Achieve a 7-day streak.", check: (locks, streak) => streak >= 7 },
  { id: "iron_mind", icon: "🧠", name: "Iron Mind", description: "Achieve a 30-day streak.", check: (locks, streak) => streak >= 30 },
  { id: "unbreakable", icon: "💪", name: "Unbreakable", description: "100 successful locks.", check: (locks) => locks.filter(l => l.status === "completed").length >= 100 },
];