import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Link, useLocation } from "react-router-dom";
import { ChevronRight, Settings } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import PullToRefresh from "@/components/PullToRefresh";
import SettingsModal from "@/components/SettingsModal";
import LockTransition from "@/components/LockTransition";
import HomeActiveLockinCard from "@/components/dashboard/HomeActiveLockinCard";
import HomeNextLockinCard from "@/components/dashboard/HomeNextLockinCard";
import HomeTodayProgress from "@/components/dashboard/HomeTodayProgress";
import { useToast } from "@/components/ui/use-toast";
import { hasActiveLockSession } from "@/lib/activeSessions";
import { circleAction } from "@/lib/circlesApi";

function getDateKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function getLockSessionKey(lock) {
  return lock.lock_session_key || `${lock.goal_name || lock.app_name}-${lock.locked_at}-${lock.unlocks_at}`;
}

function getCompletedSessionsByDay(locks) {
  const sessionsByDay = new Map();
  locks
    .filter(lock => !lock.archived_at && lock.status === "completed" && lock.unlocks_at)
    .forEach(lock => {
      const dayKey = getDateKey(new Date(lock.unlocks_at));
      if (!sessionsByDay.has(dayKey)) sessionsByDay.set(dayKey, new Map());
      const daySessions = sessionsByDay.get(dayKey);
      const sessionKey = getLockSessionKey(lock);
      if (!daySessions.has(sessionKey)) daySessions.set(sessionKey, lock);
    });
  return sessionsByDay;
}

function getMinutesUntil(timeStr) {
  const [h, m] = timeStr.split(":").map(Number);
  const now = new Date();
  const target = new Date();
  target.setHours(h, m, 0, 0);
  return Math.round((target - now) / 60000);
}

function getScheduleStartTime(sched) {
  const [h, m] = sched.start_time.split(":").map(Number);
  const date = new Date();
  date.setHours(h, m, 0, 0);
  return date.getTime();
}

function getScheduleEndTime(sched) {
  const start = getScheduleStartTime(sched);
  const [h, m] = sched.end_time.split(":").map(Number);
  const date = new Date();
  date.setHours(h, m, 0, 0);
  if (date.getTime() <= start) date.setDate(date.getDate() + 1);
  return date.getTime();
}

function isSameLockSession(candidate, anchor) {
  if (candidate.id === anchor.id) return true;
  if (candidate.goal_name !== anchor.goal_name) return false;
  const lockedDiff = Math.abs(new Date(candidate.locked_at).getTime() - new Date(anchor.locked_at).getTime());
  const unlockDiff = Math.abs(new Date(candidate.unlocks_at).getTime() - new Date(anchor.unlocks_at).getTime());
  return lockedDiff < 60000 && unlockDiff < 60000;
}

export default function Home() {
  const location = useLocation();
  const [locks, setLocks] = useState([]);
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [startingId, setStartingId] = useState(null);
  const [transition, setTransition] = useState(null);
  const { toast } = useToast();

  const fetchData = async () => {
    const [allLocks, allSchedules] = await Promise.all([
      base44.entities.AppLock.list("-created_date", 200),
      base44.entities.RecurringSchedule.list("-created_date", 50),
    ]);
    setLocks(allLocks);
    setSchedules(allSchedules);
    setLoading(false);
  };

  useEffect(() => {
    if (location.pathname === "/") fetchData();
  }, [location.pathname]);

  const activeLocks = useMemo(
    () => locks.filter(lock => !lock.archived_at && lock.status === "active" && new Date(lock.unlocks_at) > new Date()),
    [locks]
  );

  const activeSession = useMemo(
    () => activeLocks.find((lock, index, list) => list.findIndex(item => isSameLockSession(item, lock)) === index),
    [activeLocks]
  );

  const todayDay = new Date().getDay();
  const todayKey = getDateKey();

  const todaySchedules = useMemo(
    () => schedules.filter(schedule => !schedule.deleted_at && schedule.is_active !== false && schedule.days_of_week?.includes(todayDay) && !schedule.skip_dates?.includes(todayKey)),
    [schedules, todayDay, todayKey]
  );

  const nextLockin = useMemo(() => {
    const now = Date.now();
    return todaySchedules
      .map(sched => {
        const scheduleStart = getScheduleStartTime(sched);
        const scheduleEnd = getScheduleEndTime(sched);
        const scheduleGoal = sched.goal_name || sched.label;
        const completed = locks.some(lock => {
          if (lock.archived_at || lock.status !== "completed" || lock.goal_name !== scheduleGoal) return false;
          const lockedAt = new Date(lock.locked_at).getTime();
          const unlocksAt = new Date(lock.unlocks_at).getTime();
          return (lockedAt >= scheduleStart && lockedAt < scheduleEnd) || (unlocksAt > scheduleStart && unlocksAt <= scheduleEnd);
        });
        return { sched, scheduleStart, scheduleEnd, minsUntil: getMinutesUntil(sched.start_time), completed };
      })
      .filter(item => !item.completed && item.scheduleEnd > now)
      .sort((a, b) => Math.max(0, a.minsUntil) - Math.max(0, b.minsUntil))[0];
  }, [todaySchedules, locks]);

  const todayProgress = useMemo(() => {
    const sessionsByDay = getCompletedSessionsByDay(locks);
    const todaySessions = Array.from(sessionsByDay.get(todayKey)?.values() || []);
    let currentStreak = 0;
    const day = new Date();
    while (sessionsByDay.has(getDateKey(day))) {
      currentStreak += 1;
      day.setDate(day.getDate() - 1);
    }
    return {
      completedLockins: todaySessions.length,
      currentStreak,
      focusMinutes: todaySessions.reduce((total, lock) => total + (lock.duration_minutes || 0), 0),
    };
  }, [locks, todayKey]);

  const startScheduledSession = async (sched) => {
    if (!sched.apps || sched.apps.length === 0) return;
    if (navigator.vibrate) navigator.vibrate(10);
    setStartingId(sched.id);
    try {
      const now = new Date();
      const recentLocks = await base44.entities.AppLock.list("-created_date", 50);
      if (hasActiveLockSession(recentLocks)) {
        toast({ title: "Lockin already active", description: "Finish your current session before starting another." });
        return;
      }
      const [eh, em] = sched.end_time.split(":").map(Number);
      const endTime = new Date();
      endTime.setHours(eh, em, 0, 0);
      if (endTime <= now) endTime.setDate(endTime.getDate() + 1);
      const durationMinutes = Math.max(1, Math.round((endTime - now) / 60000));
      const sessionKey = sched.shared_lockin_id || `${sched.id}-${now.toISOString()}`;
      const createdLocks = await Promise.all(sched.apps.map(app =>
        base44.entities.AppLock.create({
          app_name: app.name,
          app_icon: "📱",
          goal_name: sched.goal_name || sched.label,
          goal_emoji: sched.goal_emoji || "🎯",
          icon_style: sched.icon_style || "colorful",
          duration_minutes: durationMinutes,
          severity_level: "stay_focused",
          locked_at: now.toISOString(),
          unlocks_at: endTime.toISOString(),
          status: "active",
          hardcore_mode: false,
          lock_session_key: sessionKey,
          schedule_id: sched.id,
          lockin_category: sched.label?.replace(" Lockin", "") || sched.goal_name || "Lockin",
          shared_lockin_id: sched.shared_lockin_id,
          shared_circle_id: sched.shared_circle_id,
        })
      ));
      if (sched.shared_lockin_id) await circleAction("markSharedLockinStarted", { sharedLockinId: sched.shared_lockin_id }).catch(() => null);
      setLocks(prev => [...createdLocks, ...prev.filter(lock => !createdLocks.some(created => created.id === lock.id))]);
      setTransition({ emoji: sched.goal_emoji || "🎯", goalName: sched.goal_name || sched.label });
    } catch {
      toast({ title: "Something went wrong", variant: "destructive" });
    } finally {
      setStartingId(null);
    }
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-lg px-6 py-8 space-y-5">
        <div className="h-7 w-48 rounded-xl bg-muted animate-pulse" />
        <div className="h-44 rounded-[24px] bg-muted animate-pulse" />
        <div className="h-14 rounded-2xl bg-muted animate-pulse" />
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={fetchData}>
      <div className="mx-auto flex max-w-lg flex-col gap-3 px-6 py-3">
        <AnimatePresence>
          {transition && (
            <LockTransition
              emoji={transition.emoji}
              goalName={transition.goalName}
              onComplete={() => {
                setTransition(null);
                fetchData();
              }}
            />
          )}
        </AnimatePresence>

        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-primary">Right now</p>
            <h1 className="mt-1 font-heading text-[26px] font-semibold leading-tight text-foreground">What should I be doing?</h1>
          </div>
          <button
            onClick={() => setSettingsOpen(true)}
            className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-2xl border border-border bg-card text-muted-foreground"
          >
            <Settings className="h-4 w-4" />
          </button>
        </div>

        <main className="flex flex-col gap-4">
          {activeSession ? (
            <HomeActiveLockinCard lock={activeSession} allActiveLocks={activeLocks} />
          ) : nextLockin ? (
            <HomeNextLockinCard item={nextLockin} onStart={() => startScheduledSession(nextLockin.sched)} isStarting={startingId === nextLockin.sched.id} />
          ) : (
            <section className="rounded-[24px] border border-border bg-card/95 p-5 text-center shadow-lg shadow-black/5">
              <p className="font-heading text-xl font-semibold text-foreground">Nothing scheduled today.</p>
              <p className="mt-2 text-sm text-muted-foreground">You can still lock in whenever you are ready.</p>
              <Link to="/schedule-builder" className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-2xl border border-border bg-secondary px-4 py-3 text-sm font-bold text-foreground">
                Create Schedule
                <ChevronRight className="h-4 w-4" />
              </Link>
            </section>
          )}
        </main>

        <Link to="/lockin-setup" className="block">
          <motion.div
            whileTap={{ scale: 0.97 }}
            className="flex items-center justify-between rounded-[22px] bg-primary px-5 py-4 text-primary-foreground shadow-lg shadow-primary/25"
          >
            <span className="font-heading text-lg font-bold">Start Lockin</span>
            <ChevronRight className="h-5 w-5" />
          </motion.div>
        </Link>

        <HomeTodayProgress stats={todayProgress} />

        <SettingsModal open={settingsOpen} onClose={() => setSettingsOpen(false)} />
      </div>
    </PullToRefresh>
  );
}