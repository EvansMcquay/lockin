import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Bell, Check, Pencil, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import AppSearchPicker from "@/components/AppSearchPicker";
import { useToast } from "@/components/ui/use-toast";
import { circleAction } from "@/lib/circlesApi";
import SilentGroupSessionPanel from "@/components/circles/SilentGroupSessionPanel";
import QuickReschedulePanel from "@/components/circles/QuickReschedulePanel";

function formatTime(iso) { return new Date(iso).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }); }
function timeRemaining(endAt) {
  const ms = Math.max(0, new Date(endAt) - new Date());
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  if (hours > 0) return `${hours} hour${hours === 1 ? "" : "s"} ${minutes} minutes`;
  return `${minutes} minutes`;
}
const statusLabel = { invited: "Invited", joined: "Joined", ready: "Ready", locked_in: "Locked In", completed: "Completed", declined: "Invited" };

export default function SharedLockinDetail() {
  const id = window.location.pathname.split("/").pop();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [data, setData] = useState(null);
  const [apps, setApps] = useState([]);
  const [focus, setFocus] = useState("");
  const [saving, setSaving] = useState(false);
  const [editingApps, setEditingApps] = useState(false);

  const load = async () => {
    const res = await circleAction("getSharedLockin", { sharedLockinId: id });
    setData(res);
    setFocus(res.sharedLockin.current_participant?.private_focus || res.sharedLockin.focus || "");
    setApps(res.sharedLockin.current_participant?.apps || []);
  };

  useEffect(() => {
    let alive = true;
    const refresh = () => load().catch(e => alive && toast({ title: e?.response?.data?.error || "Could not load invite", variant: "destructive" }));
    refresh();
    const timer = setInterval(refresh, 15000);
    return () => { alive = false; clearInterval(timer); };
  }, [id]);

  const toggleApp = app => setApps(prev => prev.find(a => a.name === app.name) ? prev.filter(a => a.name !== app.name) : [...prev, app]);
  const call = async (action, payload, success) => {
    setSaving(true);
    try {
      await circleAction(action, payload);
      if (success) toast({ title: success });
      await load();
    } catch (e) {
      toast({ title: e?.response?.data?.error || "Could not update Lockin", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };
  const respond = decision => call("respondSharedLockinInvite", { participantId: data.sharedLockin.current_participant.id, decision, apps, privateFocus: focus }, decision === "decline" ? "Invite declined." : "Joined Lockin.");
  const saveApps = async () => { await call("updateSharedParticipantApps", { sharedLockinId: id, apps, privateFocus: focus }, "Your apps were saved privately."); setEditingApps(false); };
  const askPush = () => call("askForEncouragement", { sharedLockinId: id }, "Friends notified privately.");
  const remind = participant => call("sendAccountabilityReminder", { sharedLockinId: id, participantId: participant.id, message: "You got this" }, "Reminder sent.");
  const pulse = payload => call("sendSharedPulse", { sharedLockinId: id, ...payload }, "Sent quietly.");
  const updateStatus = status => call("updateSharedParticipantStatus", { sharedLockinId: id, status }, status === "ready" ? "Marked ready." : "Status updated.");
  const reschedule = (start, end) => call("rescheduleSharedLockin", { sharedLockinId: id, startAt: start.toISOString(), endAt: end.toISOString() }, "Lockin rescheduled.");

  if (!data) return <div className="min-h-screen flex items-center justify-center"><div className="w-8 h-8 rounded-full border-4 border-muted border-t-primary animate-spin" /></div>;

  const item = data.sharedLockin;
  const current = item.current_participant;
  const isCreator = item.creator_id === current?.user_id;
  const active = item.is_active_now || item.status === "active";
  const canJoin = current?.status === "invited";
  const alreadyStarted = new Date(item.start_at) <= new Date();
  const lateBlocked = alreadyStarted && !item.late_joining && current?.status === "invited";
  const canEditApps = current && ["joined", "ready", "locked_in"].includes(current.status);
  const joinedCount = item.participants.filter(p => ["joined", "ready", "locked_in", "completed"].includes(p.status)).length;

  return <div className="max-w-lg mx-auto px-5 py-6 space-y-5">
    <button onClick={() => navigate(-1)} className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground"><ArrowLeft className="w-4 h-4" /> Back</button>

    <section className="rounded-3xl border border-border bg-card p-5 space-y-3">
      <p className="text-xs font-semibold uppercase tracking-widest text-primary">Silent Group Lockin</p>
      <h1 className="font-heading font-bold text-2xl text-foreground">{item.title}</h1>
      {item.focus && <p className="text-sm text-muted-foreground">{item.focus}</p>}
      <p className="text-sm text-foreground">{new Date(item.start_at).toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" })} · {formatTime(item.start_at)} – {formatTime(item.end_at)}</p>
      <p className="text-xs text-muted-foreground">Circle: {data.circle.name} · {active ? `Time remaining: ${timeRemaining(item.end_at)}` : `Starts at ${formatTime(item.start_at)}`}</p>
      {lateBlocked && <p className="rounded-2xl bg-muted p-3 text-sm text-muted-foreground">This Lockin has already started.</p>}
    </section>

    <SilentGroupSessionPanel item={item} active={active} pulses={item.pulses || []} onStatus={updateStatus} onPulse={pulse} />

    {!active && isCreator && item.allow_early_start !== false && <Button onClick={() => call("startSharedLockinEarly", { sharedLockinId: id }, "Lockin started early.")} disabled={saving} className="w-full rounded-2xl">Start Early</Button>}
    {!active && current && !isCreator && ["joined", "ready"].includes(current.status) && <Button variant="outline" onClick={() => call("leaveSharedLockinSession", { sharedLockinId: id }, "You left this session.")} disabled={saving} className="w-full rounded-2xl">Leave Session</Button>}

    {canJoin && !lateBlocked && <section className="rounded-3xl border border-border bg-card p-4 space-y-4">
      <h2 className="font-heading font-bold text-lg text-foreground">Join Lockin</h2>
      <Input value={focus} onChange={e => setFocus(e.target.value)} placeholder="Private focus" className="rounded-2xl" />
      <AppSearchPicker selected={apps} onToggle={toggleApp} />
      <div className="grid grid-cols-2 gap-2"><Button variant="outline" onClick={() => respond("decline")} disabled={saving} className="rounded-2xl"><X className="w-4 h-4" /> Decline</Button><Button onClick={() => respond("accept")} disabled={saving || apps.length === 0} className="rounded-2xl"><Check className="w-4 h-4" /> Join Lockin</Button></div>
      <p className="text-xs text-muted-foreground text-center">Your apps and private focus stay private.</p>
    </section>}

    {canEditApps && <section className="rounded-3xl border border-border bg-card p-4 space-y-3">
      <div className="flex items-center justify-between gap-3"><div><h2 className="font-heading font-bold text-lg text-foreground">My Lockin Setup</h2><p className="text-xs text-muted-foreground">Only you can see your locked apps.</p></div><Button size="sm" variant="outline" onClick={() => setEditingApps(!editingApps)} className="rounded-full"><Pencil className="w-3 h-3" /> Edit</Button></div>
      <p className="text-sm text-foreground">Goal: {focus || item.focus || item.title}</p>
      <p className="text-sm text-muted-foreground">{apps.length ? apps.map(app => app.name).join(" · ") : "No apps selected yet"}</p>
      {editingApps && <div className="space-y-3"><Input value={focus} onChange={e => setFocus(e.target.value)} placeholder="Private focus" className="rounded-2xl" /><AppSearchPicker selected={apps} onToggle={toggleApp} /><Button onClick={saveApps} disabled={saving || apps.length === 0} className="w-full rounded-2xl">Save My Apps</Button></div>}
    </section>}

    <section className="rounded-3xl border border-border bg-card p-4 space-y-3">
      <h2 className="font-heading font-bold text-lg text-foreground">Participants</h2>
      {item.participants.map(p => <div key={p.id} className="flex items-center justify-between gap-3 rounded-2xl bg-muted/50 p-3"><div><p className="text-sm font-semibold text-foreground">{p.display_name}</p><p className="text-xs text-muted-foreground">@{p.username} · {statusLabel[p.status] || "Joined"}</p></div><div className="flex gap-2">{p.user_id !== current?.user_id && p.status === "invited" && <Button size="sm" variant="outline" onClick={() => remind(p)} className="rounded-full"><Bell className="w-3 h-3" /> Remind</Button>}{isCreator && p.user_id !== current?.user_id && ["invited", "declined"].includes(p.status) && <Button size="sm" variant="outline" onClick={() => call(p.status === "declined" ? "inviteSharedParticipantAgain" : "removeSharedParticipant", { participantId: p.id }, p.status === "declined" ? "Invited again." : "Removed from this session.")} className="rounded-full">{p.status === "declined" ? "Invite Again" : "Remove"}</Button>}</div></div>)}
      <p className="text-xs text-muted-foreground">{joinedCount} participant{joinedCount === 1 ? "" : "s"} joined. Invited members who do not join are not shown as failures.</p>
    </section>

    {isCreator && <QuickReschedulePanel item={item} onReschedule={reschedule} />}

    <div className="grid grid-cols-2 gap-2"><Button variant="outline" onClick={askPush} className="rounded-2xl">Ask for a Push</Button><Button asChild variant="outline" className="rounded-2xl"><Link to="/lockin-setup">Start Yours</Link></Button></div>
  </div>;
}