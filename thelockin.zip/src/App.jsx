import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ProtectedRoute from '@/components/ProtectedRoute';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import About from '@/pages/About';
import Contact from '@/pages/Contact';
import AppLayout from '@/components/layout/AppLayout';
import Home from '@/pages/Home';
import QuickLockinSetup from '@/pages/QuickLockinSetup';
import Stats from '@/pages/Stats';
import Locks from '@/pages/Locks';
import SessionComplete from '@/pages/SessionComplete';
import Schedules from '@/pages/Schedules';
import ScheduleBuilder from '@/pages/ScheduleBuilder';
import Circles from '@/pages/Circles';
import CircleDetail from '@/pages/CircleDetail';
import SharedLockinSetup from '@/pages/SharedLockinSetup';
import SharedLockinDetail from '@/pages/SharedLockinDetail';
import Onboarding from '@/pages/Onboarding';
import ThemeProvider from '@/components/ThemeProvider';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route path="/onboarding" element={<Onboarding />} />
        <Route element={<AppLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/lockin-setup" element={<QuickLockinSetup />} />
          <Route path="/stats" element={<Stats />} />
          <Route path="/locks" element={<Locks />} />
          <Route path="/session-complete" element={<SessionComplete />} />
          <Route path="/schedules" element={<Schedules />} />
          <Route path="/schedule-builder" element={<ScheduleBuilder />} />
          <Route path="/circles" element={<Circles />} />
          <Route path="/circles/:id" element={<CircleDetail />} />
          <Route path="/shared-lockin/new" element={<SharedLockinSetup />} />
          <Route path="/shared-lockin/:id" element={<SharedLockinDetail />} />
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <QueryClientProvider client={queryClientInstance}>
          <Router>
            <AuthenticatedApp />
          </Router>
          <Toaster />
        </QueryClientProvider>
      </AuthProvider>
    </ThemeProvider>
  )
}

export default App