import React, { useState } from "react";
import { Search, Check, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { searchApps, getFaviconUrl } from "@/lib/appLibrary";

function AppIcon({ domain, name }) {
  const [imgError, setImgError] = useState(false);
  if (imgError || !domain) {
    return (
      <span className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center text-base flex-shrink-0">
        📱
      </span>
    );
  }
  return (
    <img
      src={getFaviconUrl(domain)}
      alt={name}
      className="w-8 h-8 rounded-lg object-cover flex-shrink-0"
      onError={() => setImgError(true)}
    />
  );
}

export default function AppSearchPicker({ selected = [], onToggle, maxHeight = "320px" }) {
  const [query, setQuery] = useState("");
  const filtered = searchApps(query);

  return (
    <div className="space-y-3">
      {selected.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {selected.map(app => (
            <button
              key={app.name}
              onClick={() => onToggle(app)}
              className="flex items-center gap-1.5 bg-primary text-primary-foreground px-3 py-1.5 rounded-xl text-xs font-medium active:scale-95 transition-transform"
            >
              {app.domain && (
                <img
                  src={getFaviconUrl(app.domain)}
                  alt=""
                  className="w-4 h-4 rounded"
                  onError={e => { e.target.style.display = "none"; }}
                />
              )}
              {app.name}
              <X className="w-3 h-3" />
            </button>
          ))}
        </div>
      )}

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
        <Input
          placeholder="Search apps to block..."
          value={query}
          onChange={e => setQuery(e.target.value)}
          className="pl-9 rounded-2xl h-11"
        />
      </div>

      <div className="space-y-1 overflow-y-auto" style={{ maxHeight }}>
        {filtered.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            No apps found. Try a different search.
          </p>
        ) : (
          filtered.map(app => {
            const isSelected = selected.some(a => a.name === app.name);
            return (
              <button
                key={app.name}
                onClick={() => onToggle(app)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all active:scale-[0.98] border ${
                  isSelected
                    ? "bg-primary/10 border-primary/30"
                    : "hover:bg-muted border-transparent"
                }`}
              >
                <AppIcon domain={app.domain} name={app.name} />
                <span className="flex-1 text-left text-sm font-medium text-foreground">{app.name}</span>
                {isSelected && (
                  <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                    <Check className="w-3.5 h-3.5 text-primary-foreground" />
                  </div>
                )}
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}