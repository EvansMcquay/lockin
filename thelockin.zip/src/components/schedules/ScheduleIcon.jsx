import React from "react";
import { DEFAULT_ICON_STYLE, DEFAULT_SCHEDULE_ICON } from "@/lib/scheduleIcons";

const SIZE_CLASSES = {
  sm: "w-10 h-10 text-lg rounded-2xl",
  md: "w-12 h-12 text-xl rounded-2xl",
  picker: "w-12 h-12 text-2xl rounded-2xl",
  lg: "w-14 h-14 text-2xl rounded-[20px]",
};

const STYLE_CLASSES = {
  minimal: "bg-secondary border border-border text-foreground shadow-sm",
  colorful: "bg-primary/10 border border-primary/15 text-primary shadow-sm shadow-primary/10",
  playful: "bg-accent/10 border border-accent/15 text-accent shadow-sm shadow-accent/10",
  modern: "bg-secondary border border-border text-foreground shadow-sm",
};

const ACTIVE_CLASSES = {
  minimal: "bg-white/10 border border-white/15 text-white",
  colorful: "bg-white/10 border border-white/15 text-white",
  playful: "bg-white/10 border border-white/15 text-white",
  modern: "bg-white/10 border border-white/15 text-white",
};

export default function ScheduleIcon({ icon, styleName, size = "md", active = false, className = "" }) {
  const safeStyle = styleName || DEFAULT_ICON_STYLE;
  return (
    <span className={`relative flex items-center justify-center flex-shrink-0 ${SIZE_CLASSES[size] || SIZE_CLASSES.md} ${active ? ACTIVE_CLASSES[safeStyle] || ACTIVE_CLASSES.colorful : STYLE_CLASSES[safeStyle] || STYLE_CLASSES.colorful} ${className}`}>
      <span className="leading-none transition-transform duration-200 group-active:scale-95">{icon || DEFAULT_SCHEDULE_ICON}</span>
    </span>
  );
}