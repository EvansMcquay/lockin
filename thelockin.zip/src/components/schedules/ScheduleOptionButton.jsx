import React from "react";
import { Check, ChevronRight } from "lucide-react";

export default function ScheduleOptionButton({ title, subtitle, leading, selected = false, onClick, children }) {
  const className = `w-full rounded-3xl border p-4 text-left transition-all active:scale-[0.98] ${selected ? "border-primary bg-primary/10 shadow-sm shadow-primary/10" : "border-border bg-card hover:border-primary/30"}`;
  const content = (
    <>
      <div className="flex items-center gap-3">
        {leading}
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-foreground">{title}</p>
          {subtitle && <p className="mt-1 text-xs leading-5 text-muted-foreground">{subtitle}</p>}
        </div>
        {selected ? <Check className="h-4 w-4 flex-shrink-0 text-primary" /> : <ChevronRight className="h-4 w-4 flex-shrink-0 text-muted-foreground" />}
      </div>
      {children && <div className="mt-3">{children}</div>}
    </>
  );

  if (children) {
    return <div role="button" tabIndex={0} onClick={onClick} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") onClick?.(event); }} className={className}>{content}</div>;
  }

  return <button type="button" onClick={onClick} className={className}>{content}</button>;
}