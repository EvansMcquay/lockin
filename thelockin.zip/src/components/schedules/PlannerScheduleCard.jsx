import React, { useState } from "react";
import { Link } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Bell, Calendar, CalendarX, ChevronDown, Clock, Pencil, Trash2 } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import ScheduleIcon from "@/components/schedules/ScheduleIcon";
import { getFaviconUrl } from "@/lib/appLibrary";

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export default function PlannerScheduleCard({ schedule, onToggleActive, onSkipToday, onDelete, formatTime, formatDays }) {
  const [expanded, setExpanded] = useState(false);
  const isActive = schedule.is_active !== false;
  const apps = schedule.apps || [];

  return (
    <motion.article layout className="rounded-2xl bg-card border border-border overflow-hidden">
      <button onClick={() => setExpanded(!expanded)} className="w-full text-left p-4 active:scale-[0.99] transition-transform">
        <div className="flex items-start gap-3">
          <ScheduleIcon icon={schedule.goal_emoji} styleName={schedule.icon_style} />
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <h4 className="font-heading font-bold text-sm text-foreground truncate">{schedule.label}</h4>
                <p className="text-xs text-muted-foreground truncate mt-0.5">{schedule.goal_name || "Today's goal"}</p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <span className={`text-[11px] font-semibold rounded-full px-2 py-0.5 ${isActive ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>{isActive ? "On" : "Paused"}</span>
                <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${expanded ? "rotate-180" : ""}`} />
              </div>
            </div>
            <div className="mt-3 flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
              <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{formatTime(schedule.start_time)} – {formatTime(schedule.end_time)}</span>
              <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{formatDays(schedule.days_of_week)}</span>
            </div>
          </div>
        </div>
      </button>

      <AnimatePresence initial={false}>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="overflow-hidden"
          >
            <div className="mx-4 mb-4 rounded-2xl bg-muted/60 p-3 space-y-4">
              <div>
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-widest mb-2">Repeats on</p>
                <div className="flex flex-wrap gap-1.5">
                  {DAYS.map((day, index) => (
                    <span key={day} className={`text-[11px] font-semibold rounded-full px-2.5 py-1 ${schedule.days_of_week?.includes(index) ? "bg-primary text-primary-foreground" : "bg-background text-muted-foreground"}`}>
                      {day.slice(0, 3)}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-widest mb-2">Locked apps</p>
                {apps.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5">
                    {apps.map(app => (
                      <span key={app.name} className="flex items-center gap-1.5 text-xs bg-background text-foreground px-2.5 py-1 rounded-xl font-medium">
                        {app.domain ? <img src={getFaviconUrl(app.domain)} alt="" className="w-3.5 h-3.5 rounded" onError={e => { e.target.style.display = "none"; }} /> : null}
                        {app.name}
                      </span>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground">No apps selected.</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2">
                <Link to={`/schedule-builder?edit=${schedule.id}`} className="rounded-xl bg-background px-3 py-2 text-xs font-semibold text-foreground flex items-center justify-center gap-1.5">
                  <Pencil className="w-3.5 h-3.5" /> Edit
                </Link>
                <button onClick={() => onSkipToday(schedule)} className="rounded-xl bg-background px-3 py-2 text-xs font-semibold text-foreground flex items-center justify-center gap-1.5">
                  <CalendarX className="w-3.5 h-3.5" /> Skip today
                </button>
                <label className="rounded-xl bg-background px-3 py-2 text-xs font-semibold text-foreground flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5"><Bell className="w-3.5 h-3.5" /> Active</span>
                  <Switch checked={isActive} onCheckedChange={() => onToggleActive(schedule)} />
                </label>
                <button onClick={() => onDelete(schedule)} className="rounded-xl bg-background px-3 py-2 text-xs font-semibold text-destructive flex items-center justify-center gap-1.5">
                  <Trash2 className="w-3.5 h-3.5" /> Delete
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.article>
  );
}