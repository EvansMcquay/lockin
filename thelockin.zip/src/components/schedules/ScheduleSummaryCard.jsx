import React from "react";

export default function ScheduleSummaryCard({ items }) {
  return (
    <div className="rounded-3xl border border-border bg-card overflow-hidden">
      {items.map((item, index) => (
        <button key={item.label} type="button" onClick={item.onClick} className={`w-full px-4 py-3.5 text-left transition-colors hover:bg-muted/40 ${index > 0 ? "border-t border-border" : ""}`}>
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">{item.label}</p>
              <p className="mt-1 truncate text-sm font-semibold text-foreground">{item.value}</p>
            </div>
            <span className="text-xs font-semibold text-primary">Change</span>
          </div>
        </button>
      ))}
    </div>
  );
}