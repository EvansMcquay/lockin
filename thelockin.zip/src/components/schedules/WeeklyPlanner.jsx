import React, { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import PlannerScheduleCard from "@/components/schedules/PlannerScheduleCard";

const DAYS = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

export default function WeeklyPlanner({ schedules, onToggleActive, onSkipToday, onDelete, formatTime, formatDays }) {
  const [selectedDay, setSelectedDay] = useState(new Date().getDay());

  const week = useMemo(() => DAYS.map((day, index) => ({
    day,
    index,
    schedules: schedules
      .filter(schedule => schedule.days_of_week?.includes(index))
      .sort((a, b) => (a.start_time || "").localeCompare(b.start_time || "")),
  })), [schedules]);

  const selected = week[selectedDay];
  const totalRepeats = week.reduce((sum, day) => sum + day.schedules.length, 0);

  return (
    <section className="space-y-4">
      <div className="rounded-3xl bg-card border border-border p-4 space-y-4">
        <div>
          <p className="text-xs font-semibold text-primary uppercase tracking-[0.16em]">Week view</p>
          <h2 className="font-heading font-bold text-lg text-foreground mt-1">Plan by day</h2>
          <p className="text-sm text-muted-foreground mt-0.5">{totalRepeats} scheduled session{totalRepeats === 1 ? "" : "s"} across your week.</p>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1 snap-x">
          {week.map(day => {
            const active = day.index === selectedDay;
            return (
              <motion.button
                key={day.day}
                whileTap={{ scale: 0.96 }}
                onClick={() => setSelectedDay(day.index)}
                className={`min-w-[104px] snap-start rounded-2xl border px-3 py-3 text-left transition-colors ${active ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-foreground"}`}
              >
                <span className={`block text-xs font-semibold ${active ? "text-primary-foreground/70" : "text-muted-foreground"}`}>{day.day.slice(0, 3)}</span>
                <span className="block text-sm font-bold mt-0.5">{day.day}</span>
                <span className={`block text-[11px] mt-1 ${active ? "text-primary-foreground/70" : "text-muted-foreground"}`}>{day.schedules.length} session{day.schedules.length === 1 ? "" : "s"}</span>
              </motion.button>
            );
          })}
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={selectedDay}
          initial={{ opacity: 0, x: 16 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -16 }}
          transition={{ duration: 0.18 }}
          className="space-y-3"
        >
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-heading font-bold text-base text-foreground">{selected.day}</h3>
              <p className="text-xs text-muted-foreground">Tap a schedule to see apps, repeat days, and controls.</p>
            </div>
          </div>

          {selected.schedules.length === 0 ? (
            <div className="rounded-2xl bg-card border border-border p-6 text-center">
              <p className="text-sm font-semibold text-foreground">Nothing planned for {selected.day}.</p>
              <p className="text-xs text-muted-foreground mt-1">Add a schedule or choose another day.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {selected.schedules.map(schedule => (
                <PlannerScheduleCard
                  key={`${selectedDay}-${schedule.id}`}
                  schedule={schedule}
                  selectedDay={selectedDay}
                  onToggleActive={onToggleActive}
                  onSkipToday={onSkipToday}
                  onDelete={onDelete}
                  formatTime={formatTime}
                  formatDays={formatDays}
                />
              ))}
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </section>
  );
}