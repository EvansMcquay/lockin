import React from "react";

export default function ScheduleFlowShell({ eyebrow, title, subtitle, progress, children, footer }) {
  return (
    <div className="flex-1 flex flex-col">
      <div className="mb-5">
        {progress && <div className="mb-4 h-1.5 rounded-full bg-muted overflow-hidden"><div className="h-full rounded-full bg-primary transition-all duration-300" style={{ width: progress }} /></div>}
        {eyebrow && <p className="premium-label mb-2">{eyebrow}</p>}
        <h2 className="text-2xl font-bold text-foreground tracking-[-0.04em]">{title}</h2>
        {subtitle && <p className="mt-2 text-sm leading-6 text-muted-foreground">{subtitle}</p>}
      </div>
      <div className="flex-1 space-y-3">{children}</div>
      {footer && <div className="sticky bottom-24 -mx-5 mt-6 bg-background/95 px-5 pb-[calc(1.25rem+var(--safe-area-bottom))] pt-3 backdrop-blur-xl">{footer}</div>}
    </div>
  );
}