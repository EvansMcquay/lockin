import React, { useMemo, useState } from "react";
import RoutineScheduleCard from "@/components/schedules/RoutineScheduleCard";

function getDateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function sortByTime(a, b) {
  return (a.start_time || "").localeCompare(b.start_time || "");
}

export default function RoutinePlanner({ schedules, formatTime, formatDays, onToggleActive, onSkipToday, onDelete }) {
  const groups = useMemo(() => {
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);
    const todayDay = today.getDay();
    const tomorrowDay = tomorrow.getDay();
    const todayKey = getDateKey(today);
    const tomorrowKey = getDateKey(tomorrow);
    const active = schedules.filter(schedule => schedule.is_active !== false);
    const todayItems = active.filter(schedule => schedule.days_of_week?.includes(todayDay) && !schedule.skip_dates?.includes(todayKey)).sort(sortByTime);
    const tomorrowItems = active.filter(schedule => schedule.days_of_week?.includes(tomorrowDay) && !schedule.skip_dates?.includes(tomorrowKey)).sort(sortByTime);
    const visibleIds = new Set([...todayItems, ...tomorrowItems].map(schedule => schedule.id));
    const upcomingItems = active.filter(schedule => !visibleIds.has(schedule.id)).sort(sortByTime);
    const pausedItems = schedules.filter(schedule => schedule.is_active === false).sort(sortByTime);
    return { todayItems, tomorrowItems, upcomingItems, pausedItems };
  }, [schedules]);

  return (
    <section className="space-y-5">
      <RoutineSection title="Today" empty="Nothing else today." items={groups.todayItems} canSkipToday formatTime={formatTime} formatDays={formatDays} onToggleActive={onToggleActive} onSkipToday={onSkipToday} onDelete={onDelete} />
      <RoutineSection title="Tomorrow" empty="Tomorrow is clear." items={groups.tomorrowItems} formatTime={formatTime} formatDays={formatDays} onToggleActive={onToggleActive} onSkipToday={onSkipToday} onDelete={onDelete} />
      <RoutineSection title="Upcoming" empty="No recurring routines yet." items={groups.upcomingItems} formatTime={formatTime} formatDays={formatDays} onToggleActive={onToggleActive} onSkipToday={onSkipToday} onDelete={onDelete} />
      {groups.pausedItems.length > 0 && <RoutineSection title="Paused" items={groups.pausedItems} formatTime={formatTime} formatDays={formatDays} onToggleActive={onToggleActive} onSkipToday={onSkipToday} onDelete={onDelete} />}
    </section>
  );
}

function RoutineSection({ title, empty, items, canSkipToday = false, ...cardProps }) {
  const [showAll, setShowAll] = useState(false);
  const visibleItems = showAll ? items : items.slice(0, 3);
  const hiddenCount = Math.max(0, items.length - visibleItems.length);

  return (
    <div className="space-y-2.5">
      <div className="flex items-center justify-between px-1">
        <h2 className="font-heading text-sm font-semibold uppercase tracking-[0.16em] text-muted-foreground">{title}</h2>
        <span className="text-xs text-muted-foreground">{items.length}</span>
      </div>
      {items.length === 0 ? (
        <div className="rounded-2xl border border-border bg-card/70 px-4 py-3 text-sm text-muted-foreground">{empty}</div>
      ) : (
        <div className="space-y-2.5">
          {visibleItems.map(schedule => <RoutineScheduleCard key={schedule.id} schedule={schedule} canSkipToday={canSkipToday} {...cardProps} />)}
          {hiddenCount > 0 && <button onClick={() => setShowAll(true)} className="w-full rounded-2xl border border-border bg-card/70 px-4 py-3 text-sm font-semibold text-primary">Show {hiddenCount} more</button>}
          {showAll && items.length > 3 && <button onClick={() => setShowAll(false)} className="w-full px-4 py-2 text-sm font-semibold text-muted-foreground">Show less</button>}
        </div>
      )}
    </div>
  );
}