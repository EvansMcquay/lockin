import React from "react";
import { formatConflictDays, formatConflictTime } from "@/lib/scheduleConflicts";

export default function ScheduleConflictWarning({ conflicts, onAdjust, onSaveAnyway, saving }) {
  if (conflicts.length === 0) return null;

  const firstConflict = conflicts[0];
  const extraCount = conflicts.length - 1;

  return (
    <div className="rounded-2xl border border-accent/30 bg-accent/10 p-4 space-y-3">
      <div>
        <p className="text-sm font-semibold text-foreground">Schedule overlap detected</p>
        <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
          This overlaps {firstConflict.label || "another schedule"} from {formatConflictTime(firstConflict.start_time)} to {formatConflictTime(firstConflict.end_time)} on {formatConflictDays(firstConflict.shared_days)}{extraCount > 0 ? `, plus ${extraCount} more.` : "."}
        </p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={onAdjust}
          className="rounded-xl bg-card border border-border px-3 py-2 text-xs font-semibold text-foreground active:scale-[0.98]"
        >
          Adjust time
        </button>
        <button
          type="button"
          onClick={onSaveAnyway}
          disabled={saving}
          className="rounded-xl bg-primary text-primary-foreground px-3 py-2 text-xs font-semibold disabled:opacity-60 active:scale-[0.98]"
        >
          Save anyway
        </button>
      </div>
    </div>
  );
}