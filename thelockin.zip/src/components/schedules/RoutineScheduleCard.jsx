import React, { useState } from "react";
import { Link } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Bell, CalendarX, ChevronDown, Pencil, Trash2, UserPlus } from "lucide-react";
import ScheduleIcon from "@/components/schedules/ScheduleIcon";
import { getFaviconUrl } from "@/lib/appLibrary";
import { sharedLockinSetupUrl } from "@/lib/sharedLockinLinks";

export default function RoutineScheduleCard({ schedule, formatTime, formatDays, onToggleActive, onSkipToday, onDelete, canSkipToday = false }) {
  const [expanded, setExpanded] = useState(false);
  const isActive = schedule.is_active !== false;
  const apps = schedule.apps || [];
  const inviteUrl = sharedLockinSetupUrl({ category: schedule.label, focus: schedule.goal_name || schedule.label });

  return (
    <motion.article layout className="overflow-hidden rounded-[20px] border border-border bg-card/90">
      <button onClick={() => setExpanded(!expanded)} className="w-full p-3.5 text-left active:scale-[0.99] transition-transform">
        <div className="flex items-center gap-3">
          <ScheduleIcon icon={schedule.goal_emoji} styleName={schedule.icon_style} size="sm" />
          <div className="min-w-0 flex-1">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h3 className="truncate font-heading text-base font-semibold text-foreground">{schedule.label}</h3>
                <p className="mt-0.5 text-sm font-medium text-muted-foreground">{formatTime(schedule.start_time)}</p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${isActive ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>{isActive ? "On" : "Paused"}</span>
                <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${expanded ? "rotate-180" : ""}`} />
              </div>
            </div>
          </div>
        </div>
      </button>

      <AnimatePresence initial={false}>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.18 }} className="overflow-hidden">
            <div className="mx-3.5 mb-3.5 space-y-3 rounded-2xl bg-muted/50 p-3">
              <Detail label="Goal" value={schedule.goal_name || schedule.label} />
              <Detail label="Repeat" value={formatDays(schedule.days_of_week)} />
              <Detail label="Time" value={`${formatTime(schedule.start_time)} – ${formatTime(schedule.end_time)}`} />
              <Detail label="Lockin Friends" value={schedule.shared_lockin_id ? "Shared Lockin" : "Optional"} />
              <div>
                <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Locked Apps</p>
                <div className="flex flex-wrap gap-1.5">
                  {apps.length ? apps.map(app => <span key={app.name} className="flex items-center gap-1.5 rounded-xl bg-background px-2.5 py-1 text-xs font-medium text-foreground">{app.domain ? <img src={getFaviconUrl(app.domain)} alt="" className="h-3.5 w-3.5 rounded" onError={e => { e.target.style.display = "none"; }} /> : null}{app.name}</span>) : <span className="text-xs text-muted-foreground">No apps selected</span>}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 pt-1">
                <Link to={`/schedule-builder?edit=${schedule.id}`} className="rounded-xl bg-background px-3 py-2 text-center text-xs font-semibold text-foreground"><Pencil className="mr-1 inline h-3.5 w-3.5" />Edit</Link>
                <Link to={inviteUrl} className="rounded-xl bg-background px-3 py-2 text-center text-xs font-semibold text-foreground"><UserPlus className="mr-1 inline h-3.5 w-3.5" />Friends</Link>
                {canSkipToday && <button onClick={() => onSkipToday(schedule)} className="rounded-xl bg-background px-3 py-2 text-xs font-semibold text-foreground"><CalendarX className="mr-1 inline h-3.5 w-3.5" />Skip today</button>}
                <button onClick={() => onToggleActive(schedule)} className="rounded-xl bg-background px-3 py-2 text-xs font-semibold text-foreground"><Bell className="mr-1 inline h-3.5 w-3.5" />{isActive ? "Pause" : "Resume"}</button>
                <button onClick={() => onDelete(schedule)} className="rounded-xl bg-background px-3 py-2 text-xs font-semibold text-destructive"><Trash2 className="mr-1 inline h-3.5 w-3.5" />Delete</button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.article>
  );
}

function Detail({ label, value }) {
  return <div className="flex items-center justify-between gap-3 text-sm"><span className="text-muted-foreground">{label}</span><span className="truncate font-semibold text-foreground">{value}</span></div>;
}