import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Check } from "lucide-react";
import ScheduleIcon from "@/components/schedules/ScheduleIcon";
import { ICON_CATEGORIES, ICON_STYLES, SCHEDULE_ICONS } from "@/lib/scheduleIcons";

const FAVORITES_KEY = "lockin_schedule_icon_favorites";
const RECENTS_KEY = "lockin_schedule_icon_recents";

function readStoredIds(key) {
  try {
    return JSON.parse(localStorage.getItem(key) || "[]");
  } catch {
    return [];
  }
}

export default function ScheduleIconPicker({ value, styleName, onIconChange, onStyleChange }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [favorites, setFavorites] = useState([]);
  const [recents, setRecents] = useState([]);

  useEffect(() => {
    setFavorites(readStoredIds(FAVORITES_KEY));
    setRecents(readStoredIds(RECENTS_KEY));
  }, []);

  const selectedIcon = SCHEDULE_ICONS.find(icon => icon.emoji === value) || SCHEDULE_ICONS[0];

  const visibleIcons = useMemo(() => {
    const term = query.trim().toLowerCase();
    let icons = SCHEDULE_ICONS;
    if (category === "Favorites") icons = icons.filter(icon => favorites.includes(icon.id));
    else if (category === "Recent") icons = recents.map(id => icons.find(icon => icon.id === id)).filter(Boolean);
    else if (category !== "All") icons = icons.filter(icon => icon.category === category);

    if (!term) return icons;
    return icons.filter(icon =>
      icon.label.toLowerCase().includes(term) ||
      icon.category.toLowerCase().includes(term) ||
      icon.tags.some(tag => tag.toLowerCase().includes(term))
    );
  }, [category, favorites, query, recents]);

  const chooseIcon = (icon) => {
    onIconChange(icon.emoji);
    const nextRecents = [icon.id, ...recents.filter(id => id !== icon.id)].slice(0, 12);
    setRecents(nextRecents);
    localStorage.setItem(RECENTS_KEY, JSON.stringify(nextRecents));
  };

  const toggleFavorite = () => {
    const nextFavorites = favorites.includes(selectedIcon.id)
      ? favorites.filter(id => id !== selectedIcon.id)
      : [selectedIcon.id, ...favorites].slice(0, 24);
    setFavorites(nextFavorites);
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(nextFavorites));
  };

  return (
    <div className="rounded-3xl bg-card border border-border p-4 space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Appearance</p>
          <p className="text-sm text-muted-foreground mt-1">Pick an icon style for this focus.</p>
        </div>
        <div className="flex items-center gap-2">
          <button type="button" onClick={toggleFavorite} className="w-9 h-9 rounded-xl bg-muted/70 text-sm flex items-center justify-center active:scale-95 transition-transform">
            {favorites.includes(selectedIcon.id) ? "★" : "☆"}
          </button>
          <ScheduleIcon icon={value} styleName={styleName} size="lg" />
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2">
        {ICON_STYLES.map(style => (
          <button
            key={style.id}
            type="button"
            onClick={() => onStyleChange(style.id)}
            className={`rounded-2xl px-2 py-2 text-center transition-all active:scale-[0.96] ${styleName === style.id ? "bg-primary text-primary-foreground" : "bg-muted/60 text-foreground"}`}
          >
            <span className="block text-xs font-bold">{style.label}</span>
          </button>
        ))}
      </div>

      <input
        value={query}
        onChange={e => setQuery(e.target.value)}
        placeholder="Search icons, routines, hobbies..."
        className="w-full h-10 rounded-2xl border border-input bg-background px-4 text-sm outline-none focus:ring-2 focus:ring-primary/20"
      />

      <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
        {ICON_CATEGORIES.map(item => (
          <button
            key={item}
            type="button"
            onClick={() => setCategory(item)}
            className={`whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${category === item ? "bg-secondary text-secondary-foreground" : "bg-muted text-muted-foreground"}`}
          >
            {item}
          </button>
        ))}
      </div>

      {visibleIcons.length === 0 ? (
        <div className="rounded-2xl bg-muted/50 p-4 text-center">
          <p className="text-sm font-semibold text-foreground">No icons found.</p>
          <p className="text-xs text-muted-foreground mt-1">Try another search or category.</p>
        </div>
      ) : (
        <div className="grid grid-cols-4 gap-3 max-h-80 overflow-y-auto pr-1 pb-1">
          {visibleIcons.map(icon => {
            const selected = value === icon.emoji;
            return (
              <motion.button
                key={icon.id}
                type="button"
                aria-label={`Choose ${icon.label} icon`}
                whileTap={{ scale: 0.94 }}
                onClick={() => chooseIcon(icon)}
                className={`group relative aspect-square rounded-3xl border flex items-center justify-center transition-all ${selected ? "border-primary bg-primary/10 ring-2 ring-primary/20 shadow-sm shadow-primary/10" : "border-border bg-background hover:bg-muted/50"}`}
              >
                <ScheduleIcon icon={icon.emoji} styleName={styleName} size="picker" className="mx-auto" />
                {selected && (
                  <span className="absolute right-2 top-2 w-5 h-5 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-sm">
                    <Check className="w-3 h-3" />
                  </span>
                )}
              </motion.button>
            );
          })}
        </div>
      )}
    </div>
  );
}