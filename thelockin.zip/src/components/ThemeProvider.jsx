import { useEffect } from "react";

export default function ThemeProvider({ children }) {
  useEffect(() => {
    const storedTheme = localStorage.getItem("lockin_theme");
    const useDark = storedTheme ? storedTheme === "dark" : true;
    document.documentElement.classList.toggle("dark", useDark);
  }, []);
  return children;
}