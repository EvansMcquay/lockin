import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

/**
 * Reusable, encouraging empty state.
 * Calm, confident messaging — never boring.
 */
export default function EmptyState({ icon, title, message, actionLabel, actionTo, onAction }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="text-center py-14 px-6 space-y-4"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.35, ease: "easeOut" }}
        className="text-5xl"
      >
        {icon}
      </motion.div>
      <div className="space-y-1.5">
        <h3 className="font-heading font-semibold text-lg text-foreground">{title}</h3>
        <p className="text-sm text-muted-foreground leading-relaxed max-w-xs mx-auto">{message}</p>
      </div>
      {actionLabel && actionTo && (
        <Link to={actionTo}>
          <Button className="rounded-2xl px-6 h-11 font-semibold">{actionLabel}</Button>
        </Link>
      )}
      {actionLabel && onAction && !actionTo && (
        <Button onClick={onAction} className="rounded-2xl px-6 h-11 font-semibold">{actionLabel}</Button>
      )}
    </motion.div>
  );
}