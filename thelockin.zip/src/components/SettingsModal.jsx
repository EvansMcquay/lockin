import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogAction,
  AlertDialogCancel,
} from "@/components/ui/alert-dialog";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Trash2, Monitor, Bell, Smartphone, Calendar, BellRing, Puzzle, AtSign, LogOut } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { circleAction } from "@/lib/circlesApi";

const INTEGRATIONS = [
  { name: "Screen Time / App Blocking", description: "Block real iPhone apps during Lockins", icon: Smartphone, status: "Coming Soon" },
  { name: "Calendar", description: "Turn events into Lockins automatically", icon: Calendar, status: "Coming Soon" },
  { name: "Reminders", description: "Create Lockins from your reminders", icon: BellRing, status: "Coming Soon" },
  { name: "Notifications", description: "Session alerts and reminders", icon: Bell, status: "Coming Soon" },
];

const NOTIFICATION_TYPES = [
  { key: "time_to_lock_in", label: "Time to Lock In", description: "🔔 Homework starts in 15 minutes" },
  { key: "session_starting", label: "Session Starting", description: "🔒 Lockin begins in 5 minutes" },
  { key: "session_ending", label: "Session Ending", description: "⏰ Your session ends in 5 minutes" },
  { key: "streak_reminders", label: "Streak Reminders", description: "🔥 You're one Lockin away from leveling up" },
  { key: "daily_focus", label: "Daily Focus", description: "🎉 Great job! Session completed" },
  { key: "circle_reactions", label: "Circle Reactions", description: "Mike and others celebrated your Lockin" },
  { key: "circle_encouragement", label: "Encouragement Messages", description: "Someone left a supportive note" },
  { key: "circle_started", label: "Selected Friend Started", description: "A selected friend started a shared Lockin" },
  { key: "circle_completed", label: "Circle Completions", description: "A Circle member completed a Lockin" },
];

const DEFAULT_PREFS = {
  time_to_lock_in: true,
  session_starting: true,
  session_ending: false,
  streak_reminders: true,
  daily_focus: true,
  circle_reactions: true,
  circle_encouragement: true,
  circle_started: true,
  circle_completed: true,
};

export default function SettingsModal({ open, onClose }) {
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [logoutOpen, setLogoutOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);
  const [deleteText, setDeleteText] = useState("");
  const [prefs, setPrefs] = useState(DEFAULT_PREFS);
  const [loadingPrefs, setLoadingPrefs] = useState(true);
  const [username, setUsername] = useState("");
  const [usernameStatus, setUsernameStatus] = useState(null);
  const [savingUsername, setSavingUsername] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (open) {
      base44.auth.me().then(user => {
        if (user?.notification_prefs) {
          setPrefs({ ...DEFAULT_PREFS, ...user.notification_prefs });
        }
        setUsername(user?.username || "");
        setLoadingPrefs(false);
      }).catch(() => setLoadingPrefs(false));
    } else {
      setLoadingPrefs(true);
    }
  }, [open]);

  useEffect(() => {
    if (!deleteOpen) setDeleteText("");
  }, [deleteOpen]);

  useEffect(() => {
    if (!open || username.length < 3) { setUsernameStatus(null); return; }
    const id = setTimeout(async () => {
      try { setUsernameStatus(await circleAction("checkUsernameAvailability", { username })); }
      catch { setUsernameStatus(null); }
    }, 350);
    return () => clearTimeout(id);
  }, [open, username]);

  const togglePref = async (key) => {
    const newPrefs = { ...prefs, [key]: !prefs[key] };
    setPrefs(newPrefs);
    try {
      await base44.auth.updateMe({ notification_prefs: newPrefs });
    } catch {
      setPrefs(prefs);
    }
  };

  const saveUsername = async () => {
    setSavingUsername(true);
    try {
      const result = await circleAction("updateUsername", { username });
      setUsername(result.username);
      toast({ title: "Username updated" });
    } catch (error) {
      toast({ title: error?.response?.data?.error || "Could not update username", variant: "destructive" });
    } finally {
      setSavingUsername(false);
    }
  };

  const handleLogout = async () => {
    setLoggingOut(true);
    try {
      await base44.auth.logout("/login");
    } finally {
      window.location.replace("/login");
    }
  };

  const handleDelete = async (e) => {
    e?.preventDefault?.();
    if (deleteText !== "DELETE") return;
    setDeleting(true);
    try {
      await base44.functions.invoke("deleteAccount", { confirmation: deleteText });
      try {
        await base44.auth.logout();
      } finally {
        localStorage.clear();
        sessionStorage.clear();
        window.location.href = "/register";
      }
    } catch {
      toast({ title: "Account deletion failed. Please try again.", variant: "destructive" });
      setDeleting(false);
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="max-w-sm max-h-[90vh] overflow-y-auto rounded-3xl">
          <DialogHeader>
            <DialogTitle>Settings</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 pt-2">
            <div className="rounded-2xl bg-muted/50 p-4 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <AtSign className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Account Username</p>
                  <p className="text-xs text-muted-foreground">Used for Circles and invites</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Input value={username} onChange={e => setUsername(e.target.value.toLowerCase().replace(/^@/, "").replace(/[^a-z0-9._]/g, "").slice(0, 20))} placeholder="username" className="rounded-2xl" />
                <button onClick={saveUsername} disabled={savingUsername || !usernameStatus?.available} className="rounded-2xl bg-primary px-4 text-sm font-semibold text-primary-foreground disabled:opacity-50">Save</button>
              </div>
              {usernameStatus && <p className={`text-xs ${usernameStatus.available ? "text-success" : "text-destructive"}`}>{usernameStatus.available ? "Username available." : usernameStatus.reason || "That username is already taken."}</p>}
            </div>

            <div className="rounded-2xl bg-muted/50 p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Monitor className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">Appearance</p>
                <p className="text-xs text-muted-foreground">Theme follows your system preference</p>
              </div>
            </div>

            <div className="rounded-2xl bg-muted/50 p-4 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Bell className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Notifications</p>
                  <p className="text-xs text-muted-foreground">Choose what reminds you</p>
                </div>
              </div>
              {!loadingPrefs && (
                <div className="space-y-2.5 pt-1">
                  {NOTIFICATION_TYPES.map(n => (
                    <div key={n.key} className="flex items-center justify-between">
                      <div className="flex-1 min-w-0 pr-2">
                        <p className="text-sm font-medium text-foreground">{n.label}</p>
                        <p className="text-xs text-muted-foreground">{n.description}</p>
                      </div>
                      <Switch
                        checked={prefs[n.key]}
                        onCheckedChange={() => togglePref(n.key)}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Integrations */}
            <div className="rounded-2xl bg-muted/50 p-4 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Puzzle className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Integrations</p>
                  <p className="text-xs text-muted-foreground">Connect with your iPhone</p>
                </div>
              </div>
              <div className="space-y-2 pt-1">
                {INTEGRATIONS.map(int => (
                  <div key={int.name} className="flex items-center justify-between rounded-xl bg-card/50 p-3">
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <int.icon className="w-4 h-4 text-primary flex-shrink-0" />
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-foreground truncate">{int.name}</p>
                        <p className="text-[11px] text-muted-foreground truncate">{int.description}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-semibold text-accent flex-shrink-0">{int.status}</span>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => setLogoutOpen(true)}
              className="w-full rounded-2xl border border-border bg-muted/50 p-4 flex items-center gap-3 text-left active:scale-[0.98] transition-transform"
            >
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <LogOut className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">Log Out</p>
                <p className="text-xs text-muted-foreground">End this session and return to sign in</p>
              </div>
            </button>

            <button
              onClick={() => setDeleteOpen(true)}
              className="w-full rounded-2xl border border-destructive/20 bg-destructive/5 p-4 flex items-center gap-3 text-left active:scale-[0.98] transition-transform"
            >
              <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center flex-shrink-0">
                <Trash2 className="w-5 h-5 text-destructive" />
              </div>
              <div>
                <p className="text-sm font-medium text-destructive">Delete Account</p>
                <p className="text-xs text-muted-foreground">Permanently remove your account and data</p>
              </div>
            </button>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={logoutOpen} onOpenChange={(o) => !loggingOut && setLogoutOpen(o)}>
        <AlertDialogContent className="max-w-sm rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Log out of Lockin?</AlertDialogTitle>
            <AlertDialogDescription>
              You will need to sign in again to access this account.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={loggingOut}>No, Stay Logged In</AlertDialogCancel>
            <AlertDialogAction onClick={handleLogout} disabled={loggingOut}>
              {loggingOut ? "Logging out..." : "Yes, Log Out"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={deleteOpen} onOpenChange={(o) => !deleting && setDeleteOpen(o)}>
        <AlertDialogContent className="max-w-sm rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete your account?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently deletes your account, profile, schedules, Lockins,
              session history, journal entries, stats, and settings. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">Type DELETE to confirm.</p>
            <Input
              value={deleteText}
              onChange={(e) => setDeleteText(e.target.value)}
              disabled={deleting}
              placeholder="DELETE"
              className="rounded-2xl"
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting || deleteText !== "DELETE"}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? "Deleting..." : "Delete Forever"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}