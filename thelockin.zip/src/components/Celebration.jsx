import { useEffect } from "react";
import confetti from "canvas-confetti";

export function fireConfetti() {
  const colors = ["#0d7c5a", "#f0a500", "#1a2433"];
  confetti({
    particleCount: 80,
    spread: 70,
    origin: { y: 0.6 },
    colors,
  });
  setTimeout(() => {
    confetti({
      particleCount: 50,
      angle: 60,
      spread: 55,
      origin: { x: 0, y: 0.7 },
      colors,
    });
    confetti({
      particleCount: 50,
      angle: 120,
      spread: 55,
      origin: { x: 1, y: 0.7 },
      colors,
    });
  }, 200);
}

export default function Celebration({ fireOnMount = false, children }) {
  useEffect(() => {
    if (fireOnMount) {
      const t = setTimeout(() => fireConfetti(), 300);
      return () => clearTimeout(t);
    }
  }, [fireOnMount]);
  return children || null;
}