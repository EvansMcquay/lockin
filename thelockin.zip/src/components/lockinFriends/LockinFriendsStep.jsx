import React, { useEffect, useState } from "react";
import { Check, Users } from "lucide-react";
import { lockinFriendsAction } from "@/lib/lockinFriendsApi";

const MODES = [
  { value: "celebrate", label: "Celebrate when I finish" },
  { value: "start_encouragement", label: "Encourage me if I haven't started on time" },
  { value: "both", label: "Both" },
];

function Avatar({ name, photo }) {
  return photo ? <img src={photo} alt={name} className="w-10 h-10 rounded-2xl object-cover" /> : <span className="w-10 h-10 rounded-2xl bg-primary/10 text-primary flex items-center justify-center font-bold">{(name || "F").slice(0, 1)}</span>;
}

function PersonRow({ person, selected, onClick }) {
  return <button type="button" onClick={onClick} className={`w-full rounded-2xl border p-3 flex items-center gap-3 text-left ${selected ? "border-primary bg-primary/10" : "border-border bg-card"}`}><Avatar name={person.name} photo={person.photo_url} /><div className="flex-1 min-w-0"><p className="text-sm font-semibold text-foreground truncate">{person.name}</p><p className="text-xs text-muted-foreground truncate">@{person.username}</p></div>{selected && <Check className="w-4 h-4 text-primary" />}</button>;
}

export default function LockinFriendsStep({ value, onChange }) {
  const [context, setContext] = useState({ people: [], circles: [] });
  const selected = value?.targets || [];
  const helpMode = value?.helpMode || "both";
  useEffect(() => { lockinFriendsAction("lockinFriendsContext").then(setContext).catch(() => null); }, []);
  const isSelected = (type, id) => selected.some(item => item.type === type && item.id === id);
  const toggle = (target) => onChange({ targets: isSelected(target.type, target.id) ? selected.filter(item => !(item.type === target.type && item.id === target.id)) : [...selected, target], helpMode });
  const clear = () => onChange({ targets: [], helpMode });
  return <section className="space-y-4"><div><h2 className="font-heading font-bold text-lg text-foreground mb-1">Lockin Friends</h2><p className="text-sm text-muted-foreground">Choose people who can help you follow through.</p></div><button type="button" onClick={clear} className={`w-full rounded-2xl border p-4 text-left ${selected.length === 0 ? "border-primary bg-primary/10" : "border-border bg-card"}`}><div className="flex items-center justify-between"><div><p className="text-sm font-semibold text-foreground">No Lockin Friends</p><p className="text-xs text-muted-foreground">Fast and private. You can skip this.</p></div>{selected.length === 0 && <Check className="w-4 h-4 text-primary" />}</div></button>{context.circles.length > 0 && <div className="space-y-2"><p className="premium-label">Circles</p>{context.circles.map(circle => <button key={circle.id} type="button" onClick={() => toggle({ type: "circle", id: circle.id, name: circle.name })} className={`w-full rounded-2xl border p-3 flex items-center gap-3 text-left ${isSelected("circle", circle.id) ? "border-primary bg-primary/10" : "border-border bg-card"}`}><span className="w-10 h-10 rounded-2xl bg-secondary flex items-center justify-center text-lg">{circle.icon || <Users className="w-4 h-4" />}</span><div className="flex-1"><p className="text-sm font-semibold text-foreground">{circle.name}</p><p className="text-xs text-muted-foreground">Entire Circle · {circle.member_count} friend{circle.member_count === 1 ? "" : "s"}</p></div>{isSelected("circle", circle.id) && <Check className="w-4 h-4 text-primary" />}</button>)}</div>}{context.people.length > 0 && <div className="space-y-2"><p className="premium-label">Friends</p>{context.people.slice(0, 12).map(person => <PersonRow key={person.id} person={person} selected={isSelected("person", person.id)} onClick={() => toggle({ type: "person", id: person.id, name: person.name })} />)}</div>}{selected.length > 0 && <div className="space-y-2"><p className="premium-label">How should they help?</p>{MODES.map(mode => <button key={mode.value} type="button" onClick={() => onChange({ targets: selected, helpMode: mode.value })} className={`w-full rounded-2xl border px-4 py-3 flex items-center justify-between text-sm font-semibold ${helpMode === mode.value ? "border-primary bg-primary/10 text-primary" : "border-border bg-card text-foreground"}`}>{mode.label}{helpMode === mode.value && <Check className="w-4 h-4" />}</button>)}</div>}</section>;
}