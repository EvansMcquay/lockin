import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { lockinFriendsAction } from "@/lib/lockinFriendsApi";

const QUICK = ["💪 Lock in!", "📚 Homework time!", "🔥 You got this!", "👏 Finish strong!", "🚀 Let’s go!"];

function RequestCard({ item, onRefresh }) {
  const [open, setOpen] = useState(false);
  const [custom, setCustom] = useState("");
  const send = async (message) => { await lockinFriendsAction("sendEncouragement", { notificationId: item.id, message }); onRefresh(); };
  return <div className="premium-card p-4 space-y-3"><div><p className="text-sm font-semibold text-foreground">{item.message || `${item.owner_name} could use a little push.`}</p><p className="text-xs text-muted-foreground mt-1">Private Lockin Friends reminder</p></div>{open ? <div className="space-y-2">{QUICK.map(msg => <button key={msg} onClick={() => send(msg)} className="w-full rounded-2xl bg-muted px-3 py-2 text-left text-sm font-semibold text-foreground">{msg}</button>)}<div className="flex gap-2"><Input value={custom} onChange={e => setCustom(e.target.value.slice(0, 80))} placeholder="Write your own" className="h-10 rounded-2xl" /><Button onClick={() => send(custom)} disabled={!custom.trim()} size="sm">Send</Button></div></div> : <div className="grid grid-cols-2 gap-2"><Button onClick={() => setOpen(true)} className="rounded-2xl">💪 Encourage</Button><Button variant="outline" onClick={async () => { await lockinFriendsAction("dismissNotification", { notificationId: item.id }); onRefresh(); }} className="rounded-2xl">Ignore</Button></div>}</div>;
}

function MessageCard({ item, schedules, onStartSchedule, onRefresh }) {
  const dismiss = async (status = "dismissed") => { await lockinFriendsAction("dismissNotification", { notificationId: item.id, status }); onRefresh(); };
  const canStart = item.schedule_id && schedules.some(s => s.id === item.schedule_id && !s.deleted_at);
  return <div className="premium-card p-4 space-y-3"><div><p className="text-sm font-semibold text-foreground">{item.from_name || "A friend"} sent you some encouragement.</p><p className="text-lg font-bold text-foreground mt-2">{item.message}</p></div><div className="grid grid-cols-1 gap-2">{canStart && <Button onClick={async () => { await onStartSchedule(item.schedule_id); await dismiss(); }} className="rounded-2xl">Start Lockin</Button>}<Button variant="outline" onClick={() => dismiss("snoozed")} className="rounded-2xl">Remind Me in 10 Minutes</Button><Button variant="ghost" onClick={() => dismiss()} className="rounded-2xl">Thanks</Button></div></div>;
}

export default function LockinFriendInbox({ notifications = [], schedules = [], onStartSchedule, onRefresh }) {
  if (!notifications.length) return null;
  return <section className="space-y-3"><h2 className="font-heading font-semibold text-2xl text-foreground">Lockin Friends</h2>{notifications.map(item => item.type === "encouragement_request" ? <RequestCard key={item.id} item={item} onRefresh={onRefresh} /> : item.type === "encouragement_message" ? <MessageCard key={item.id} item={item} schedules={schedules} onStartSchedule={onStartSchedule} onRefresh={onRefresh} /> : <div key={item.id} className="premium-card p-4 flex items-center justify-between gap-3"><p className="text-sm font-semibold text-foreground">🎉 {item.message}</p><Button size="sm" variant="outline" onClick={async () => { await lockinFriendsAction("dismissNotification", { notificationId: item.id }); onRefresh(); }}>Nice</Button></div>)}</section>;
}