import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

/**
 * Full-screen premium transition that plays ONLY after the user presses "Start Lockin".
 * Sequence (~1.8s total):
 *   1. Screen dims in
 *   2. Lock icon drops closed with shackle animation
 *   3. Ring pulse radiates outward
 *   4. "You're Locked In." fades in
 *   5. Brief hold
 *   6. Smooth fade out → onComplete
 */
export default function LockTransition({ emoji, goalName, onComplete }) {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    if (navigator.vibrate) navigator.vibrate([20, 40, 60]);
    const t1 = setTimeout(() => setPhase(1), 100);
    const t2 = setTimeout(() => setPhase(2), 600);
    const t3 = setTimeout(() => setPhase(3), 1000);
    const t4 = setTimeout(() => onComplete?.(), 1800);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); clearTimeout(t4); };
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.25 }}
      className="fixed inset-0 z-[100] bg-secondary flex flex-col items-center justify-center"
    >
      {/* Lock icon container */}
      <div className="relative w-24 h-24 flex items-center justify-center">
        {/* Ring pulse — radiates outward */}
        <AnimatePresence>
          {phase >= 1 && (
            <>
              <motion.div
                initial={{ scale: 0.5, opacity: 0.6 }}
                animate={{ scale: 2.5, opacity: 0 }}
                transition={{ duration: 0.9, ease: "easeOut" }}
                className="absolute inset-0 rounded-full border-2 border-white/25"
              />
              <motion.div
                initial={{ scale: 0.5, opacity: 0.4 }}
                animate={{ scale: 3.5, opacity: 0 }}
                transition={{ duration: 1.1, ease: "easeOut", delay: 0.15 }}
                className="absolute inset-0 rounded-full border border-white/15"
              />
            </>
          )}
        </AnimatePresence>

        {/* Lock SVG */}
        <motion.svg
          width="80"
          height="80"
          viewBox="0 0 72 72"
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
        >
          {/* Shackle — starts open, drops closed */}
          <motion.path
            d="M22 34 V24 a14 14 0 0 1 28 0 V34"
            stroke="white"
            strokeWidth="4"
            fill="none"
            strokeLinecap="round"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{ duration: 0.4, ease: "easeInOut" }}
          />
          {/* Lock body */}
          <motion.rect
            x="16"
            y="34"
            width="40"
            height="26"
            rx="7"
            fill="white"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, delay: 0.3 }}
          />
          {/* Keyhole */}
          <motion.circle
            cx="36"
            cy="45"
            r="3.5"
            fill="#1a2433"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.15, delay: 0.5, type: "spring", stiffness: 400 }}
          />
        </motion.svg>
      </div>

      {/* "You're Locked In." text */}
      <AnimatePresence>
        {phase >= 2 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="mt-10 text-center"
          >
            <p className="text-white font-heading font-bold text-2xl tracking-tight">
              You're Locked In.
            </p>
            {goalName && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.65 }}
                transition={{ delay: 0.2, duration: 0.3 }}
                className="text-white/60 text-sm mt-2"
              >
                {emoji} {goalName}
              </motion.p>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Final fade-out overlay */}
      <AnimatePresence>
        {phase >= 3 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4 }}
            className="absolute inset-0 bg-background"
          />
        )}
      </AnimatePresence>
    </motion.div>
  );
}