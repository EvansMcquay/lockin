import React from "react";
import { Outlet, Link, useLocation } from "react-router-dom";
import { Home, Calendar, Plus, Users } from "lucide-react";
import HomePage from "@/pages/Home";
import QuickLockinSetupPage from "@/pages/QuickLockinSetup";
import SchedulesPage from "@/pages/Schedules";
import CirclesPage from "@/pages/Circles";

const NAV_ITEMS = [
  { path: "/", icon: Home, label: "Today" },
  { path: "/lockin-setup", icon: Plus, label: "Start", primary: true },
  { path: "/schedules", icon: Calendar, label: "Plan" },
  { path: "/circles", icon: Users, label: "Circle" },
];

const PAGE_TITLES = {
  "/": "Today",
  "/lockin-setup": "Start Lockin",
  "/schedules": "Coming Up",
  "/circles": "Circles",
  "/stats": "Progress",
  "/locks": "History",
  "/session-complete": "Complete",
  "/schedule-builder": "New Schedule",
};

const TAB_PAGES = [
  { path: "/", Component: HomePage },
  { path: "/lockin-setup", Component: QuickLockinSetupPage },
  { path: "/schedules", Component: SchedulesPage },
  { path: "/circles", Component: CirclesPage },
];

export default function AppLayout() {
  const location = useLocation();
  const isTabPath = TAB_PAGES.some(t => t.path === location.pathname);
  const pageTitle = PAGE_TITLES[location.pathname] || "Lockin";

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col" style={{ paddingTop: "var(--safe-area-top)" }}>
      <header className="sticky top-0 z-40 bg-background/75 backdrop-blur-xl border-b border-border/70 flex-shrink-0">
        <div className="max-w-lg mx-auto h-12 flex items-center justify-center px-5">
          <h1 className="font-heading font-semibold text-sm tracking-[-0.02em] text-foreground/90">{pageTitle}</h1>
        </div>
      </header>

      <main className={`flex-1 overflow-y-auto ${location.pathname === "/" ? "pb-20" : "pb-28"}`}>
        {TAB_PAGES.map(({ path, Component }) => (
          <div key={path} className={location.pathname === path ? "" : "hidden"}>
            <Component />
          </div>
        ))}
        {!isTabPath && <Outlet />}
      </main>

      <footer className={`max-w-lg mx-auto w-full px-5 pb-32 ${location.pathname === "/" ? "hidden" : "flex"} items-center justify-center gap-5 text-xs text-muted-foreground`}>
        <Link to="/about" className="hover:text-foreground">About</Link>
        <Link to="/contact" className="hover:text-foreground">Contact</Link>
      </footer>

      <nav className="fixed bottom-0 inset-x-0 z-50 px-4 pb-3 pointer-events-none" style={{ paddingBottom: "calc(var(--safe-area-bottom) + 0.75rem)" }}>
        <div className="max-w-lg mx-auto pointer-events-auto rounded-[28px] border border-border/80 bg-card/90 backdrop-blur-xl shadow-2xl shadow-black/25 px-2 py-2 flex items-center justify-between">
          {NAV_ITEMS.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`relative flex min-w-0 flex-1 flex-col items-center gap-1 rounded-2xl px-2 py-2.5 transition-all duration-200 active:scale-95 ${
                  item.primary
                    ? "text-primary-foreground bg-primary shadow-lg shadow-primary/20"
                    : isActive ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <item.icon className="w-5 h-5" strokeWidth={isActive || item.primary ? 2.4 : 1.9} />
                <span className="text-[10px] font-medium leading-none tracking-[-0.01em]">{item.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}