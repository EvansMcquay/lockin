import React from "react";

const HOURS = Array.from({ length: 12 }, (_, i) => String(i + 1));
const MINUTES = ["00", "15", "30", "45"];
const PERIODS = ["AM", "PM"];
const DURATIONS = [
  { label: "15 minutes", value: 15 }, { label: "30 minutes", value: 30 }, { label: "45 minutes", value: 45 },
  { label: "1 hour", value: 60 }, { label: "1 hour 30 minutes", value: 90 }, { label: "2 hours", value: 120 },
];
const CUSTOM = [15, 30, 45, 60, 75, 90, 105, 120, 150, 180, 210, 240];

function ScrollColumn({ label, options, value, onSelect }) {
  return <div className="space-y-2">
    <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground text-center">{label}</p>
    <div className="h-36 overflow-y-auto rounded-2xl border border-border bg-background/60 p-1 snap-y snap-mandatory">
      {options.map(option => <button key={option} type="button" onClick={() => onSelect(option)} className={`w-full snap-center rounded-xl py-3 text-sm font-semibold transition-all ${String(value) === String(option) ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:bg-muted hover:text-foreground"}`}>{option}</button>)}
    </div>
  </div>;
}

function TimeSelect({ label, value, onChange }) {
  return <div className="space-y-3">
    <div className="flex items-center justify-between">
      <p className="text-sm font-semibold text-foreground">{label}</p>
      <p className="rounded-full bg-muted px-3 py-1 text-xs font-semibold text-muted-foreground">{value.hour}:{value.minute} {value.period}</p>
    </div>
    <div className="grid grid-cols-3 gap-2">
      <ScrollColumn label="Hour" options={HOURS} value={value.hour} onSelect={hour => onChange({ ...value, hour })} />
      <ScrollColumn label="Minute" options={MINUTES} value={value.minute} onSelect={minute => onChange({ ...value, minute })} />
      <ScrollColumn label="AM/PM" options={PERIODS} value={value.period} onSelect={period => onChange({ ...value, period })} />
    </div>
  </div>;
}

export default function TimeChoicePicker({ form, setForm }) {
  const setStart = startTime => setForm(prev => ({ ...prev, startTime }));
  const setEnd = endTime => setForm(prev => ({ ...prev, endTime }));
  return <section className="rounded-3xl border border-border bg-card p-4 space-y-4">
    <div>
      <p className="text-xs font-semibold uppercase tracking-widest text-primary">5–6. Choose time</p>
      <p className="text-xs text-muted-foreground mt-1">Scroll each column, then tap the time you want.</p>
    </div>
    <TimeSelect label="Start time" value={form.startTime} onChange={setStart} />
    <div className="grid grid-cols-2 gap-2">
      <button type="button" onClick={() => setForm(prev => ({ ...prev, timeMode: "end_time" }))} className={`rounded-2xl py-3 text-sm font-semibold ${form.timeMode === "end_time" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>End Time</button>
      <button type="button" onClick={() => setForm(prev => ({ ...prev, timeMode: "duration" }))} className={`rounded-2xl py-3 text-sm font-semibold ${form.timeMode === "duration" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>Duration</button>
    </div>
    {form.timeMode === "end_time" ? <TimeSelect label="End time" value={form.endTime} onChange={setEnd} /> : <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">{DURATIONS.map(d => <button key={d.value} type="button" onClick={() => setForm(prev => ({ ...prev, durationMinutes: d.value, customDuration: false }))} className={`rounded-2xl px-3 py-3 text-sm font-semibold ${form.durationMinutes === d.value && !form.customDuration ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>{d.label}</button>)}<button type="button" onClick={() => setForm(prev => ({ ...prev, customDuration: true }))} className={`col-span-2 rounded-2xl px-3 py-3 text-sm font-semibold ${form.customDuration ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>Custom</button></div>
      {form.customDuration && <div className="h-32 overflow-y-auto rounded-2xl border border-border bg-background/60 p-1">{CUSTOM.map(m => <button key={m} type="button" onClick={() => setForm(prev => ({ ...prev, durationMinutes: m, customDuration: true }))} className={`w-full rounded-xl py-3 text-sm font-semibold ${form.durationMinutes === m ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground"}`}>{m < 60 ? `${m} minutes` : `${Math.floor(m / 60)} hour${m >= 120 ? "s" : ""}${m % 60 ? ` ${m % 60} minutes` : ""}`}</button>)}</div>}
    </div>}
  </section>;
}