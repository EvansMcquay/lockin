import React from "react";
import { Link } from "react-router-dom";
import { Lock, Globe, ChevronRight } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function CircleCard({ circle }) {
  const PrivacyIcon = circle.privacy === "public" ? Globe : Lock;
  const { toast } = useToast();
  const copyCode = async (event) => {
    event.preventDefault();
    event.stopPropagation();
    await navigator.clipboard.writeText(circle.code);
    toast({ title: "Circle code copied" });
  };
  return (
    <Link to={`/circles/${circle.id}`} className="block">
      <div className="rounded-3xl border border-border bg-card p-4 active:scale-[0.98] transition-transform">
        <div className="flex items-start gap-3">
          <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-2xl flex-shrink-0">{circle.icon || "🤝"}</div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h3 className="font-heading font-bold text-base text-foreground truncate">{circle.name}</h3>
              <PrivacyIcon className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">{circle.member_count || 0}/8 members · {circle.privacy}</p>
            {circle.code && <button onClick={copyCode} className="text-xs font-mono tracking-[0.18em] text-primary mt-1">{circle.code}</button>}
            {circle.purpose && <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{circle.purpose}</p>}
            <div className="flex items-center justify-between mt-3">
              <div className="flex -space-x-2">
                {(circle.members || []).slice(0, 4).map(member => (
                  <div key={member.id} className="w-7 h-7 rounded-full bg-muted border-2 border-card flex items-center justify-center text-[10px] font-bold text-foreground">
                    {(member.display_name || "M").slice(0, 1).toUpperCase()}
                  </div>
                ))}
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}