import React from "react";
import { KeyRound, Lock, Settings, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CircleDetailActionPanel({ circle, isOwner, isFull, showSettings, onInvite, onStart, onCopyCode, onToggleSettings, onProfile }) {
  return (
    <section className="rounded-[28px] border border-border bg-card p-4 shadow-lg shadow-black/5 space-y-4">
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-2xl">{circle.icon}</div>
        <div className="min-w-0 flex-1">
          <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-muted-foreground">What should this Circle do next?</p>
          <h1 className="mt-1 font-heading font-bold text-xl text-foreground truncate">{circle.name}</h1>
          <p className="text-sm text-muted-foreground">{circle.member_count}/8 members · {circle.privacy} circle</p>
          {circle.purpose && <p className="mt-1 text-sm text-foreground line-clamp-2">{circle.purpose}</p>}
        </div>
      </div>

      <Button onClick={onStart} className="w-full rounded-2xl h-12">
        <Lock className="w-4 h-4" /> Start Together
      </Button>

      <div className="grid grid-cols-2 gap-2">
        {isOwner && (
          <Button variant="outline" onClick={onInvite} disabled={isFull} className="rounded-2xl">
            <UserPlus className="w-4 h-4" /> Invite
          </Button>
        )}
        {circle.code && (
          <button onClick={onCopyCode} className="inline-flex items-center justify-center gap-2 rounded-2xl bg-primary/10 px-3 py-2 text-xs font-mono font-semibold tracking-[0.18em] text-primary">
            <KeyRound className="w-3.5 h-3.5" /> {circle.code}
          </button>
        )}
      </div>

      <div className="flex -space-x-2">
        {circle.members.slice(0, 6).map(member => (
          <button key={member.id} onClick={() => onProfile(member.user_id)} className="w-8 h-8 rounded-full bg-primary/15 border-2 border-card text-xs font-bold text-foreground">
            {(member.display_name || member.username || "M").slice(0, 1).toUpperCase()}
          </button>
        ))}
      </div>

      {isOwner && (
        <Button variant="ghost" onClick={onToggleSettings} className="w-full rounded-2xl text-muted-foreground">
          <Settings className="w-4 h-4" /> {showSettings ? "Hide Settings" : "Circle Settings"}
        </Button>
      )}
    </section>
  );
}