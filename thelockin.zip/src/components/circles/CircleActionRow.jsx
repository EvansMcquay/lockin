import React from "react";
import { Calendar, Lock, UserPlus, Users } from "lucide-react";

const actions = [
  ["start", Lock, "Start Together"],
  ["schedule", Calendar, "Schedule"],
  ["invite", UserPlus, "Invite"],
  ["members", Users, "Members"],
];

export default function CircleActionRow({ onAction, inviteDisabled }) {
  return (
    <div className="grid grid-cols-4 gap-2">
      {actions.map(([id, Icon, label]) => (
        <button
          key={id}
          type="button"
          onClick={() => onAction(id)}
          disabled={id === "invite" && inviteDisabled}
          className="rounded-2xl border border-border bg-card/80 px-2 py-3 text-center text-xs font-bold text-foreground shadow-sm disabled:opacity-40"
        >
          <Icon className="w-4 h-4 mx-auto mb-1 text-primary" />
          {label}
        </button>
      ))}
    </div>
  );
}