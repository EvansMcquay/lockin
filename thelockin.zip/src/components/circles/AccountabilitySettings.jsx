import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { circleAction } from "@/lib/circlesApi";

export default function AccountabilitySettings({ members, circles = [], currentUserId, value, onSaved, onError }) {
  const [form, setForm] = useState(value);
  const [saving, setSaving] = useState(false);
  useEffect(() => setForm(value), [value]);
  if (!form) return null;
  const toggle = (field, id) => setForm(prev => ({ ...prev, [field]: (prev[field] || []).includes(id) ? prev[field].filter(x => x !== id) : [...(prev[field] || []), id] }));
  const people = members.filter(m => m.user_id !== currentUserId);
  const save = async () => {
    setSaving(true);
    try { await circleAction("updateAccountabilityPreference", form); onSaved?.(); }
    catch (error) { onError?.(error?.response?.data?.error || "Could not save accountability settings"); }
    finally { setSaving(false); }
  };
  return (
    <section className="rounded-3xl border border-border bg-card p-4 space-y-4">
      <div><h2 className="font-heading font-bold text-lg text-foreground">Who Can Help Keep Me On Track?</h2><p className="text-sm text-muted-foreground">Reminders are off unless you explicitly allow them.</p></div>
      <div className="space-y-2">
        <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Accountability Reminders</p>
        <select value={form.reminder_mode} onChange={e => setForm({ ...form, reminder_mode: e.target.value })} className="w-full rounded-2xl border border-input bg-background px-3 py-3 text-sm text-foreground">
          <option value="nobody">Nobody</option><option value="selected_people">Selected friends</option><option value="selected_circles">Everyone in selected Circles</option>
        </select>
      </div>
      <div className="space-y-2">
        <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Shared Lockin Invites</p>
        <select value={form.shared_invite_mode || "all_circle_members"} onChange={e => setForm({ ...form, shared_invite_mode: e.target.value })} className="w-full rounded-2xl border border-input bg-background px-3 py-3 text-sm text-foreground">
          <option value="all_circle_members">Allow from all Circle members</option><option value="selected_members">Allow from selected members</option><option value="off">Do not allow</option>
        </select>
      </div>
      {form.reminder_mode === "selected_people" && <div className="flex flex-wrap gap-2">{people.map(m => <button key={m.id} onClick={() => toggle("allowed_user_ids", m.user_id)} className={`rounded-full px-3 py-2 text-xs font-semibold ${(form.allowed_user_ids || []).includes(m.user_id) ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>@{m.username}</button>)}</div>}
      {form.reminder_mode === "selected_circles" && <div className="flex flex-wrap gap-2">{circles.map(c => <button key={c.id} onClick={() => toggle("allowed_circle_ids", c.id)} className={`rounded-full px-3 py-2 text-xs font-semibold ${(form.allowed_circle_ids || []).includes(c.id) ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>{c.name}</button>)}</div>}
      {form.shared_invite_mode === "selected_members" && <div className="flex flex-wrap gap-2">{people.map(m => <button key={m.id} onClick={() => toggle("shared_invite_allowed_user_ids", m.user_id)} className={`rounded-full px-3 py-2 text-xs font-semibold ${(form.shared_invite_allowed_user_ids || []).includes(m.user_id) ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>@{m.username}</button>)}</div>}
      <div className="grid grid-cols-2 gap-2 text-xs">{[["show_joined_status","Show Joined"],["show_started_status","Show Started"],["show_completed_status","Show Completed"],["allow_late_join_requests","Late Join Requests"]].map(([key,label]) => <button key={key} onClick={() => setForm({ ...form, [key]: !form[key] })} className={`rounded-2xl px-3 py-3 font-semibold ${form[key] ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>{label}: {form[key] ? "On" : "Off"}</button>)}</div>
      <Button onClick={save} disabled={saving} className="w-full rounded-2xl">{saving ? "Saving..." : "Save Accountability Settings"}</Button>
    </section>
  );
}