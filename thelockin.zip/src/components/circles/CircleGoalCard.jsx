import React, { useState } from "react";
import { Button } from "@/components/ui/button";

const LABELS = {
  total_completed: "total Lockins completed",
  shared_completed: "shared Lockins completed",
  Homework: "Homework Lockins completed",
  Work: "Work Lockins completed",
  Gym: "Gym Lockins completed",
  Sleep: "Sleep Lockins completed",
  Custom: "custom Lockins completed",
};

export default function CircleGoalCard({ goal, isOwner, preference, onCreate, onTogglePrivacy }) {
  const [saving, setSaving] = useState(false);
  if (!goal) {
    return <section className="rounded-3xl border border-border bg-card p-4 space-y-3">
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-primary">Circle Goal</p>
        <h2 className="font-heading font-bold text-lg text-foreground">Build momentum together</h2>
        <p className="text-sm text-muted-foreground">Set one cooperative goal for the Circle. No rankings, just shared progress.</p>
      </div>
      {isOwner && <Button onClick={onCreate} className="w-full rounded-2xl">Create Circle Goal</Button>}
    </section>;
  }

  const current = Math.min(goal.current_amount || 0, goal.target_amount || 1);
  const target = Math.max(1, goal.target_amount || 1);
  const remaining = Math.max(0, target - current);
  const progress = Math.min(100, Math.round((current / target) * 100));
  const complete = current >= target;
  const label = goal.goal_type === "Custom" && goal.custom_category ? `${goal.custom_category} Lockins completed` : LABELS[goal.goal_type] || "Lockins completed";

  return <section className={`rounded-3xl border p-4 space-y-4 ${complete ? "border-primary/30 bg-primary/10" : "border-border bg-card"}`}>
    <div className="flex items-start justify-between gap-3">
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-primary">Active Circle Goal</p>
        <h2 className="font-heading font-bold text-lg text-foreground">{goal.title || "Circle Goal"}</h2>
        <p className="text-sm text-muted-foreground">{current} of {target} {label}</p>
      </div>
      {complete && <span className="text-2xl">✅</span>}
    </div>
    <div className="h-2 rounded-full bg-muted overflow-hidden"><div className="h-full rounded-full bg-primary transition-all" style={{ width: `${progress}%` }} /></div>
    <p className="text-sm font-semibold text-foreground">{complete ? `${target} completed together.` : `${remaining} more to reach the goal.`}</p>
    <p className="text-xs text-muted-foreground">{complete ? "Circle Goal Complete" : remaining <= 3 ? "Almost there" : "The Circle is building momentum"}</p>
    <button type="button" disabled={saving} onClick={async () => { setSaving(true); await onTogglePrivacy(!(preference?.show_contributions !== false)); setSaving(false); }} className="w-full rounded-2xl bg-muted px-3 py-3 text-xs font-semibold text-muted-foreground">
      {preference?.show_contributions !== false ? "Show my contributions" : "Keep my contribution count private"}
    </button>
    {complete && <div className="grid grid-cols-2 gap-2"><Button variant="outline" className="rounded-2xl">Celebrate</Button>{isOwner && <Button onClick={onCreate} className="rounded-2xl">Create Another</Button>}</div>}
  </section>;
}