import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";

const options = [
  { value: "everyone", label: "Everyone in this Circle" },
  { value: "selected", label: "Selected members only" },
  { value: "nobody", label: "Nobody" },
];

export default function CircleSharingSettings({ members, currentUserId, sharing, saving, onSave }) {
  const [form, setForm] = useState(sharing);
  useEffect(() => setForm(sharing), [sharing]);
  const others = members.filter(m => m.user_id !== currentUserId);
  const toggleSelected = (field, id) => setForm(prev => ({ ...prev, [field]: prev[field]?.includes(id) ? prev[field].filter(v => v !== id) : [...(prev[field] || []), id] }));

  return (
    <div className="rounded-3xl bg-card border border-border p-4 space-y-4">
      <div>
        <h2 className="font-heading font-bold text-lg text-foreground">Sharing and Accountability</h2>
        <p className="text-xs text-muted-foreground">Missed and failed sessions are never shared.</p>
      </div>
      <ShareSelect label="Share when I start a Lockin" value={form.started_visibility} onChange={value => setForm({ ...form, started_visibility: value })} />
      {form.started_visibility === "selected" && <MemberPicker members={others} selected={form.started_selected_user_ids || []} onToggle={id => toggleSelected("started_selected_user_ids", id)} />}
      <ShareSelect label="Share when I complete a Lockin" value={form.completed_visibility} onChange={value => setForm({ ...form, completed_visibility: value })} />
      {form.completed_visibility === "selected" && <MemberPicker members={others} selected={form.completed_selected_user_ids || []} onToggle={id => toggleSelected("completed_selected_user_ids", id)} />}
      <ToggleRow label="Allow reactions" checked={form.allow_reactions !== false} onChange={checked => setForm({ ...form, allow_reactions: checked })} />
      <ToggleRow label="Allow encouragement messages" checked={form.allow_messages !== false} onChange={checked => setForm({ ...form, allow_messages: checked })} />
      <Button onClick={() => onSave(form)} disabled={saving} className="w-full rounded-2xl">{saving ? "Saving..." : "Save Sharing Settings"}</Button>
    </div>
  );
}

function ShareSelect({ label, value, onChange }) {
  return <label className="block space-y-1.5"><span className="text-sm font-semibold text-foreground">{label}</span><select value={value} onChange={e => onChange(e.target.value)} className="w-full h-11 rounded-2xl border border-input bg-background px-3 text-sm text-foreground">{options.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label>;
}
function ToggleRow({ label, checked, onChange }) {
  return <div className="flex items-center justify-between gap-3"><span className="text-sm font-semibold text-foreground">{label}</span><Switch checked={checked} onCheckedChange={onChange} /></div>;
}
function MemberPicker({ members, selected, onToggle }) {
  return <div className="rounded-2xl bg-muted/40 p-2 space-y-1">{members.map(member => <button key={member.user_id} type="button" onClick={() => onToggle(member.user_id)} className="w-full flex items-center justify-between text-left rounded-xl px-2 py-1.5 text-sm text-foreground"><span>@{member.username}</span><span>{selected.includes(member.user_id) ? "✓" : ""}</span></button>)}</div>;
}