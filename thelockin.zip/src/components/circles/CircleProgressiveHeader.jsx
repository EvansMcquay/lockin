import React from "react";
import { Plus, KeyRound, Link2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CircleProgressiveHeader({ username, onCreate, onJoin, onInviteLink }) {
  return (
    <section className="rounded-[28px] border border-white/10 bg-white/5 p-5 shadow-lg shadow-black/10 backdrop-blur space-y-4">
      <div className="space-y-2">
        <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/60">Circles</p>
        <h1 className="font-heading text-2xl font-bold leading-tight text-white">Join or create?</h1>
        <p className="text-sm leading-relaxed text-white/75">Start with one trusted group, then lock in together when you are ready.</p>
        {username && <p className="text-xs font-semibold text-white/70">Your username: @{username}</p>}
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Button variant="outline" onClick={onJoin} className="h-12 rounded-2xl border-white/15 bg-white/10 text-white hover:bg-white/15">
          <KeyRound className="w-4 h-4" /> Join
        </Button>
        <Button onClick={onCreate} className="h-12 rounded-2xl">
          <Plus className="w-4 h-4" /> Create
        </Button>
      </div>

      <button onClick={onInviteLink} className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-white/5 px-3 py-2 text-xs font-semibold text-white/70">
        <Link2 className="w-3.5 h-3.5" /> I have an invite link
      </button>
    </section>
  );
}