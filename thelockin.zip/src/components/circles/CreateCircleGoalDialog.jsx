import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const TYPES = [
  { value: "total_completed", label: "Total Lockins Completed" },
  { value: "shared_completed", label: "Shared Lockins Completed" },
  { value: "Homework", label: "Homework Lockins" },
  { value: "Work", label: "Work Lockins" },
  { value: "Gym", label: "Gym Lockins" },
  { value: "Sleep", label: "Sleep Lockins" },
  { value: "Custom", label: "Custom category" },
];
const PERIODS = [
  { value: "this_week", label: "This Week" },
  { value: "this_month", label: "This Month" },
  { value: "custom", label: "Custom Date Range" },
];

export default function CreateCircleGoalDialog({ open, onOpenChange, onCreate }) {
  const [form, setForm] = useState({ goal_type: "Homework", target_amount: 20, period: "this_week", title: "", custom_category: "", start_date: "", end_date: "" });
  const [saving, setSaving] = useState(false);
  const submit = async () => {
    setSaving(true);
    await onCreate(form);
    setSaving(false);
    onOpenChange(false);
  };

  return <Dialog open={open} onOpenChange={onOpenChange}>
    <DialogContent className="rounded-3xl max-w-md">
      <DialogHeader><DialogTitle>Create Circle Goal</DialogTitle></DialogHeader>
      <div className="space-y-4">
        <Input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="Optional title, e.g. Finals Week Push" className="rounded-2xl" />
        <div className="grid grid-cols-2 gap-2">{TYPES.map(type => <button key={type.value} type="button" onClick={() => setForm({ ...form, goal_type: type.value })} className={`rounded-2xl px-3 py-3 text-xs font-semibold ${form.goal_type === type.value ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>{type.label}</button>)}</div>
        {form.goal_type === "Custom" && <Input value={form.custom_category} onChange={e => setForm({ ...form, custom_category: e.target.value })} placeholder="Custom category" className="rounded-2xl" />}
        <Input type="number" min="1" value={form.target_amount} onChange={e => setForm({ ...form, target_amount: Number(e.target.value) })} placeholder="Target amount" className="rounded-2xl" />
        <div className="grid grid-cols-3 gap-2">{PERIODS.map(period => <button key={period.value} type="button" onClick={() => setForm({ ...form, period: period.value })} className={`rounded-2xl px-2 py-3 text-xs font-semibold ${form.period === period.value ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>{period.label}</button>)}</div>
        {form.period === "custom" && <div className="grid grid-cols-2 gap-2"><Input type="date" value={form.start_date} onChange={e => setForm({ ...form, start_date: e.target.value })} className="rounded-2xl" /><Input type="date" value={form.end_date} onChange={e => setForm({ ...form, end_date: e.target.value })} className="rounded-2xl" /></div>}
        <Button onClick={submit} disabled={saving || !form.target_amount || (form.period === "custom" && (!form.start_date || !form.end_date))} className="w-full rounded-2xl">{saving ? "Creating..." : "Create Goal"}</Button>
      </div>
    </DialogContent>
  </Dialog>;
}