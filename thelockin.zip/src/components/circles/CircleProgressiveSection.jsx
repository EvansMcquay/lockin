import React from "react";

export default function CircleProgressiveSection({ sections, activeSection, onChange }) {
  const active = sections.find(section => section.id === activeSection);

  return (
    <section className="rounded-[28px] border border-border bg-card p-4 shadow-lg shadow-black/5 space-y-3">
      <div>
        <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Choose one thing</p>
        <h2 className="font-heading font-bold text-lg text-foreground">What should we handle now?</h2>
      </div>

      <div className="grid grid-cols-2 gap-2">
        {sections.map(section => (
          <button
            key={section.id}
            type="button"
            onClick={() => onChange(activeSection === section.id ? null : section.id)}
            className={`rounded-2xl border px-3 py-3 text-left transition-all ${activeSection === section.id ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/30 text-foreground"}`}
          >
            <span className="block text-sm font-bold">{section.title}</span>
            <span className="block text-xs text-muted-foreground mt-0.5">{section.subtitle}</span>
          </button>
        ))}
      </div>

      {active ? (
        <div className="pt-1 space-y-3">
          {active.content}
        </div>
      ) : (
        <p className="rounded-2xl bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
          Keep the Circle page light. Open only what you need right now.
        </p>
      )}
    </section>
  );
}