import React, { useEffect, useState } from "react";
import { Share2, UserRound, Search, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { circleAction } from "@/lib/circlesApi";

const statusLabel = {
  none: "Invite",
  pending: "Pending",
  accepted: "Accepted",
  declined: "Declined",
  expired: "Expired",
};

export default function InviteCircleDialog({ open, onOpenChange, circle, circleId, onSent, onError }) {
  const [mode, setMode] = useState("options");
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [selected, setSelected] = useState([]);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (!open) {
      setMode("options");
      setQuery("");
      setResults([]);
      setSelected([]);
    }
  }, [open]);

  useEffect(() => {
    if (mode !== "username" || query.trim().length < 2) {
      setResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const data = await circleAction("searchInviteUsers", { circleId, query });
        setResults(data.users || []);
      } catch (error) {
        onError(error?.response?.data?.error || "Could not search users");
      } finally {
        setLoading(false);
      }
    }, 250);
    return () => clearTimeout(timer);
  }, [circleId, mode, query]);

  const buildInvite = async () => {
    const invite = await circleAction("createInviteLink", { circleId });
    const link = `${window.location.origin}/circles?invite=${invite.token}`;
    return {
      link,
      title: "Join my Circle on Lockin",
      message: "I'm inviting you to join my Circle on Lockin. Tap the link below to join.",
    };
  };

  const inviteByShare = async () => {
    try {
      const invite = await buildInvite();
      if (navigator.share) {
        await navigator.share({ title: invite.title, text: invite.message, url: invite.link });
        onSent("Circle invite shared.");
      } else {
        await navigator.clipboard.writeText(invite.link);
        onSent("Invite link copied.");
      }
    } catch (error) {
      if (error?.name !== "AbortError") onError(error?.response?.data?.error || "Could not share invite");
    }
  };

  const toggleUser = (user) => {
    if (user.is_member || user.invite_status !== "none") return;
    setSelected(prev => prev.some(item => item.id === user.id) ? prev.filter(item => item.id !== user.id) : [...prev, user]);
  };

  const sendUsernameInvites = async () => {
    setSending(true);
    try {
      await circleAction("inviteUsers", { circleId, userIds: selected.map(user => user.id) });
      onSent();
      onOpenChange(false);
    } catch (error) {
      onError(error?.response?.data?.error || "Could not send invite");
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-3xl max-w-md">
        <DialogHeader><DialogTitle>Invite to Circle</DialogTitle></DialogHeader>
        {mode === "options" ? (
          <div className="grid grid-cols-2 gap-3">
            <InviteOption icon={UserRound} label="Username" description="Invite Lockin users" onClick={() => setMode("username")} />
            <InviteOption icon={Share2} label="Share" onClick={inviteByShare} />
          </div>
        ) : (
          <div className="space-y-3">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 w-4 h-4 -translate-y-1/2 text-muted-foreground" />
              <Input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search username" className="rounded-2xl pl-10" autoFocus />
            </div>
            <div className="max-h-72 overflow-y-auto space-y-2">
              {query.trim().length < 2 && <p className="text-sm text-muted-foreground text-center py-4">Type at least 2 characters.</p>}
              {loading && <p className="text-sm text-muted-foreground text-center py-4">Searching...</p>}
              {!loading && query.trim().length >= 2 && results.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">No users found.</p>}
              {results.map(user => {
                const checked = selected.some(item => item.id === user.id);
                const disabled = user.is_member || user.invite_status !== "none";
                return (
                  <button key={user.id} onClick={() => toggleUser(user)} disabled={disabled} className="w-full rounded-2xl bg-muted/50 p-3 flex items-center gap-3 text-left disabled:opacity-60">
                    {user.profile_image_url ? <img src={user.profile_image_url} alt="" className="w-10 h-10 rounded-full object-cover" /> : <div className="w-10 h-10 rounded-full bg-primary/15 flex items-center justify-center text-sm font-bold text-foreground">{user.display_name.slice(0, 1).toUpperCase()}</div>}
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-foreground truncate">{user.display_name}</p>
                      <p className="text-xs text-muted-foreground truncate">@{user.username}</p>
                    </div>
                    <span className={`text-xs font-semibold ${checked ? "text-primary" : "text-muted-foreground"}`}>{checked ? <Check className="w-4 h-4" /> : statusLabel[user.invite_status] || "Invite"}</span>
                  </button>
                );
              })}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" onClick={() => setMode("options")} className="rounded-2xl">Back</Button>
              <Button onClick={sendUsernameInvites} disabled={sending || selected.length === 0} className="rounded-2xl">{sending ? "Sending..." : "Send Invite"}</Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function InviteOption({ icon: Icon, label, description, onClick }) {
  return (
    <Button variant="outline" onClick={onClick} className="h-28 rounded-3xl flex-col gap-2 px-3 text-center">
      <Icon className="w-5 h-5" />
      <span className="font-semibold">{label}</span>
      {description && <span className="text-xs font-normal text-muted-foreground">{description}</span>}
    </Button>
  );
}