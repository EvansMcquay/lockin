import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function CircleLivingHero({ circle, eyebrow, title, description, summary = [], primaryLabel, primaryTo, onPrimary, secondaryLabel, secondaryTo, onSecondary }) {
  return (
    <section className="rounded-[30px] border border-border bg-card p-5 shadow-xl shadow-black/10 space-y-4">
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-2xl">{circle.icon}</div>
        <div className="min-w-0 flex-1">
          <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-muted-foreground">{eyebrow}</p>
          <h1 className="mt-1 font-heading font-bold text-2xl text-foreground leading-tight">{title}</h1>
          {description && <p className="mt-1 text-sm text-muted-foreground leading-relaxed">{description}</p>}
        </div>
      </div>

      {summary.length > 0 && (
        <div className="grid grid-cols-3 gap-2">
          {summary.map(item => (
            <div key={item.label} className="rounded-2xl bg-muted/40 px-3 py-2">
              <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-muted-foreground">{item.label}</p>
              <p className="mt-0.5 text-sm font-bold text-foreground truncate">{item.value}</p>
            </div>
          ))}
        </div>
      )}

      <div className="space-y-2">
        {primaryTo ? (
          <Button asChild className="w-full h-12 rounded-2xl text-base"><Link to={primaryTo}>{primaryLabel}</Link></Button>
        ) : (
          <Button onClick={onPrimary} className="w-full h-12 rounded-2xl text-base">{primaryLabel}</Button>
        )}
        {secondaryLabel && (secondaryTo ? (
          <Button asChild variant="outline" className="w-full h-11 rounded-2xl"><Link to={secondaryTo}>{secondaryLabel}</Link></Button>
        ) : (
          <Button onClick={onSecondary} variant="outline" className="w-full h-11 rounded-2xl">{secondaryLabel}</Button>
        ))}
      </div>
    </section>
  );
}