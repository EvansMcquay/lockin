import React from "react";
import { Button } from "@/components/ui/button";

const DAY_NAMES = { 0: "Sunday", 1: "Monday", 2: "Tuesday", 3: "Wednesday", 4: "Thursday", 5: "Friday", 6: "Saturday" };

export default function SharedLockinReview({ title, form, circle, invited, timeLabel, dateLabel, saving, onEdit, onSend }) {
  const invitedNames = invited.length ? invited.map(m => m.display_name).join(" and ") : "None selected";
  return <div className="rounded-3xl border border-border bg-card p-5 space-y-4">
    <div>
      <p className="text-xs font-semibold uppercase tracking-widest text-primary">9. Review</p>
      <h2 className="text-xl font-bold text-foreground">{title}</h2>
      <p className="text-sm text-muted-foreground">{form.focus || "Optional goal"}</p>
    </div>
    <div className="rounded-2xl bg-muted/50 p-4 text-sm text-foreground space-y-3">
      <div className="flex items-start justify-between gap-3"><span><span className="block font-semibold">{dateLabel}</span>{form.selectedDays?.length > 1 && <span className="block text-muted-foreground">{form.selectedDays.map(day => DAY_NAMES[day]).join(", ")}</span>}</span><button type="button" onClick={onEdit} className="text-xs font-semibold text-primary">Edit</button></div>
      <div className="flex items-start justify-between gap-3"><span><span className="block font-semibold">{timeLabel}</span><span className="block text-muted-foreground">{form.timeMode === "duration" ? `${form.durationMinutes} minute duration` : "Start and end time"}</span></span><button type="button" onClick={onEdit} className="text-xs font-semibold text-primary">Edit</button></div>
      <div className="flex items-start justify-between gap-3"><span><span className="block font-semibold">{form.repeatMode === "every_week" ? "Repeats every week" : "One time"}</span><span className="block text-muted-foreground">Circle: {circle?.name}</span></span><button type="button" onClick={onEdit} className="text-xs font-semibold text-primary">Edit</button></div>
      <div className="flex items-start justify-between gap-3"><span><span className="block font-semibold">Invited</span><span className="block text-muted-foreground">{invitedNames}</span></span><button type="button" onClick={onEdit} className="text-xs font-semibold text-primary">Edit</button></div>
    </div>
    <p className="text-xs text-muted-foreground">Each person chooses their own locked apps privately.</p>
    <div className="grid grid-cols-2 gap-2"><Button variant="outline" onClick={onEdit} className="rounded-2xl">Edit Details</Button><Button onClick={onSend} disabled={saving} className="rounded-2xl">{saving ? "Sending..." : "Send Invite"}</Button></div>
  </div>;
}