import React, { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import TimeChoicePicker from "@/components/circles/TimeChoicePicker";

function ymd(date) { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`; }
function partsFromDate(date) { const hours = date.getHours(); return { hour: String(hours % 12 || 12), minute: String(Math.round(date.getMinutes() / 15) * 15).padStart(2, "0").replace("60", "00"), period: hours >= 12 ? "PM" : "AM" }; }
function combine(dateValue, time) { const date = new Date(`${dateValue}T12:00`); let hour = Number(time.hour) % 12; if (time.period === "PM") hour += 12; return new Date(date.getFullYear(), date.getMonth(), date.getDate(), hour, Number(time.minute), 0, 0); }
function nextWeekday() { const date = new Date(); do { date.setDate(date.getDate() + 1); } while ([0, 6].includes(date.getDay())); return date; }
function thisWeekend() { const date = new Date(); const offset = date.getDay() === 6 ? 0 : (6 - date.getDay() + 7) % 7; date.setDate(date.getDate() + offset); return date; }

export default function QuickReschedulePanel({ item, onReschedule }) {
  const duration = item.duration_minutes || 60;
  const initialStart = useMemo(() => new Date(item.start_at), [item.start_at]);
  const initialEnd = useMemo(() => new Date(item.end_at), [item.end_at]);
  const [customOpen, setCustomOpen] = useState(false);
  const [date, setDate] = useState(ymd(initialStart));
  const [form, setForm] = useState({ startTime: partsFromDate(initialStart), endTime: partsFromDate(initialEnd), timeMode: "duration", durationMinutes: duration, customDuration: false });

  const quick = (label) => {
    const start = new Date(item.start_at);
    if (label === "later") start.setHours(Math.max(new Date().getHours() + 1, start.getHours()), start.getMinutes(), 0, 0);
    if (label === "tomorrow") start.setDate(new Date().getDate() + 1);
    if (label === "weekday") { const next = nextWeekday(); start.setFullYear(next.getFullYear(), next.getMonth(), next.getDate()); }
    if (label === "weekend") { const next = thisWeekend(); start.setFullYear(next.getFullYear(), next.getMonth(), next.getDate()); }
    const end = new Date(start.getTime() + duration * 60000);
    onReschedule(start, end);
  };
  const submitCustom = () => {
    const start = combine(date, form.startTime);
    const end = form.timeMode === "duration" ? new Date(start.getTime() + Number(form.durationMinutes || duration) * 60000) : combine(date, form.endTime);
    onReschedule(start, end);
  };

  return <section className="rounded-3xl border border-border bg-card p-4 space-y-3">
    <div><p className="text-xs font-semibold uppercase tracking-widest text-primary">Quick Reschedule</p><p className="text-sm text-muted-foreground">Keep the same people, goal, and duration.</p></div>
    <div className="grid grid-cols-2 gap-2">
      <Button variant="outline" onClick={() => quick("later")} className="rounded-2xl">Later Today</Button>
      <Button variant="outline" onClick={() => quick("tomorrow")} className="rounded-2xl">Tomorrow</Button>
      <Button variant="outline" onClick={() => quick("weekday")} className="rounded-2xl">Next Weekday</Button>
      <Button variant="outline" onClick={() => quick("weekend")} className="rounded-2xl">This Weekend</Button>
    </div>
    <button type="button" onClick={() => setCustomOpen(!customOpen)} className="w-full rounded-2xl bg-muted px-3 py-3 text-sm font-semibold text-foreground">Pick Date and Time</button>
    {customOpen && <div className="space-y-3"><input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full rounded-2xl border border-input bg-background px-4 py-3 text-sm text-foreground" /><TimeChoicePicker form={form} setForm={setForm} /><Button onClick={submitCustom} className="w-full rounded-2xl">Save New Time</Button></div>}
  </section>;
}