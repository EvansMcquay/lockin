import React from "react";
import SharedLockinCard from "@/components/circles/SharedLockinCard";

export default function SharedLockinInbox({ items = [] }) {
  if (!items.length) return null;
  return <section className="space-y-3"><h2 className="font-heading font-bold text-lg text-foreground">Shared Lockins</h2>{items.map(item => <SharedLockinCard key={item.id} item={item} />)}</section>;
}