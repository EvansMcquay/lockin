import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function CircleMoreDialog({ open, onOpenChange, items, activeId, onSelect }) {
  const active = items.find(item => item.id === activeId);

  if (!open) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{active ? active.title : "More"}</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-2">
          {items.map(item => (
            <button
              key={item.id}
              type="button"
              onClick={() => item.onClick ? item.onClick() : onSelect(item.id)}
              className={`rounded-2xl border px-3 py-3 text-left text-sm font-bold ${item.danger ? "border-destructive/30 bg-destructive/10 text-destructive" : activeId === item.id ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/30 text-foreground"}`}
            >
              {item.title}
            </button>
          ))}
        </div>

        {active?.content && <div className="pt-2 space-y-3">{active.content}</div>}
      </DialogContent>
    </Dialog>
  );
}