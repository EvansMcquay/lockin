import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Flag, Trash2 } from "lucide-react";

function formatTime(value) {
  if (!value) return "Just now";
  return new Date(value).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

function duration(minutes) {
  return `${minutes || 0} minute${Number(minutes) === 1 ? "" : "s"}`;
}

export default function CircleActivityCard({ item, reactions, currentUserId, onReact, onMessage, onDeleteMessage, onReportMessage, onProfile, onStartYours }) {
  const [message, setMessage] = useState("");
  const isLockin = item.type === "lockin_started" || item.type === "lockin_completed";
  const completed = item.type === "lockin_completed";
  const joined = item.type === "member_joined";

  return (
    <div className="rounded-3xl border border-border bg-card p-4 space-y-3">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-2xl bg-primary/10 flex items-center justify-center text-lg">{completed ? "✅" : joined ? "🤝" : "🟢"}</div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-foreground">
            <button onClick={() => onProfile(item.actor_user_id)} className="text-primary">@{item.actor_username}</button>{" "}
            {completed ? "completed" : joined ? "joined the Circle" : "started"}{isLockin && ` a ${item.template_name || "Lockin"} Lockin`}
          </p>
          {item.focus && <p className="text-sm text-muted-foreground mt-1">{item.focus}</p>}
          {isLockin && <p className="text-xs text-muted-foreground mt-1">{duration(item.duration_minutes)} · {formatTime(completed ? item.completed_at : item.started_at)}{item.status === "active" && !completed ? " · Active" : ""}</p>}
        </div>
      </div>

      {isLockin && (
        <>
          {item.allow_reactions && (
            <div className="flex flex-wrap gap-1.5">
              {reactions.map(emoji => (
                <button key={emoji} onClick={() => onReact(item.id, emoji)} className={`rounded-full border px-2.5 py-1 text-sm ${item.my_reactions?.includes(emoji) ? "bg-primary/15 border-primary/30" : "bg-muted/40 border-border"}`}>
                  {emoji} {item.reaction_counts?.[emoji] || ""}
                </button>
              ))}
            </div>
          )}

          {item.allow_messages && (
            <div className="space-y-2">
              {item.encouragements?.map(msg => (
                <div key={msg.id} className="rounded-2xl bg-muted/40 p-2.5 text-xs text-foreground">
                  <span className="font-semibold">@{msg.username}</span> {msg.message}
                  <div className="flex gap-2 mt-1 text-muted-foreground">
                    {msg.user_id === currentUserId ? <button onClick={() => onDeleteMessage(msg.id)} className="inline-flex items-center gap-1"><Trash2 className="w-3 h-3" /> Delete</button> : <button onClick={() => onReportMessage(msg.id)} className="inline-flex items-center gap-1"><Flag className="w-3 h-3" /> Report</button>}
                  </div>
                </div>
              ))}
              <div className="flex gap-2">
                <Input value={message} onChange={e => setMessage(e.target.value.slice(0, 100))} placeholder="Encourage them..." className="h-10 rounded-2xl text-sm" />
                <Button size="sm" onClick={() => { onMessage(item.id, message); setMessage(""); }} disabled={!message.trim()} className="rounded-2xl">Send</Button>
              </div>
            </div>
          )}

          <Button variant="outline" size="sm" onClick={onStartYours} className="w-full rounded-2xl">Start Yours</Button>
        </>
      )}
    </div>
  );
}