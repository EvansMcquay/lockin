import React, { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { circleAction } from "@/lib/circlesApi";

export default function UsernamePromptDialog({ open, onCreated }) {
  const [username, setUsername] = useState("");
  const [status, setStatus] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (username.length < 3) { setStatus(null); return; }
    const id = setTimeout(async () => setStatus(await circleAction("checkUsernameAvailability", { username })), 350);
    return () => clearTimeout(id);
  }, [username]);

  const save = async () => {
    setSaving(true);
    try {
      const result = await circleAction("updateUsername", { username });
      onCreated(result.username);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open}>
      <DialogContent className="rounded-3xl">
        <DialogHeader><DialogTitle>Create your Circle username</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">Choose a unique @username before using Circles.</p>
          <div className="relative"><span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">@</span><Input value={username} onChange={e => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9._]/g, "").slice(0, 20))} className="pl-8 rounded-2xl" placeholder="jameslocks" autoFocus /></div>
          {status && <p className={`text-xs ${status.available ? "text-success" : "text-destructive"}`}>{status.available ? "Username available." : status.reason || "That username is already taken."}</p>}
          {status?.suggestions?.length > 0 && <div className="flex flex-wrap gap-2">{status.suggestions.map(s => <button key={s} onClick={() => setUsername(s)} className="rounded-full bg-muted px-3 py-1 text-xs text-foreground">@{s}</button>)}</div>}
          <Button onClick={save} disabled={saving || !status?.available} className="w-full rounded-2xl">{saving ? "Saving..." : "Continue"}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}