import React from "react";

const OPTIONS = [
  { value: "today", label: "Today" },
  { value: "tomorrow", label: "Tomorrow" },
  { value: "weekdays", label: "Weekdays" },
  { value: "weekend", label: "Weekend" },
  { value: "specific", label: "Pick Specific Date" },
];
const DAYS = [
  { value: 1, label: "Monday" }, { value: 2, label: "Tuesday" }, { value: 3, label: "Wednesday" },
  { value: 4, label: "Thursday" }, { value: 5, label: "Friday" }, { value: 6, label: "Saturday" }, { value: 0, label: "Sunday" },
];

function daysFor(option, specificDate) {
  if (option === "weekdays") return [1, 2, 3, 4, 5];
  if (option === "weekend") return [6, 0];
  const date = option === "tomorrow" ? new Date(Date.now() + 86400000) : option === "specific" ? new Date(`${specificDate}T12:00`) : new Date();
  return [date.getDay()];
}

export default function DateOptionSelector({ form, setForm }) {
  const updateOption = (dateOption) => setForm(prev => ({ ...prev, dateOption, selectedDays: daysFor(dateOption, prev.specificDate) }));
  const toggleDay = (day) => setForm(prev => ({ ...prev, selectedDays: prev.selectedDays.includes(day) ? prev.selectedDays.filter(d => d !== day) : [...prev.selectedDays, day] }));
  const showDays = ["weekdays", "weekend"].includes(form.dateOption);
  const availableDays = DAYS.filter(d => daysFor(form.dateOption, form.specificDate).includes(d.value));
  const selectedLabels = DAYS.filter(d => form.selectedDays.includes(d.value)).map(d => d.label);

  return <div className="space-y-4">
    <section className="rounded-3xl border border-border bg-card p-4 space-y-3">
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-primary">3. Choose date option</p>
        <p className="text-xs text-muted-foreground mt-1">Start simple, then remove days if needed.</p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {OPTIONS.map(option => <button key={option.value} type="button" onClick={() => updateOption(option.value)} className={`rounded-2xl px-3 py-3 text-sm font-semibold ${form.dateOption === option.value ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>{option.label}</button>)}
      </div>
      {form.dateOption === "specific" && <input type="date" value={form.specificDate} onChange={e => setForm(prev => ({ ...prev, specificDate: e.target.value, selectedDays: daysFor("specific", e.target.value) }))} className="w-full rounded-2xl border border-input bg-background px-4 py-3 text-sm text-foreground" />}
      {showDays && <div className="space-y-2">
        <p className="text-xs font-semibold text-muted-foreground">Selected: {selectedLabels.length ? selectedLabels.join(", ") : "Choose at least one day"}</p>
        <div className="flex flex-wrap gap-2">{availableDays.map(day => <button key={day.value} type="button" onClick={() => toggleDay(day.value)} className={`rounded-full px-3 py-2 text-xs font-semibold ${form.selectedDays.includes(day.value) ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground line-through"}`}>{day.label}</button>)}</div>
        <p className="text-xs text-muted-foreground">Tap a day to remove or add it back.</p>
      </div>}
    </section>
    <section className="rounded-3xl border border-border bg-card p-4 space-y-3">
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-primary">4. Repeat this Lockin?</p>
        <p className="text-xs text-muted-foreground mt-1">Keep it one time or repeat the selected days every week.</p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <button type="button" onClick={() => setForm(prev => ({ ...prev, repeatMode: "one_time" }))} className={`rounded-2xl py-3 text-sm font-semibold ${form.repeatMode === "one_time" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>One Time</button>
        <button type="button" onClick={() => setForm(prev => ({ ...prev, repeatMode: "every_week" }))} className={`rounded-2xl py-3 text-sm font-semibold ${form.repeatMode === "every_week" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>Every Week</button>
      </div>
    </section>
  </div>;
}