import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function CreateCircleDialog({ open, onOpenChange, onCreate, saving }) {
  const [form, setForm] = useState({ name: "", icon: "🤝", privacy: "private", purpose: "" });
  const update = (key, value) => setForm(prev => ({ ...prev, [key]: value }));
  const submit = () => onCreate(form).then(() => setForm({ name: "", icon: "🤝", privacy: "private", purpose: "" }));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm rounded-3xl">
        <DialogHeader><DialogTitle>Create Circle</DialogTitle></DialogHeader>
        <div className="space-y-4 pt-2">
          <Input placeholder="Circle name" value={form.name} onChange={e => update("name", e.target.value)} className="rounded-2xl h-12" />
          <Input placeholder="Icon, optional" value={form.icon} onChange={e => update("icon", e.target.value)} className="rounded-2xl h-12" />
          <div className="grid grid-cols-2 gap-2">
            {["private", "public"].map(option => (
              <button key={option} onClick={() => update("privacy", option)} className={`rounded-2xl border p-3 text-sm font-semibold capitalize ${form.privacy === option ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border text-foreground"}`}>
                {option}
              </button>
            ))}
          </div>
          <Input placeholder="Purpose, optional" value={form.purpose} onChange={e => update("purpose", e.target.value)} className="rounded-2xl h-12" />
          <Button onClick={submit} disabled={saving || !form.name.trim()} className="w-full rounded-2xl h-12 font-semibold">
            {saving ? "Creating..." : "Create Circle"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}