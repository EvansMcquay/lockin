import React from "react";
import { Button } from "@/components/ui/button";

const STATUS = {
  invited: { label: "Invited", icon: "⚪" },
  joined: { label: "Joined", icon: "⚪" },
  ready: { label: "Ready", icon: "🟢" },
  locked_in: { label: "Locked In", icon: "🟢" },
  completed: { label: "Completed", icon: "✅" },
  declined: { label: "Invited", icon: "⚪" },
};
const REACTIONS = ["🔥", "💪", "👏", "🙌"];
const MESSAGES = ["Keep going", "Finish strong", "You got this", "We’re locked in", "Almost there"];

export default function SilentGroupSessionPanel({ item, active, pulses = [], onStatus, onPulse }) {
  const participants = item.participants || [];
  const joined = participants.filter(p => ["joined", "ready", "locked_in", "completed"].includes(p.status));
  const allDone = joined.length > 0 && joined.every(p => p.status === "completed");
  const counts = pulses.filter(p => p.type === "reaction").reduce((acc, pulse) => ({ ...acc, [pulse.emoji]: (acc[pulse.emoji] || 0) + 1 }), {});
  const encouragements = pulses.filter(p => p.type === "encouragement").slice(0, 2);

  return <section className="rounded-3xl border border-border bg-card p-4 space-y-4">
    <div>
      <p className="text-xs font-semibold uppercase tracking-widest text-primary">Silent Group Lockin</p>
      <h2 className="font-heading font-bold text-lg text-foreground">{active ? "Locked In Together" : "Waiting Room"}</h2>
      <p className="text-sm text-muted-foreground">Quiet accountability. No chat, no distractions.</p>
    </div>
    <div className="space-y-2">
      {participants.map(participant => {
        const status = STATUS[participant.status] || STATUS.invited;
        return <div key={participant.id} className="flex items-center justify-between rounded-2xl bg-muted/50 px-3 py-2.5">
          <span className="text-sm font-semibold text-foreground">{status.icon} {participant.display_name}</span>
          <span className="text-xs font-semibold text-muted-foreground">{status.label}</span>
        </div>;
      })}
    </div>
    {!active && <div className="grid grid-cols-2 gap-2">
      <Button variant="outline" onClick={() => onStatus("joined")} className="rounded-2xl">Joined</Button>
      <Button onClick={() => onStatus("ready")} className="rounded-2xl">Ready</Button>
    </div>}
    {active && <div className="space-y-3">
      <div className="flex flex-wrap gap-2">{REACTIONS.map(emoji => <button key={emoji} type="button" onClick={() => onPulse({ type: "reaction", emoji })} className="rounded-full bg-muted px-3 py-2 text-sm font-semibold">{emoji} {counts[emoji] || ""}</button>)}</div>
      <div className="flex gap-2 overflow-x-auto pb-1">{MESSAGES.map(message => <button key={message} type="button" onClick={() => onPulse({ type: "encouragement", message })} className="flex-shrink-0 rounded-full bg-primary/10 px-3 py-2 text-xs font-semibold text-primary">{message}</button>)}</div>
      {encouragements.length > 0 && <div className="space-y-1">{encouragements.map(pulse => <p key={pulse.id} className="rounded-2xl bg-muted/40 px-3 py-2 text-xs text-muted-foreground"><span className="font-semibold text-foreground">@{pulse.username}</span> {pulse.message}</p>)}</div>}
    </div>}
    {allDone && <div className="rounded-2xl bg-primary/10 p-4 text-center space-y-2"><div className="text-3xl">✨</div><p className="font-heading font-bold text-lg text-foreground">Everyone Followed Through</p><p className="text-sm text-muted-foreground">{joined.map(p => `${p.display_name} ✅`).join(" · ")}</p></div>}
  </section>;
}