import React from "react";
import { Link } from "react-router-dom";
import { Clock, Users } from "lucide-react";
import { Button } from "@/components/ui/button";

const statusStyle = {
  invited: "text-warning",
  joined: "text-primary",
  ready: "text-primary",
  locked_in: "text-success",
  completed: "text-success",
  declined: "text-muted-foreground",
};
const statusLabel = { invited: "Invited", joined: "Joined", ready: "Ready", locked_in: "Locked In", completed: "Completed", declined: "Invited" };

function formatTime(iso) {
  return new Date(iso).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
}

export default function SharedLockinCard({ item }) {
  const participants = item.participants || [];
  return (
    <div className="rounded-3xl border border-border bg-card p-4 space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-semibold text-primary uppercase tracking-[0.16em]">Shared Lockin</p>
          <h3 className="font-heading font-bold text-base text-foreground truncate">{item.title}</h3>
          {item.focus && <p className="text-sm text-muted-foreground truncate">{item.focus}</p>}
        </div>
        <span className="rounded-full bg-primary/10 px-2.5 py-1 text-xs font-semibold text-primary">{item.category}</span>
      </div>
      <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
        <div className="rounded-2xl bg-muted/50 p-3"><Clock className="w-4 h-4 mb-1" />{formatTime(item.start_at)} – {formatTime(item.end_at)}</div>
        <div className="rounded-2xl bg-muted/50 p-3"><Users className="w-4 h-4 mb-1" />{participants.length} participant{participants.length === 1 ? "" : "s"}</div>
      </div>
      <div className="flex flex-wrap gap-2">
        {participants.map(p => <span key={p.id} className={`text-xs font-semibold ${statusStyle[p.status] || "text-muted-foreground"}`}>@{p.username}: {statusLabel[p.status] || "Joined"}</span>) }
      </div>
      <Button asChild variant="outline" className="w-full rounded-2xl"><Link to={`/shared-lockin/${item.id}`}>View Details</Link></Button>
    </div>
  );
}