import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

function formatTime(iso) { return new Date(iso).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }); }

export default function UpcomingSharedLockinCard({ item }) {
  if (!item) return null;
  const locked = (item.participants || []).filter(p => p.status === "locked_in").length;
  return <section className="rounded-3xl border border-primary/20 bg-primary/10 p-4 space-y-3">
    <div>
      <p className="text-xs font-semibold uppercase tracking-widest text-primary">Active or Upcoming</p>
      <h2 className="font-heading font-bold text-lg text-foreground">{item.title}</h2>
      {item.focus && <p className="text-sm text-muted-foreground">{item.focus}</p>}
      <p className="text-sm font-semibold text-foreground mt-1">{formatTime(item.start_at)} – {formatTime(item.end_at)}</p>
    </div>
    <p className="text-xs text-muted-foreground">{locked > 0 ? `${locked} member${locked === 1 ? "" : "s"} locked in now` : `${(item.participants || []).length} invited or joined`}</p>
    <Button asChild className="w-full rounded-2xl"><Link to={`/shared-lockin/${item.id}`}>Start Together</Link></Button>
  </section>;
}