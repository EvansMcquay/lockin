import React from "react";
import { Clock, Flame, ShieldCheck, Shield } from "lucide-react";

export default function StatsOverview({ locks, unlockEvents }) {
  const completedLocks = locks.filter(l => l.status === "completed");
  const activeLocks = locks.filter(l => l.status === "active" && new Date(l.unlocks_at) > new Date());

  const totalMinutesSaved = completedLocks.reduce((sum, l) => sum + (l.duration_minutes || 0), 0);
  const hoursSaved = (totalMinutesSaved / 60).toFixed(1);

  // Hours saved this week
  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);
  const weekMinutes = completedLocks
    .filter(l => new Date(l.locked_at) >= weekAgo)
    .reduce((sum, l) => sum + (l.duration_minutes || 0), 0);
  const weekHours = (weekMinutes / 60).toFixed(1);

  // Calculate streak
  const lockDates = new Set(
    locks
      .filter(l => l.status !== "emergency_unlocked")
      .map(l => new Date(l.locked_at).toDateString())
  );
  let streak = 0;
  const d = new Date();
  while (lockDates.has(d.toDateString())) {
    streak++;
    d.setDate(d.getDate() - 1);
  }

  const stats = [
    { icon: Clock, label: "Hours Saved", value: `${hoursSaved}h`, color: "text-primary" },
    { icon: Flame, label: "Day Streak", value: streak, color: "text-orange-500" },
    { icon: ShieldCheck, label: "Locks Done", value: completedLocks.length, color: "text-accent" },
    { icon: Shield, label: "This Week", value: `${weekHours}h`, color: "text-violet-500" },
  ];

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
        {stats.map((stat) => (
          <div key={stat.label} className="rounded-2xl bg-card border border-border p-4">
            <div className="flex items-center gap-2 mb-1">
              <stat.icon className={`w-4 h-4 ${stat.color}`} />
              <span className="text-xs text-muted-foreground">{stat.label}</span>
            </div>
            <p className="text-2xl font-heading font-bold text-foreground">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Encouraging message */}
      {(completedLocks.length > 0 || activeLocks.length > 0) && (
        <div className="rounded-2xl bg-primary/5 border border-primary/10 px-4 py-3">
          <p className="text-sm text-primary font-medium text-center">
            {activeLocks.length > 0
              ? `${activeLocks.length} app${activeLocks.length > 1 ? "s" : ""} currently protected. Stay focused. 🛡️`
              : weekHours > 0
              ? `You've reclaimed ${weekHours} hours this week. Keep going. 🔥`
              : `${hoursSaved} hours reclaimed total. You're doing great. 💪`}
          </p>
        </div>
      )}
    </div>
  );
}