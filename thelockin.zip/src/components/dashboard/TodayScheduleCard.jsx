import React from "react";
import { Link } from "react-router-dom";
import { ChevronDown, Check, Play, Clock, Pencil, CalendarX, Trash2, UserPlus } from "lucide-react";
import { sharedLockinSetupUrl } from "@/lib/sharedLockinLinks";
import { motion, AnimatePresence } from "framer-motion";
import ScheduleIcon from "@/components/schedules/ScheduleIcon";

function formatTime(timeStr) {
  const [h, m] = timeStr.split(":").map(Number);
  const date = new Date();
  date.setHours(h, m, 0, 0);
  return date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
}

function StatusPill({ status, minsUntil }) {
  if (status === "completed") return <span className="text-[11px] font-semibold text-success">Complete</span>;
  if (status === "active") return <span className="text-[11px] font-semibold text-primary">Active</span>;
  if (status === "not_started") return <span className="text-[11px] font-semibold text-primary">Ready</span>;
  if (minsUntil > 0 && minsUntil <= 60) return <span className="text-[11px] font-semibold text-warning">In {minsUntil}m</span>;
  if (minsUntil <= 0) return <span className="text-[11px] font-medium text-muted-foreground">Ended</span>;
  return <span className="text-[11px] font-medium text-muted-foreground">Later</span>;
}

export default function TodayScheduleCard({ item, expanded, onToggle, onStart, onSkipToday, onDelete, isStarting }) {
  const { sched, status, minsUntil, sessions = [] } = item;
  const isActive = status === "active";
  const isCompleted = status === "completed";
  const canStart = !isCompleted && !isActive && (status === "not_started" || (minsUntil > 0 && minsUntil <= 60));
  const timeStr = `${formatTime(sched.start_time)} – ${formatTime(sched.end_time)}`;
  const today = new Date().toISOString().slice(0, 10);
  const inviteUrl = sharedLockinSetupUrl({ category: sched.label, focus: sched.goal_name || sched.label, start: `${today}T${sched.start_time}`, end: `${today}T${sched.end_time}` });

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -6 }}
      transition={{ duration: 0.18 }}
      className={`rounded-[20px] border overflow-hidden shadow-sm ${isActive ? "bg-primary/10 border-primary/25" : "bg-card/90 border-border"}`}
    >
      <button onClick={onToggle} className="w-full text-left p-4 active:scale-[0.99] transition-transform">
        <div className="flex items-center gap-3">
          <ScheduleIcon icon={sched.goal_emoji} styleName={sched.icon_style} active={isActive} />
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h3 className="font-heading font-semibold text-base text-foreground truncate">{sched.label}</h3>
                <p className="text-xs mt-0.5 text-muted-foreground">{timeStr}</p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <StatusPill status={status} minsUntil={minsUntil} />
                <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${expanded ? "rotate-180" : ""}`} />
              </div>
            </div>
            <p className="text-xs mt-2 truncate text-muted-foreground">{sched.goal_name || "Today's goal"}</p>
          </div>
        </div>
      </button>

      <AnimatePresence initial={false}>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className={`mx-4 mb-4 rounded-2xl p-3 space-y-3 ${isActive ? "bg-primary/10 border border-primary/15" : "bg-muted/60"}`}>
              <div className="space-y-2">
                {sessions.length > 0 ? sessions.map(session => (
                  <div key={session.id} className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className={`w-7 h-7 rounded-xl flex items-center justify-center flex-shrink-0 ${session.status === "completed" ? "bg-primary/15 text-primary" : "bg-background/70 text-muted-foreground"}`}>
                        {session.status === "completed" ? <Check className="w-3.5 h-3.5" /> : <Clock className="w-3.5 h-3.5" />}
                      </span>
                      <span className="text-xs font-medium truncate text-foreground">{session.app_name}</span>
                    </div>
                    <span className="text-[11px] capitalize flex-shrink-0 text-muted-foreground">{session.status?.replace("_", " ")}</span>
                  </div>
                )) : (
                  <p className="text-xs text-muted-foreground">No session started yet.</p>
                )}
              </div>

              {canStart && (
                <motion.button
                  whileTap={{ scale: 0.97 }}
                  onClick={onStart}
                  disabled={isStarting}
                  className="w-full rounded-2xl bg-primary text-primary-foreground font-semibold py-3 text-sm disabled:opacity-60 flex items-center justify-center gap-2"
                >
                  <Play className="w-4 h-4" fill="currentColor" />
                  {isStarting ? "Locking in..." : "Lockin"}
                </motion.button>
              )}

              <div className="grid grid-cols-4 gap-2 pt-1 text-muted-foreground">
                <Link to={`/schedule-builder?edit=${sched.id}`} className="rounded-xl bg-background/70 px-2 py-2 text-xs font-semibold flex items-center justify-center gap-1">
                  <Pencil className="w-3.5 h-3.5" /> Edit
                </Link>
                <Link to={inviteUrl} className="rounded-xl bg-background/70 px-2 py-2 text-xs font-semibold flex items-center justify-center gap-1">
                  <UserPlus className="w-3.5 h-3.5" /> Invite
                </Link>
                <button onClick={onSkipToday} className="rounded-xl bg-background/70 px-2 py-2 text-xs font-semibold flex items-center justify-center gap-1">
                  <CalendarX className="w-3.5 h-3.5" /> Skip
                </button>
                <button onClick={onDelete} className="rounded-xl bg-background/70 px-2 py-2 text-xs font-semibold text-destructive flex items-center justify-center gap-1">
                  <Trash2 className="w-3.5 h-3.5" /> Delete
                </button>
              </div>
              <p className="text-[11px] text-muted-foreground">
                Skipping only affects today. Deleting hides future occurrences without removing past sessions.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}