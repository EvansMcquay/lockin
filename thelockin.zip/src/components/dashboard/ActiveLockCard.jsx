import React, { useState, useEffect } from "react";
import { getTimeRemaining, SEVERITY_LEVELS } from "@/lib/freedomLockData";
import { Progress } from "@/components/ui/progress";
import { Lock, Unlock } from "lucide-react";

export default function ActiveLockCard({ lock, onEmergencyUnlock }) {
  const [remaining, setRemaining] = useState(getTimeRemaining(lock.unlocks_at));
  const severity = SEVERITY_LEVELS[lock.severity_level];

  useEffect(() => {
    const interval = setInterval(() => {
      setRemaining(getTimeRemaining(lock.unlocks_at));
    }, 1000);
    return () => clearInterval(interval);
  }, [lock.unlocks_at]);

  const totalDuration = lock.duration_minutes * 60 * 1000;
  const elapsed = totalDuration - remaining.total;
  const percent = totalDuration > 0 ? Math.min(100, (elapsed / totalDuration) * 100) : 100;
  const isComplete = remaining.total <= 0;

  return (
    <div className={`rounded-2xl border p-4 transition-all duration-300 ${
      isComplete ? "bg-secondary/50 border-accent/30" : "bg-card border-border"
    }`}>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <span className="text-2xl">{lock.app_icon || "📱"}</span>
          <div>
            <h3 className="font-heading font-semibold text-foreground">{lock.app_name}</h3>
            <span className={`text-xs px-2 py-0.5 rounded-full border ${severity?.color || ""}`}>
              {severity?.emoji} {severity?.label}
            </span>
          </div>
        </div>
        {isComplete ? (
          <div className="w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center">
            <Unlock className="w-4 h-4 text-accent" />
          </div>
        ) : (
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
            <Lock className="w-4 h-4 text-primary" />
          </div>
        )}
      </div>

      {isComplete ? (
        <p className="text-sm text-accent font-medium">✓ Lock completed! You did it!</p>
      ) : (
        <>
          <div className="mb-2">
            <div className="flex items-baseline gap-1 font-mono">
              <span className="text-2xl font-bold text-foreground">
                {String(remaining.hours).padStart(2, "0")}
              </span>
              <span className="text-muted-foreground text-sm">h</span>
              <span className="text-2xl font-bold text-foreground">
                {String(remaining.minutes).padStart(2, "0")}
              </span>
              <span className="text-muted-foreground text-sm">m</span>
              <span className="text-2xl font-bold text-foreground">
                {String(remaining.seconds).padStart(2, "0")}
              </span>
              <span className="text-muted-foreground text-sm">s</span>
            </div>
          </div>
          <Progress value={percent} className="h-2 mb-3" />
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground italic">"{severity?.message}"</p>
            {!lock.hardcore_mode && (
              <button
                onClick={() => onEmergencyUnlock(lock)}
                className="text-xs text-destructive/70 hover:text-destructive font-medium transition-colors"
              >
                Emergency
              </button>
            )}
            {lock.hardcore_mode && (
              <span className="text-xs text-red-600 font-semibold">☠️ Hardcore</span>
            )}
          </div>
        </>
      )}
    </div>
  );
}