import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { getTimeRemaining } from "@/lib/freedomLockData";

function isSameSessionLock(candidate, anchor) {
  if (candidate.id === anchor.id) return true;
  if (candidate.goal_name !== anchor.goal_name) return false;
  const lockedDiff = Math.abs(new Date(candidate.locked_at).getTime() - new Date(anchor.locked_at).getTime());
  const unlockDiff = Math.abs(new Date(candidate.unlocks_at).getTime() - new Date(anchor.unlocks_at).getTime());
  return lockedDiff < 60000 && unlockDiff < 60000;
}

export default function HomeActiveLockinCard({ lock, allActiveLocks = [] }) {
  const [remaining, setRemaining] = useState(getTimeRemaining(lock.unlocks_at));
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => setRemaining(getTimeRemaining(lock.unlocks_at)), 1000);
    return () => clearInterval(interval);
  }, [lock.unlocks_at]);

  const sessionLocks = useMemo(() => {
    const locks = allActiveLocks.filter(item => !item.archived_at && item.status === "active" && new Date(item.unlocks_at) > new Date() && isSameSessionLock(item, lock));
    return locks.length > 0 ? locks : [lock];
  }, [allActiveLocks, lock]);

  const blockedApps = useMemo(() => [...new Set(sessionLocks.map(item => item.app_name).filter(Boolean))], [sessionLocks]);
  const visibleApps = expanded ? blockedApps : blockedApps.slice(0, 4);
  const sessionName = lock.lockin_category || lock.goal_name || "Current Lockin";
  const focus = lock.goal_name || sessionName;
  const timeStr = `${String(remaining.hours).padStart(2, "0")}:${String(remaining.minutes).padStart(2, "0")}:${String(remaining.seconds).padStart(2, "0")}`;
  const progress = Math.max(0, Math.min(100, 100 - (remaining.total / Math.max(1, (lock.duration_minutes || 1) * 60000)) * 100));

  return (
    <motion.section
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.22 }}
      className="rounded-[24px] border border-primary/25 bg-card/95 p-4 shadow-xl shadow-primary/10"
    >
      <div className="space-y-3">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-primary">Active Lockin</p>
          <h2 className="mt-1 font-heading text-xl font-semibold leading-tight text-foreground">{sessionName}</h2>
          <p className="mt-1 text-sm text-muted-foreground">{focus}</p>
        </div>

        <div>
          <p className="timer-tabular text-[34px] font-semibold leading-none text-foreground">{timeStr}</p>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
            <motion.div className="h-full rounded-full bg-primary" initial={{ width: 0 }} animate={{ width: `${progress}%` }} transition={{ duration: 0.25 }} />
          </div>
        </div>

        {blockedApps.length > 0 && (
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">Locked apps</p>
            <p className="mt-1 text-sm font-medium leading-relaxed text-foreground">{visibleApps.join(" · ")}</p>
          </div>
        )}

        <button
          onClick={() => setExpanded(prev => !prev)}
          className="inline-flex items-center gap-1.5 rounded-2xl bg-secondary px-3 py-1.5 text-sm font-semibold text-foreground"
        >
          {expanded ? "Collapse" : "Expand"}
          <ChevronDown className={`h-4 w-4 transition-transform ${expanded ? "rotate-180" : ""}`} />
        </button>
      </div>
    </motion.section>
  );
}