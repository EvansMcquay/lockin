import React, { useState, useEffect } from "react";
import { Flame, X, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

const STREAK_MESSAGES = {
  1: "Day 1 done. The hardest day is behind you. 💪",
  2: "Two days in. You're already ahead of yesterday's you.",
  3: "3-day streak! Your brain is already rewiring. Keep it up.",
  5: "5 days strong. Half a week of real discipline.",
  7: "One full week! 🎉 You're building something real.",
  10: "10 days! Double digits. You're not stopping now.",
  14: "Two weeks strong! Habits take 21 days — you're close.",
  21: "21 days! Science says this is where habits form. You did it.",
  30: "30-day streak! 🏆 You're a completely different person.",
};

const GENERIC_STREAK_MESSAGES = [
  "Your streak is building momentum — don't break the chain.",
  "Every locked day is a vote for who you want to become.",
  "You're training discipline like a muscle. It's getting stronger.",
  "Small wins compound. Keep stacking them.",
  "Today's discipline is tomorrow's freedom.",
  "TikTok still exists. You still don't need it.",
  "Instagram isn't taking attendance. Your streak is.",
  "Your dopamine dealer is successfully blocked. Again. 🔒",
];

function getStreakMessage(streak) {
  const milestone = Object.keys(STREAK_MESSAGES)
    .map(Number)
    .sort((a, b) => b - a)
    .find((m) => streak >= m);

  if (milestone && streak === milestone) {
    return { text: STREAK_MESSAGES[milestone], isMilestone: true };
  }
  const msgs = GENERIC_STREAK_MESSAGES;
  // Use streak as seed for consistent daily message
  const idx = streak % msgs.length;
  return { text: msgs[idx], isMilestone: false };
}

export default function StreakReminder({ streak, dismissed, onDismiss }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (streak > 0 && !dismissed) {
      const timer = setTimeout(() => setVisible(true), 600);
      return () => clearTimeout(timer);
    }
  }, [streak, dismissed]);

  const handleDismiss = () => {
    setVisible(false);
    setTimeout(onDismiss, 300);
  };

  const { text, isMilestone } = getStreakMessage(streak);

  if (!visible) return null;

  return (
    <div
      className={`rounded-2xl border p-4 transition-all duration-300 ${
        isMilestone
          ? "bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200"
          : "bg-gradient-to-r from-primary/5 to-accent/5 border-primary/15"
      }`}
    >
      <div className="flex items-start gap-3">
        <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${
          isMilestone ? "bg-amber-100" : "bg-primary/10"
        }`}>
          <Flame className={`w-5 h-5 ${isMilestone ? "text-amber-600" : "text-primary"}`} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span className={`text-sm font-heading font-semibold ${
              isMilestone ? "text-amber-800" : "text-foreground"
            }`}>
              🔥 {streak}-day streak{isMilestone ? " milestone!" : ""}
            </span>
          </div>
          <p className={`text-xs leading-relaxed ${
            isMilestone ? "text-amber-700" : "text-muted-foreground"
          }`}>
            {text}
          </p>
          <Link
            to="/stats"
            className={`inline-flex items-center gap-1 text-xs font-medium mt-1.5 ${
              isMilestone ? "text-amber-700 hover:text-amber-900" : "text-primary hover:text-primary/80"
            }`}
          >
            View full stats <ChevronRight className="w-3 h-3" />
          </Link>
        </div>
        <button
          onClick={handleDismiss}
          className="text-muted-foreground hover:text-foreground transition-colors flex-shrink-0 p-0.5"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}