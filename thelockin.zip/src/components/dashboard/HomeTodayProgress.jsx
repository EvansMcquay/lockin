import React from "react";

function formatFocusMinutes(minutes) {
  if (!minutes) return "Let's Get Started";
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return mins ? `${hours}h ${mins}m` : `${hours}h`;
}

function displayValue(type, value) {
  if (type === "completed") return value > 0 ? String(value) : "First Lockin";
  if (type === "streak") return value > 0 ? `${value} day${value === 1 ? "" : "s"}` : "Build Your Streak";
  return formatFocusMinutes(value);
}

export default function HomeTodayProgress({ stats }) {
  const metrics = [
    { key: "completed", label: "Completed Lockins", value: stats.completedLockins },
    { key: "streak", label: "Current Streak", value: stats.currentStreak },
    { key: "focus", label: "Total Focus Time", value: stats.focusMinutes },
  ];

  return (
    <section className="rounded-[20px] border border-border/70 bg-card/55 p-2.5 shadow-sm shadow-black/5">
      <p className="mb-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Today's Progress</p>
      <div className="grid grid-cols-3 gap-1.5">
        {metrics.map(metric => (
          <div key={metric.key} className="rounded-2xl bg-secondary/70 px-2 py-1.5 text-center">
            <p className="truncate text-[10px] font-semibold leading-tight text-muted-foreground">{metric.label}</p>
            <p className="mt-1 truncate text-[11px] font-bold leading-tight text-foreground">{displayValue(metric.key, metric.value)}</p>
          </div>
        ))}
      </div>
    </section>
  );
}