import React, { useEffect, useState } from "react";
import { circleAction } from "@/lib/circlesApi";

const STATUS = { joined: "⚪", ready: "⚪", locked_in: "🟢", completed: "✅", invited: "⚪" };

export default function SharedSessionMiniPanel({ sharedLockinId }) {
  const [item, setItem] = useState(null);
  useEffect(() => {
    let alive = true;
    const load = () => circleAction("getSharedLockin", { sharedLockinId }).then(res => { if (alive) setItem(res.sharedLockin); }).catch(() => null);
    load();
    const timer = setInterval(load, 15000);
    return () => { alive = false; clearInterval(timer); };
  }, [sharedLockinId]);
  if (!item) return null;
  return <div className="rounded-2xl border border-border bg-background/50 p-3 space-y-2">
    <p className="text-xs font-semibold uppercase tracking-widest text-primary">Locked In Together</p>
    <div className="grid grid-cols-2 gap-2">{(item.participants || []).map(participant => <div key={participant.id} className="truncate text-xs font-semibold text-muted-foreground">{STATUS[participant.status] || "⚪"} {participant.display_name}</div>)}</div>
  </div>;
}