import React, { useState, useEffect } from "react";
import { getRandomMessage } from "@/lib/freedomLockData";
import { Sparkles, RefreshCw } from "lucide-react";

export default function QuoteCard() {
  const [message, setMessage] = useState(getRandomMessage());
  const [fading, setFading] = useState(false);

  const refresh = () => {
    setFading(true);
    setTimeout(() => {
      setMessage(getRandomMessage());
      setFading(false);
    }, 200);
  };

  useEffect(() => {
    const interval = setInterval(refresh, 15000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="rounded-2xl bg-gradient-to-br from-primary/10 via-accent/5 to-secondary/30 border border-primary/10 p-5">
      <div className="flex items-start justify-between mb-2">
        <Sparkles className="w-5 h-5 text-primary" />
        <button onClick={refresh} className="text-muted-foreground hover:text-foreground transition-colors">
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>
      <p className={`text-sm font-medium text-foreground leading-relaxed transition-opacity duration-200 ${
        fading ? "opacity-0" : "opacity-100"
      }`}>
        "{message}"
      </p>
    </div>
  );
}