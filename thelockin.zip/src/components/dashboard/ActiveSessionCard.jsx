import React, { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import { getTimeRemaining } from "@/lib/freedomLockData";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, Clock3, ShieldCheck, UserPlus } from "lucide-react";
import { sharedLockinSetupUrl } from "@/lib/sharedLockinLinks";
import ScheduleIcon from "@/components/schedules/ScheduleIcon";
import SharedSessionMiniPanel from "@/components/dashboard/SharedSessionMiniPanel";

const END_REASONS = [
  { value: "need_app", label: "Need an app" },
  { value: "schedule_changed", label: "Plans changed" },
  { value: "emergency", label: "Emergency" },
  { value: "other", label: "Other" },
];

function formatDateTime(isoStr) {
  return new Date(isoStr).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
}

function isSameSessionLock(candidate, anchor) {
  if (candidate.id === anchor.id) return true;
  if (candidate.goal_name !== anchor.goal_name) return false;
  const lockedDiff = Math.abs(new Date(candidate.locked_at).getTime() - new Date(anchor.locked_at).getTime());
  const unlockDiff = Math.abs(new Date(candidate.unlocks_at).getTime() - new Date(anchor.unlocks_at).getTime());
  return lockedDiff < 60000 && unlockDiff < 60000;
}

export default function ActiveSessionCard({ lock, allActiveLocks = [], onEndEarly }) {
  const [remaining, setRemaining] = useState(getTimeRemaining(lock.unlocks_at));
  const [confirmingEnd, setConfirmingEnd] = useState(false);
  const [selectedReason, setSelectedReason] = useState("");

  useEffect(() => {
    const interval = setInterval(() => setRemaining(getTimeRemaining(lock.unlocks_at)), 1000);
    return () => clearInterval(interval);
  }, [lock.unlocks_at]);

  const isComplete = remaining.total <= 0;
  const sessionLocks = allActiveLocks.filter(l => !l.archived_at && l.status === "active" && new Date(l.unlocks_at) > new Date() && isSameSessionLock(l, lock));
  const locksInSession = sessionLocks.length > 0 ? sessionLocks : [lock];
  const blockedApps = [...new Set(locksInSession.map(l => l.app_name).filter(Boolean))];
  const hasEmergencyUnlock = locksInSession.some(l => !l.hardcore_mode && Number(l.emergency_unlock_cost || 0) > 0);
  const endReasons = useMemo(() => hasEmergencyUnlock ? END_REASONS : END_REASONS.filter(reason => reason.value !== "emergency"), [hasEmergencyUnlock]);

  const sessionName = lock.goal_name || "Current Lockin";
  const startTime = formatDateTime(lock.locked_at);
  const endTime = formatDateTime(lock.unlocks_at);
  const timeStr = `${String(remaining.hours).padStart(2, "0")}:${String(remaining.minutes).padStart(2, "0")}:${String(remaining.seconds).padStart(2, "0")}`;
  const progress = Math.max(0, Math.min(100, 100 - (remaining.total / Math.max(1, (lock.duration_minutes || 1) * 60000)) * 100));
  const inviteUrl = sharedLockinSetupUrl({ focus: sessionName, start: lock.locked_at?.slice(0, 16), end: lock.unlocks_at?.slice(0, 16), duration: lock.duration_minutes, late: true });

  if (isComplete) {
    return (
      <Link to={`/session-complete?session=${lock.id}`} className="block">
        <motion.div whileTap={{ scale: 0.98 }} className="premium-card px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <ScheduleIcon icon={lock.goal_emoji || "✓"} styleName={lock.icon_style} size="sm" />
            <div className="min-w-0">
              <p className="font-semibold text-sm text-foreground truncate">{sessionName}</p>
              <p className="text-xs text-primary font-medium">Complete — review session</p>
            </div>
          </div>
          <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
        </motion.div>
      </Link>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.28, ease: "easeOut" }}
      className="relative overflow-hidden rounded-[28px] border border-primary/25 bg-gradient-to-br from-primary/25 via-card to-secondary p-5 shadow-2xl shadow-primary/10"
    >
      <motion.div animate={{ opacity: [0.35, 0.65, 0.35] }} transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }} className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-primary/20 blur-3xl" />

      <div className="relative space-y-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <ScheduleIcon icon={lock.goal_emoji || "•"} styleName={lock.icon_style} size="md" active />
            <div className="min-w-0">
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-primary">Current Lockin</p>
              <h2 className="font-heading font-semibold text-[22px] leading-tight text-foreground truncate">{sessionName}</h2>
            </div>
          </div>
          <div className="flex items-center gap-1.5 rounded-full border border-primary/25 bg-primary/10 px-2.5 py-1 text-primary">
            <span className="h-1.5 w-1.5 rounded-full bg-success" />
            <span className="text-xs font-medium">Active</span>
          </div>
        </div>

        <div>
          <p className="timer-tabular text-[42px] font-semibold leading-none text-foreground">{timeStr}</p>
          <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/10 dark:bg-white/10">
            <motion.div className="h-full rounded-full bg-primary" initial={{ width: 0 }} animate={{ width: `${progress}%` }} transition={{ duration: 0.3 }} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="premium-surface p-3">
            <Clock3 className="w-4 h-4 text-muted-foreground mb-1.5" />
            <p className="text-xs text-muted-foreground">Time</p>
            <p className="text-sm font-medium text-foreground">{startTime} – {endTime}</p>
          </div>
          <div className="premium-surface p-3">
            <ShieldCheck className="w-4 h-4 text-muted-foreground mb-1.5" />
            <p className="text-xs text-muted-foreground">Locked</p>
            <p className="text-sm font-medium text-foreground truncate">{blockedApps.length || 0} app{blockedApps.length === 1 ? "" : "s"}</p>
          </div>
        </div>

        {blockedApps.length > 0 && <p className="text-sm text-muted-foreground leading-relaxed">{blockedApps.join(" · ")}</p>}

        {lock.shared_lockin_id && <SharedSessionMiniPanel sharedLockinId={lock.shared_lockin_id} />}

        <Link to={inviteUrl} className="inline-flex items-center gap-2 rounded-2xl border border-border bg-background/60 px-3 py-2 text-sm font-semibold text-foreground">
          <UserPlus className="w-4 h-4" /> Invite to Lockin
        </Link>

        {onEndEarly && (
          <button onClick={() => setConfirmingEnd(true)} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
            End early
          </button>
        )}
      </div>

      <AnimatePresence>
        {confirmingEnd && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.2 }} className="relative overflow-hidden">
            <div className="mt-5 rounded-[20px] border border-border bg-background/70 p-4 space-y-4">
              <div>
                <p className="text-base font-semibold text-foreground">End this session?</p>
                <p className="text-sm text-muted-foreground mt-1">This will be saved as ended early.</p>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {endReasons.map(reason => (
                  <button key={reason.value} onClick={() => setSelectedReason(reason.value)} className={`rounded-2xl px-3 py-2.5 text-xs font-medium transition-colors ${selectedReason === reason.value ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}>
                    {reason.label}
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => { setConfirmingEnd(false); setSelectedReason(""); }} className="rounded-2xl bg-secondary px-3 py-3 text-sm font-medium text-foreground">Keep going</button>
                <button onClick={() => onEndEarly(lock, selectedReason)} disabled={!selectedReason} className="rounded-2xl bg-destructive px-3 py-3 text-sm font-medium text-destructive-foreground disabled:opacity-40">End session</button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}