import React from "react";
import { motion } from "framer-motion";
import ScheduleIcon from "@/components/schedules/ScheduleIcon";

function formatTime(timeStr) {
  const [h, m] = timeStr.split(":").map(Number);
  const date = new Date();
  date.setHours(h, m, 0, 0);
  return date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
}

function startsInLabel(minutes) {
  if (minutes <= 0) return "Ready now";
  if (minutes === 1) return "Starts in 1 minute";
  if (minutes < 60) return `Starts in ${minutes} minutes`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return mins === 0 ? `Starts in ${hours}h` : `Starts in ${hours}h ${mins}m`;
}

export default function HomeNextLockinCard({ item, onStart, isStarting }) {
  const { sched, minsUntil } = item;
  const sessionName = sched.label || sched.goal_name || "Lockin";
  const focus = sched.goal_name || sessionName;

  return (
    <motion.section
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.22 }}
      className="rounded-[24px] border border-border bg-card/95 p-4 shadow-lg shadow-black/5"
    >
      <div className="space-y-3">
        <div className="flex items-start gap-3">
          <ScheduleIcon icon={sched.goal_emoji} styleName={sched.icon_style} size="md" />
          <div className="min-w-0 flex-1">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-primary">Next Up</p>
            <h2 className="mt-1 truncate font-heading text-xl font-semibold leading-tight text-foreground">{sessionName}</h2>
            <p className="mt-1 truncate text-sm text-muted-foreground">{focus}</p>
          </div>
        </div>

        <div className="space-y-1">
          <p className="text-sm font-semibold text-foreground">Today • {formatTime(sched.start_time)}</p>
          <p className="text-sm text-muted-foreground">{startsInLabel(minsUntil)}</p>
        </div>

        <button
          onClick={onStart}
          disabled={isStarting}
          className="w-full rounded-2xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground shadow-lg shadow-primary/20 disabled:opacity-60"
        >
          {isStarting ? "Starting..." : "Start Early"}
        </button>
      </div>
    </motion.section>
  );
}