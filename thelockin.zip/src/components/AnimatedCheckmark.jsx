import { motion } from "framer-motion";

/**
 * SVG checkmark that draws itself inside a subtle circle.
 * Premium, restrained — no bouncing.
 */
export default function AnimatedCheckmark({ size = 80, delay = 0.2 }) {
  return (
    <div className="relative" style={{ width: size, height: size }}>
      {/* Circle background fades in */}
      <motion.div
        initial={{ scale: 0.6, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3, ease: "easeOut" }}
        className="absolute inset-0 rounded-full bg-primary/10"
      />
      <svg
        viewBox="0 0 52 52"
        className="absolute inset-0 w-full h-full"
        fill="none"
      >
        {/* Circle border draws */}
        <motion.circle
          cx="26"
          cy="26"
          r="23"
          stroke="hsl(var(--primary))"
          strokeWidth="2"
          fill="none"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 0.3 }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
        />
        {/* Checkmark draws */}
        <motion.path
          d="M15 27 L23 35 L38 18"
          stroke="hsl(var(--primary))"
          strokeWidth="3.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.45, ease: "easeInOut", delay }}
        />
      </svg>
    </div>
  );
}