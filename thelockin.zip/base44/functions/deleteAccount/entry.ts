import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

const USER_OWNED_ENTITIES = [
  'AppLock',
  'RecurringSchedule',
  'JournalEntry',
  'KeyDistraction',
  'UnlockEvent',
];

async function activeMembers(base44, circleId) {
  return await base44.asServiceRole.entities.CircleMember.filter({ circle_id: circleId, status: 'active' }, '-created_date', 50);
}

async function cleanupCircleReferences(base44, circleId) {
  await base44.asServiceRole.entities.CircleMember.deleteMany({ circle_id: circleId });
  await base44.asServiceRole.entities.CircleInvite.deleteMany({ circle_id: circleId });
  await base44.asServiceRole.entities.CircleJoinRequest.deleteMany({ circle_id: circleId });
  await base44.asServiceRole.entities.CircleModerationAction.deleteMany({ circle_id: circleId });
}

async function removeUserFromCircles(base44, userId) {
  const ownedCircles = await base44.asServiceRole.entities.Circle.filter({ owner_id: userId }, '-created_date', 100);
  for (const circle of ownedCircles) {
    await cleanupCircleReferences(base44, circle.id);
    await base44.asServiceRole.entities.Circle.delete(circle.id);
  }

  const memberships = await base44.asServiceRole.entities.CircleMember.filter({ user_id: userId, status: 'active' }, '-created_date', 100);
  for (const membership of memberships) {
    const circle = await base44.asServiceRole.entities.Circle.get(membership.circle_id).catch(() => null);
    if (!circle) continue;
    const members = await activeMembers(base44, circle.id);
    if (membership.role === 'owner') {
      const nextOwner = members.filter(m => m.user_id !== userId).sort((a, b) => new Date(a.joined_at) - new Date(b.joined_at))[0];
      if (nextOwner) {
        await base44.asServiceRole.entities.CircleMember.update(nextOwner.id, { role: 'owner' });
        await base44.asServiceRole.entities.Circle.update(circle.id, { owner_id: nextOwner.user_id, owner_name: nextOwner.display_name });
      } else {
        await cleanupCircleReferences(base44, circle.id);
        await base44.asServiceRole.entities.Circle.delete(circle.id);
        continue;
      }
    }
    await base44.asServiceRole.entities.CircleMember.delete(membership.id);
    const remaining = Math.max(0, members.length - 1);
    await base44.asServiceRole.entities.Circle.update(circle.id, { member_count: remaining });
  }

  await base44.asServiceRole.entities.CircleInvite.deleteMany({ invited_by_id: userId });
  await base44.asServiceRole.entities.CircleInvite.deleteMany({ invited_user_id: userId });
  await base44.asServiceRole.entities.CircleInvite.deleteMany({ accepted_by_id: userId });
  await base44.asServiceRole.entities.CircleJoinRequest.deleteMany({ user_id: userId });
  await base44.asServiceRole.entities.CircleModerationAction.deleteMany({ actor_user_id: userId });
  await base44.asServiceRole.entities.CircleModerationAction.deleteMany({ target_user_id: userId });
}

async function deleteEntityRecordsForUser(base44, entityName, userId) {
  const entity = base44.asServiceRole.entities[entityName];
  for (let attempt = 0; attempt < 10; attempt += 1) {
    const remaining = await entity.filter({ created_by_id: userId }, '-created_date', 1);
    if (!remaining || remaining.length === 0) return;
    await entity.deleteMany({ created_by_id: userId });
  }
  throw new Error(`Could not fully delete ${entityName}`);
}

async function verifyNoUserRecordsRemain(base44, userId) {
  const remainingEntities = [];
  for (const entityName of USER_OWNED_ENTITIES) {
    const remaining = await base44.asServiceRole.entities[entityName].filter({ created_by_id: userId }, '-created_date', 1);
    if (remaining && remaining.length > 0) remainingEntities.push(entityName);
  }
  const ownedCircle = await base44.asServiceRole.entities.Circle.filter({ owner_id: userId }, '-created_date', 1);
  const membership = await base44.asServiceRole.entities.CircleMember.filter({ user_id: userId }, '-created_date', 1);
  const invitedBy = await base44.asServiceRole.entities.CircleInvite.filter({ invited_by_id: userId }, '-created_date', 1);
  const invitedUser = await base44.asServiceRole.entities.CircleInvite.filter({ invited_user_id: userId }, '-created_date', 1);
  const acceptedBy = await base44.asServiceRole.entities.CircleInvite.filter({ accepted_by_id: userId }, '-created_date', 1);
  const requests = await base44.asServiceRole.entities.CircleJoinRequest.filter({ user_id: userId }, '-created_date', 1);
  const actorActions = await base44.asServiceRole.entities.CircleModerationAction.filter({ actor_user_id: userId }, '-created_date', 1);
  const targetActions = await base44.asServiceRole.entities.CircleModerationAction.filter({ target_user_id: userId }, '-created_date', 1);
  if (ownedCircle[0]) remainingEntities.push('Circle');
  if (membership[0]) remainingEntities.push('CircleMember');
  if (invitedBy[0] || invitedUser[0] || acceptedBy[0]) remainingEntities.push('CircleInvite');
  if (requests[0]) remainingEntities.push('CircleJoinRequest');
  if (actorActions[0] || targetActions[0]) remainingEntities.push('CircleModerationAction');
  if (remainingEntities.length > 0) {
    throw new Error(`Deletion verification failed for: ${remainingEntities.join(', ')}`);
  }
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    if (body.confirmation !== 'DELETE') {
      return Response.json({ error: 'Type DELETE to confirm account deletion.' }, { status: 400 });
    }

    await removeUserFromCircles(base44, user.id);
    for (const entityName of USER_OWNED_ENTITIES) {
      await deleteEntityRecordsForUser(base44, entityName, user.id);
    }

    await verifyNoUserRecordsRemain(base44, user.id);
    await base44.asServiceRole.entities.User.delete(user.id);

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message || 'Account deletion failed.' }, { status: 500 });
  }
});