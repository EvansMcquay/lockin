import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

const QUICK_MESSAGES = ['💪 Lock in!', '📚 Homework time!', '🔥 You got this!', '👏 Finish strong!', '🚀 Let’s go!'];
const HELP_MODES = ['celebrate', 'start_encouragement', 'both'];
const MAX_FRIENDS = 24;

function nowIso() { return new Date().toISOString(); }
function cleanText(value, limit) { return String(value || '').trim().slice(0, limit); }
function displayName(user) { return user.first_name || user.full_name || (user.email ? user.email.split('@')[0] : 'Friend'); }
function usernameFor(user) { return String(user.username || '').toLowerCase(); }
function isOffensive(value) {
  const text = String(value || '').toLowerCase();
  return ['fuck', 'shit', 'bitch', 'asshole', 'nigger', 'faggot', 'cunt', 'whore', 'slut', 'kill', 'rape'].some(term => text.includes(term));
}
function startMinutes(time) {
  const [h, m] = String(time || '00:00').split(':').map(Number);
  return (Number(h) || 0) * 60 + (Number(m) || 0);
}
function zonedNow(timeZone) {
  const parts = new Intl.DateTimeFormat('en-US', { timeZone: timeZone || 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit', weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(new Date());
  const get = type => parts.find(p => p.type === type)?.value || '';
  const hour = Number(get('hour')) % 24;
  const minute = Number(get('minute'));
  const weekdays = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  return { date: `${get('year')}-${get('month')}-${get('day')}`, day: weekdays[get('weekday')] ?? 0, minutes: hour * 60 + minute };
}
async function activeMembers(base44, circleId) {
  return await base44.asServiceRole.entities.CircleMember.filter({ circle_id: circleId, status: 'active' }, '-created_date', 50);
}
async function memberships(base44, userId) {
  return await base44.asServiceRole.entities.CircleMember.filter({ user_id: userId, status: 'active' }, '-created_date', 100);
}
async function memberOf(base44, circleId, userId) {
  const rows = await base44.asServiceRole.entities.CircleMember.filter({ circle_id: circleId, user_id: userId, status: 'active' }, '-created_date', 1);
  return rows[0] || null;
}
async function enrichMember(base44, member) {
  const user = await base44.asServiceRole.entities.User.get(member.user_id).catch(() => null);
  return { id: member.user_id, name: member.display_name || (user ? displayName(user) : 'Friend'), username: member.username || (user ? usernameFor(user) : ''), photo_url: user?.profile_image_url || user?.avatar_url || user?.photo_url || '' };
}
async function lockinFriendsContext(base44, user) {
  const myMemberships = await memberships(base44, user.id);
  const selections = await base44.asServiceRole.entities.LockinFriendSelection.filter({ owner_user_id: user.id }, '-created_date', 500).catch(() => []);
  const usage = new Map();
  for (const row of selections) usage.set(row.friend_user_id, (usage.get(row.friend_user_id) || 0) + 1);
  const peopleById = new Map();
  const circles = [];
  for (const membership of myMemberships) {
    const circle = await base44.asServiceRole.entities.Circle.get(membership.circle_id).catch(() => null);
    if (!circle || circle.deleted_at) continue;
    const members = (await activeMembers(base44, circle.id)).filter(m => m.user_id !== user.id);
    circles.push({ id: circle.id, name: circle.name, icon: circle.icon || '🤝', member_count: members.length });
    for (const member of members) if (!peopleById.has(member.user_id)) peopleById.set(member.user_id, await enrichMember(base44, member));
  }
  const people = [...peopleById.values()].map(person => ({ ...person, frequency: usage.get(person.id) || 0 })).sort((a, b) => b.frequency - a.frequency || a.name.localeCompare(b.name));
  return { people, circles, quickMessages: QUICK_MESSAGES };
}
async function expandTargets(base44, user, targets) {
  const people = new Map();
  for (const target of (Array.isArray(targets) ? targets : []).slice(0, 12)) {
    if (target.type === 'circle') {
      const circleId = cleanText(target.id, 80);
      if (!(await memberOf(base44, circleId, user.id))) continue;
      const circle = await base44.asServiceRole.entities.Circle.get(circleId).catch(() => null);
      const members = (await activeMembers(base44, circleId)).filter(m => m.user_id !== user.id);
      for (const member of members) people.set(member.user_id, { ...(await enrichMember(base44, member)), source_type: 'circle', source_circle_id: circleId, source_circle_name: circle?.name || 'Circle' });
    } else {
      const friendId = cleanText(target.id, 80);
      let found = null;
      for (const membership of await memberships(base44, user.id)) {
        const member = await memberOf(base44, membership.circle_id, friendId);
        if (member) { found = member; break; }
      }
      if (found) people.set(friendId, { ...(await enrichMember(base44, found)), source_type: 'person' });
    }
  }
  return [...people.values()].slice(0, MAX_FRIENDS);
}
async function saveLockinFriends(base44, user, payload) {
  const targets = await expandTargets(base44, user, payload.targets);
  const helpMode = HELP_MODES.includes(payload.helpMode) ? payload.helpMode : 'both';
  const scheduleId = cleanText(payload.scheduleId, 100);
  const lockSessionKey = cleanText(payload.lockSessionKey, 140);
  if (!targets.length) return { saved: 0 };
  if (scheduleId) {
    const existing = await base44.asServiceRole.entities.LockinFriendSelection.filter({ owner_user_id: user.id, schedule_id: scheduleId, status: 'active' }, '-created_date', 100).catch(() => []);
    await Promise.all(existing.map(row => base44.asServiceRole.entities.LockinFriendSelection.update(row.id, { status: 'archived' })));
  }
  const rows = [];
  for (const person of targets) rows.push({
    owner_user_id: user.id,
    owner_name: displayName(user),
    owner_username: usernameFor(user),
    friend_user_id: person.id,
    friend_name: person.name,
    friend_username: person.username,
    friend_photo_url: person.photo_url,
    source_type: person.source_type || 'person',
    source_circle_id: person.source_circle_id,
    source_circle_name: person.source_circle_name,
    help_mode: helpMode,
    lock_session_key: lockSessionKey,
    schedule_id: scheduleId,
    goal_name: cleanText(payload.goalName, 120),
    category: cleanText(payload.category, 80) || 'Lockin',
    start_at: cleanText(payload.startAt, 40),
    timezone: cleanText(payload.timezone, 80) || 'America/New_York',
    status: 'active',
    last_used_at: nowIso()
  });
  await base44.asServiceRole.entities.LockinFriendSelection.bulkCreate(rows);
  return { saved: rows.length };
}
async function hasStartedSchedule(base44, selection, schedule, localDate, localStart) {
  const locks = await base44.asServiceRole.entities.AppLock.filter({ created_by_id: selection.owner_user_id, goal_name: schedule.goal_name || schedule.label }, '-created_date', 30).catch(() => []);
  return locks.some(lock => {
    const when = new Date(lock.locked_at);
    const z = new Intl.DateTimeFormat('en-CA', { timeZone: selection.timezone || 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit' }).format(when);
    const mins = Number(new Intl.DateTimeFormat('en-US', { timeZone: selection.timezone || 'America/New_York', hour: '2-digit', minute: '2-digit', hour12: false }).format(when).split(':')[0]) * 60 + Number(new Intl.DateTimeFormat('en-US', { timeZone: selection.timezone || 'America/New_York', hour: '2-digit', minute: '2-digit', hour12: false }).format(when).split(':')[1]);
    return z === localDate && mins >= localStart - 10;
  });
}
async function maybeCreateStartRequest(base44, selection, schedule, local) {
  if (!['start_encouragement', 'both'].includes(selection.help_mode)) return 0;
  if (!schedule || schedule.deleted_at || schedule.is_active === false) return 0;
  if (!(schedule.days_of_week || []).includes(local.day) || (schedule.skip_dates || []).includes(local.date)) return 0;
  const start = startMinutes(schedule.start_time);
  if (local.minutes < start + 1 || local.minutes > start + 45) return 0;
  if (await hasStartedSchedule(base44, selection, schedule, local.date, start)) return 0;
  const existing = await base44.asServiceRole.entities.LockinFriendNotification.filter({ selection_id: selection.id, to_user_id: selection.friend_user_id, type: 'encouragement_request', local_date: local.date }, '-created_date', 1).catch(() => []);
  if (existing[0]) return 0;
  await base44.asServiceRole.entities.LockinFriendNotification.create({
    selection_id: selection.id,
    owner_user_id: selection.owner_user_id,
    owner_name: selection.owner_name,
    owner_username: selection.owner_username,
    to_user_id: selection.friend_user_id,
    type: 'encouragement_request',
    message: `${selection.owner_name || 'Your friend'} could use a little push to start today’s ${selection.goal_name || 'Lockin'}.`,
    goal_name: selection.goal_name,
    category: selection.category,
    schedule_id: selection.schedule_id,
    lock_session_key: `${selection.schedule_id}-${local.date}`,
    local_date: local.date,
    status: 'sent'
  });
  return 1;
}
async function processDueStartChecks(base44) {
  const selections = await base44.asServiceRole.entities.LockinFriendSelection.filter({ status: 'active' }, '-created_date', 500).catch(() => []);
  let sent = 0;
  for (const selection of selections.filter(s => s.schedule_id)) {
    const schedule = await base44.asServiceRole.entities.RecurringSchedule.get(selection.schedule_id).catch(() => null);
    sent += await maybeCreateStartRequest(base44, selection, schedule, zonedNow(selection.timezone));
  }
  return { sent };
}
async function processMyDueStartChecks(base44, user, payload) {
  const selections = await base44.asServiceRole.entities.LockinFriendSelection.filter({ owner_user_id: user.id, status: 'active' }, '-created_date', 200).catch(() => []);
  let sent = 0;
  for (const selection of selections.filter(s => s.schedule_id)) {
    const schedule = await base44.asServiceRole.entities.RecurringSchedule.get(selection.schedule_id).catch(() => null);
    const local = payload.localDate ? { date: cleanText(payload.localDate, 10), day: Number(payload.currentDay), minutes: Number(payload.currentMinutes) } : zonedNow(selection.timezone);
    sent += await maybeCreateStartRequest(base44, selection, schedule, local);
  }
  return { sent };
}
async function listNotifications(base44, user) {
  const items = await base44.asServiceRole.entities.LockinFriendNotification.filter({ to_user_id: user.id, status: 'sent' }, '-created_date', 30).catch(() => []);
  return { notifications: items };
}
async function sendEncouragement(base44, user, payload) {
  const note = await base44.asServiceRole.entities.LockinFriendNotification.get(payload.notificationId);
  if (!note || note.to_user_id !== user.id || note.type !== 'encouragement_request' || note.status !== 'sent') throw new Error('Encouragement is no longer available.');
  const message = cleanText(payload.message, 80);
  if (!message || isOffensive(message)) throw new Error('Keep it short and positive.');
  await base44.asServiceRole.entities.LockinFriendNotification.create({ selection_id: note.selection_id, owner_user_id: note.owner_user_id, owner_name: note.owner_name, owner_username: note.owner_username, from_user_id: user.id, from_name: displayName(user), from_username: usernameFor(user), to_user_id: note.owner_user_id, type: 'encouragement_message', message, goal_name: note.goal_name, category: note.category, schedule_id: note.schedule_id, lock_session_key: note.lock_session_key, local_date: note.local_date, status: 'sent' });
  await base44.asServiceRole.entities.LockinFriendNotification.update(note.id, { status: 'responded', responded_at: nowIso() });
  return { success: true };
}
async function dismissNotification(base44, user, payload) {
  const note = await base44.asServiceRole.entities.LockinFriendNotification.get(payload.notificationId);
  if (!note || note.to_user_id !== user.id) throw new Error('Notification not found.');
  const status = payload.status === 'snoozed' ? 'snoozed' : 'dismissed';
  await base44.asServiceRole.entities.LockinFriendNotification.update(note.id, { status, responded_at: nowIso() });
  return { success: true };
}
async function notifyCompleted(base44, user, payload) {
  const key = cleanText(payload.lockSessionKey, 140);
  const scheduleId = cleanText(payload.scheduleId, 100);
  const filters = key ? [{ owner_user_id: user.id, lock_session_key: key, status: 'active' }] : [];
  if (scheduleId) filters.push({ owner_user_id: user.id, schedule_id: scheduleId, status: 'active' });
  let selections = [];
  for (const filter of filters) selections = selections.concat(await base44.asServiceRole.entities.LockinFriendSelection.filter(filter, '-created_date', 100).catch(() => []));
  const seen = new Set();
  let sent = 0;
  for (const selection of selections) {
    if (seen.has(selection.friend_user_id) || !['celebrate', 'both'].includes(selection.help_mode)) continue;
    seen.add(selection.friend_user_id);
    const existing = await base44.asServiceRole.entities.LockinFriendNotification.filter({ selection_id: selection.id, to_user_id: selection.friend_user_id, type: 'celebration' }, '-created_date', 1).catch(() => []);
    if (existing[0]) continue;
    await base44.asServiceRole.entities.LockinFriendNotification.create({ selection_id: selection.id, owner_user_id: user.id, owner_name: displayName(user), owner_username: usernameFor(user), to_user_id: selection.friend_user_id, type: 'celebration', message: `${displayName(user)} finished ${selection.goal_name || 'a Lockin'}.`, goal_name: selection.goal_name, category: selection.category, schedule_id: selection.schedule_id, lock_session_key: key, status: 'sent' });
    sent++;
  }
  return { sent };
}

const handlers = { lockinFriendsContext, saveLockinFriends, processDueStartChecks, processMyDueStartChecks, listNotifications, sendEncouragement, dismissNotification, notifyCompleted };

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const action = body.action;
    if (!handlers[action]) return Response.json({ error: 'Unsupported Lockin Friends action.' }, { status: 400 });
    if (action === 'processDueStartChecks') return Response.json(await processDueStartChecks(base44));
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    return Response.json(await handlers[action](base44, user, body.payload || {}));
  } catch (error) {
    return Response.json({ error: error.message || 'Lockin Friends action failed.' }, { status: 500 });
  }
});