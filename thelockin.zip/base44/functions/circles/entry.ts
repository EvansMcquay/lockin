import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

const MAX_MEMBERS = 8;
const INVITE_DAYS = 14;
const USERNAME_COOLDOWN_DAYS = 14;
const POSITIVE_REACTIONS = ['🔥', '👏', '💪', '✅', '🙌', '😂'];
const SESSION_REACTIONS = ['🔥', '💪', '👏', '🙌'];
const SESSION_MESSAGES = ['Keep going', 'Finish strong', 'You got this', 'We’re locked in', 'Almost there'];
const BLOCKED_TERMS = ['fuck', 'shit', 'bitch', 'asshole', 'nigger', 'faggot', 'cunt', 'whore', 'slut', 'hitler', 'nazi', 'kill', 'rape'];

function nowIso() { return new Date().toISOString(); }
function displayName(user) { return user.first_name || user.full_name || (user.email ? user.email.split('@')[0] : 'Member'); }
function usernameFor(user) { return String(user.username || '').toLowerCase(); }
function cleanText(value, limit) { return String(value || '').trim().slice(0, limit); }
function token() { return crypto.randomUUID().replaceAll('-', ''); }
function isOffensive(value) { const text = String(value || '').toLowerCase(); return BLOCKED_TERMS.some(term => text.includes(term)); }
function normalizeUsername(value) { return cleanText(value, 30).replace(/^@/, '').toLowerCase(); }
function validUsername(username) { return /^[a-z0-9._]{3,20}$/.test(username) && !isOffensive(username); }

function randomCircleCode() {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let value = '';
  const bytes = new Uint8Array(5);
  crypto.getRandomValues(bytes);
  for (const byte of bytes) value += alphabet[byte % alphabet.length];
  return value;
}

async function uniqueCircleCode(base44) {
  for (let i = 0; i < 8; i++) {
    const code = randomCircleCode();
    const existing = await base44.asServiceRole.entities.Circle.filter({ code }, '-created_date', 1);
    if (!existing[0]) return code;
  }
  throw new Error('Could not generate a unique circle code.');
}

function normalizeCircleCode(value) { return cleanText(value, 24).toUpperCase().replace(/[^A-Z0-9]/g, ''); }
function expiresAt() { const d = new Date(); d.setDate(d.getDate() + INVITE_DAYS); return d.toISOString(); }

async function activeMembers(base44, circleId) {
  return await base44.asServiceRole.entities.CircleMember.filter({ circle_id: circleId, status: 'active' }, '-created_date', 50);
}
async function getCircle(base44, circleId) {
  const circle = await base44.asServiceRole.entities.Circle.get(circleId);
  if (!circle || circle.deleted_at) throw new Error('Circle not found.');
  return circle;
}
async function getMembership(base44, circleId, userId) {
  const rows = await base44.asServiceRole.entities.CircleMember.filter({ circle_id: circleId, user_id: userId, status: 'active' }, '-created_date', 1);
  return rows[0] || null;
}
async function requireMember(base44, circleId, userId) {
  const member = await getMembership(base44, circleId, userId);
  if (!member) throw new Error('You are not a member of this circle.');
  return member;
}
async function requireOwner(base44, circleId, userId) {
  const member = await requireMember(base44, circleId, userId);
  if (member.role !== 'owner') throw new Error('Only the circle owner can do that.');
  return member;
}
async function refreshCount(base44, circleId) {
  const members = await activeMembers(base44, circleId);
  await base44.asServiceRole.entities.Circle.update(circleId, { member_count: members.length });
  return members.length;
}
async function ensureCircleCode(base44, circle) {
  if (circle.code) return circle;
  const code = await uniqueCircleCode(base44);
  await base44.asServiceRole.entities.Circle.update(circle.id, { code });
  return { ...circle, code };
}
async function ensureSharingPreference(base44, circleId, userId) {
  const existing = (await base44.asServiceRole.entities.CircleSharingPreference.filter({ circle_id: circleId, user_id: userId }, '-created_date', 1))[0];
  if (existing) return existing;
  return await base44.asServiceRole.entities.CircleSharingPreference.create({
    circle_id: circleId,
    user_id: userId,
    started_visibility: 'nobody',
    started_selected_user_ids: [],
    completed_visibility: 'everyone',
    completed_selected_user_ids: [],
    allow_reactions: true,
    allow_messages: true,
  });
}
async function createJoinActivity(base44, circleId, user) {
  await base44.asServiceRole.entities.CircleActivity.create({
    circle_id: circleId,
    actor_user_id: user.id,
    actor_name: displayName(user),
    actor_username: usernameFor(user),
    type: 'member_joined',
    status: 'completed',
    completed_at: nowIso(),
    visibility: 'everyone',
    selected_user_ids: [],
    allow_reactions: false,
    allow_messages: false,
  });
}
async function serializeCircle(base44, circle) {
  const codedCircle = await ensureCircleCode(base44, circle);
  const members = await activeMembers(base44, circle.id);
  for (const member of members) await ensureSharingPreference(base44, circle.id, member.user_id);
  return { ...codedCircle, members, member_count: members.length };
}
async function circleSummary(base44, circle) {
  const codedCircle = await ensureCircleCode(base44, circle);
  const members = await activeMembers(base44, circle.id);
  return { ...codedCircle, members: [], member_count: members.length };
}

async function usernameTaken(base44, username, currentUserId = '') {
  const matches = await base44.asServiceRole.entities.User.filter({ username }, '-created_date', 2);
  return matches.some(u => u.id !== currentUserId);
}
async function availableSuggestions(base44, desired) {
  const base = (desired.replace(/[^a-z0-9_]/g, '') || 'lockin').slice(0, 14);
  const candidates = [`${base}_${Math.floor(10 + Math.random() * 89)}`, `${base}.${Math.floor(100 + Math.random() * 899)}`, `${base}locks`].map(v => v.slice(0, 20));
  const available = [];
  for (const candidate of candidates) {
    if (validUsername(candidate) && !(await usernameTaken(base44, candidate))) available.push(candidate);
  }
  return available.slice(0, 3);
}
async function checkUsernameAvailability(base44, _user, payload) {
  const username = normalizeUsername(payload.username);
  if (!username) return { available: false, reason: 'Username is required.', suggestions: [] };
  if (!/^[a-z0-9._]+$/.test(username)) return { available: false, reason: 'Use letters, numbers, underscores, or periods only.', suggestions: await availableSuggestions(base44, username) };
  if (username.length < 3) return { available: false, reason: 'Username must be at least 3 characters.', suggestions: [] };
  if (username.length > 20) return { available: false, reason: 'Username must be 20 characters or less.', suggestions: [] };
  if (isOffensive(username)) return { available: false, reason: 'Choose a different username.', suggestions: await availableSuggestions(base44, username) };
  const taken = await usernameTaken(base44, username, payload.currentUserId || '');
  return { available: !taken, username, reason: taken ? 'That username is already taken.' : '', suggestions: taken ? await availableSuggestions(base44, username) : [] };
}
async function updateUsername(base44, user, payload) {
  const username = normalizeUsername(payload.username);
  if (!validUsername(username)) throw new Error('Choose a username with 3–20 letters, numbers, underscores, or periods.');
  if (await usernameTaken(base44, username, user.id)) throw new Error('That username is already taken.');
  const current = usernameFor(user);
  if (current && current === username) return { username };
  if (current && user.username_updated_at) {
    const nextAllowed = new Date(new Date(user.username_updated_at).getTime() + USERNAME_COOLDOWN_DAYS * 86400000);
    if (nextAllowed > new Date()) throw new Error(`You can change your username again on ${nextAllowed.toLocaleDateString('en-US')}.`);
  }
  const name = cleanText(payload.name, 80);
  const updates = { username, username_updated_at: nowIso() };
  if (name) updates.first_name = name.split(' ')[0];
  await base44.asServiceRole.entities.User.update(user.id, updates);
  const memberships = await base44.asServiceRole.entities.CircleMember.filter({ user_id: user.id, status: 'active' }, '-created_date', 100);
  await Promise.all(memberships.map(m => base44.asServiceRole.entities.CircleMember.update(m.id, { username, display_name: name || displayName(user) })));
  return { username };
}

function requireUsername(user) {
  if (!usernameFor(user)) throw new Error('Create a username before using Circles.');
}

async function createCircle(base44, user, payload) {
  requireUsername(user);
  const name = cleanText(payload.name, 60);
  if (!name) throw new Error('Circle name is required.');
  const privacy = payload.privacy === 'public' ? 'public' : 'private';
  const circle = await base44.asServiceRole.entities.Circle.create({ name, icon: cleanText(payload.icon || '🤝', 8), code: await uniqueCircleCode(base44), privacy, purpose: cleanText(payload.purpose, 160), owner_id: user.id, owner_name: displayName(user), member_count: 1 });
  await base44.asServiceRole.entities.CircleMember.create({ circle_id: circle.id, user_id: user.id, display_name: displayName(user), username: usernameFor(user), role: 'owner', status: 'active', joined_at: nowIso() });
  await ensureSharingPreference(base44, circle.id, user.id);
  await createJoinActivity(base44, circle.id, user);
  return await serializeCircle(base44, circle);
}
async function listCircles(base44, user) {
  const requiresUsername = !usernameFor(user);
  if (requiresUsername) return { circles: [], invitations: [], publicCircles: [], username: '', requiresUsername: true };
  const memberships = await base44.asServiceRole.entities.CircleMember.filter({ user_id: user.id, status: 'active' }, '-created_date', 100);
  const circles = [];
  for (const membership of memberships) {
    const circle = await base44.asServiceRole.entities.Circle.get(membership.circle_id).catch(() => null);
    if (circle && !circle.deleted_at) circles.push(await serializeCircle(base44, circle));
  }
  const invites = await base44.asServiceRole.entities.CircleInvite.filter({ invited_user_id: user.id, status: 'pending' }, '-created_date', 50);
  const invitations = [];
  for (const invite of invites) {
    const circle = await base44.asServiceRole.entities.Circle.get(invite.circle_id).catch(() => null);
    if (circle && !circle.deleted_at && new Date(invite.expires_at) > new Date()) invitations.push({ ...invite, circle: await circleSummary(base44, circle) });
  }
  const allPublic = await base44.asServiceRole.entities.Circle.filter({ privacy: 'public' }, '-created_date', 50);
  const publicCircles = [];
  for (const circle of allPublic) {
    if (circle.deleted_at || memberships.some(m => m.circle_id === circle.id)) continue;
    publicCircles.push(await circleSummary(base44, circle));
  }
  return { circles, invitations, publicCircles, username: usernameFor(user), requiresUsername: false };
}

function visibleToUser(activity, userId) {
  if (activity.visibility !== 'selected') return true;
  return activity.actor_user_id === userId || (activity.selected_user_ids || []).includes(userId);
}
async function serializeActivity(base44, activity, currentUserId) {
  const reactions = await base44.asServiceRole.entities.CircleReaction.filter({ activity_id: activity.id }, '-created_date', 100);
  const encouragements = await base44.asServiceRole.entities.CircleEncouragement.filter({ activity_id: activity.id, status: 'active' }, 'created_date', 50);
  const counts = {};
  for (const reaction of reactions) counts[reaction.emoji] = (counts[reaction.emoji] || 0) + 1;
  return { ...activity, reaction_counts: counts, my_reactions: reactions.filter(r => r.user_id === currentUserId).map(r => r.emoji), encouragements };
}
async function getCircleDetail(base44, user, payload) {
  requireUsername(user);
  const circle = await getCircle(base44, payload.circleId);
  const membership = await requireMember(base44, circle.id, user.id);
  const data = await serializeCircle(base44, circle);
  const isOwner = membership.role === 'owner';
  const invites = isOwner ? await base44.asServiceRole.entities.CircleInvite.filter({ circle_id: circle.id, status: 'pending' }, '-created_date', 50) : [];
  const requests = isOwner ? await base44.asServiceRole.entities.CircleJoinRequest.filter({ circle_id: circle.id, status: 'pending' }, '-created_date', 50) : [];
  const sharing = await ensureSharingPreference(base44, circle.id, user.id);
  const cutoff = new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString();
  const rows = await base44.asServiceRole.entities.CircleActivity.filter({ circle_id: circle.id }, '-created_date', 40);
  const sharedRows = await base44.asServiceRole.entities.SharedLockin.filter({ circle_id: circle.id }, '-start_at', 20).catch(() => []);
  const sharedLockins = [];
  for (const row of sharedRows) sharedLockins.push(await serializeSharedLockin(base44, row, user.id));
  const recent = rows.filter(a => new Date(a.created_date || a.started_at || a.completed_at || 0) >= new Date(cutoff) && visibleToUser(a, user.id)).slice(0, 20);
  const activity = [];
  for (const item of recent) activity.push(await serializeActivity(base44, item, user.id));
  const activeStatuses = {};
  for (const item of rows) {
    if (item.type === 'lockin_started' && item.status === 'active' && item.unlocks_at && new Date(item.unlocks_at) > new Date() && visibleToUser(item, user.id)) activeStatuses[item.actor_user_id] = 'locked_in';
  }
  const accountability = await ensureAccountabilityPreference(base44, user.id);
  const goalPreference = await ensureGoalPreference(base44, circle.id, user.id);
  const activeGoal = await activeCircleGoal(base44, circle.id);
  const spotlightSharedLockin = sharedLockins.find(item => item.status !== 'cancelled' && new Date(item.end_at) > new Date()) || null;
  return { circle: data, membership, invites, requests, activity, sharedLockins, spotlightSharedLockin, activeGoal, goalPreference, sharing, accountability, activeStatuses, positiveReactions: POSITIVE_REACTIONS };
}
async function updateCircle(base44, user, payload) {
  await requireOwner(base44, payload.circleId, user.id);
  const updates = {};
  if (payload.name !== undefined) updates.name = cleanText(payload.name, 60);
  if (payload.icon !== undefined) updates.icon = cleanText(payload.icon || '🤝', 8);
  if (payload.purpose !== undefined) updates.purpose = cleanText(payload.purpose, 160);
  if (payload.privacy !== undefined) updates.privacy = payload.privacy === 'public' ? 'public' : 'private';
  if (updates.name === '') throw new Error('Circle name is required.');
  await base44.asServiceRole.entities.Circle.update(payload.circleId, updates);
  return { success: true };
}
function effectiveInviteStatus(invite) {
  if (!invite) return 'none';
  if (invite.status === 'pending' && invite.expires_at && new Date(invite.expires_at) <= new Date()) return 'expired';
  return invite.status || 'none';
}
async function inviteUsername(base44, user, payload) {
  requireUsername(user);
  await requireOwner(base44, payload.circleId, user.id);
  const members = await activeMembers(base44, payload.circleId);
  if (members.length >= MAX_MEMBERS) throw new Error('Circle Full.');
  const username = normalizeUsername(payload.username);
  if (!username) throw new Error('Username is required.');
  const invited = (await base44.asServiceRole.entities.User.filter({ username }, '-created_date', 1))[0];
  if (!invited) throw new Error('No user found with that username.');
  if (members.some(m => m.user_id === invited.id)) throw new Error('That user is already in this circle.');
  const existing = await base44.asServiceRole.entities.CircleInvite.filter({ circle_id: payload.circleId, invited_user_id: invited.id }, '-created_date', 1);
  if (existing[0]) return existing[0];
  return await base44.asServiceRole.entities.CircleInvite.create({ circle_id: payload.circleId, token: token(), invited_user_id: invited.id, invited_username: username, invited_by_id: user.id, inviter_name: displayName(user), status: 'pending', expires_at: expiresAt() });
}
async function searchInviteUsers(base44, user, payload) {
  requireUsername(user);
  await requireOwner(base44, payload.circleId, user.id);
  const query = normalizeUsername(payload.query);
  if (query.length < 2) return { users: [] };
  const members = await activeMembers(base44, payload.circleId);
  const memberIds = new Set(members.map(m => m.user_id));
  const invites = await base44.asServiceRole.entities.CircleInvite.filter({ circle_id: payload.circleId }, '-created_date', 200);
  const latestInviteByUser = new Map();
  for (const invite of invites) {
    if (invite.invited_user_id && !latestInviteByUser.has(invite.invited_user_id)) latestInviteByUser.set(invite.invited_user_id, invite);
  }
  const users = await base44.asServiceRole.entities.User.list('-created_date', 200);
  const matches = users
    .filter(item => item.id !== user.id && usernameFor(item) && (usernameFor(item).includes(query) || displayName(item).toLowerCase().includes(query)))
    .slice(0, 12)
    .map(item => {
      const invite = latestInviteByUser.get(item.id);
      return {
        id: item.id,
        display_name: displayName(item),
        username: usernameFor(item),
        profile_image_url: item.profile_image_url || item.avatar_url || item.photo_url || '',
        is_member: memberIds.has(item.id),
        invite_status: memberIds.has(item.id) ? 'accepted' : effectiveInviteStatus(invite),
      };
    });
  return { users: matches };
}
async function inviteUsers(base44, user, payload) {
  requireUsername(user);
  await requireOwner(base44, payload.circleId, user.id);
  const members = await activeMembers(base44, payload.circleId);
  if (members.length >= MAX_MEMBERS) throw new Error('Circle Full.');
  const memberIds = new Set(members.map(m => m.user_id));
  const userIds = [...new Set((payload.userIds || []).map(id => cleanText(id, 80)).filter(Boolean))].slice(0, 8);
  if (!userIds.length) throw new Error('Choose at least one user.');
  const results = [];
  for (const userId of userIds) {
    if (memberIds.has(userId) || userId === user.id) continue;
    const invited = await base44.asServiceRole.entities.User.get(userId).catch(() => null);
    if (!invited || !usernameFor(invited)) continue;
    const existing = await base44.asServiceRole.entities.CircleInvite.filter({ circle_id: payload.circleId, invited_user_id: invited.id }, '-created_date', 1);
    if (existing[0]) {
      results.push({ user_id: invited.id, username: usernameFor(invited), status: effectiveInviteStatus(existing[0]) });
      continue;
    }
    const invite = await base44.asServiceRole.entities.CircleInvite.create({ circle_id: payload.circleId, token: token(), invited_user_id: invited.id, invited_username: usernameFor(invited), invited_by_id: user.id, inviter_name: displayName(user), status: 'pending', expires_at: expiresAt() });
    results.push({ user_id: invited.id, username: usernameFor(invited), status: invite.status, invite_id: invite.id });
  }
  return { sent: results.filter(item => item.status === 'pending').length, invitations: results };
}
async function createInviteLink(base44, user, payload) {
  await requireOwner(base44, payload.circleId, user.id);
  const members = await activeMembers(base44, payload.circleId);
  if (members.length >= MAX_MEMBERS) throw new Error('Circle Full.');
  return await base44.asServiceRole.entities.CircleInvite.create({ circle_id: payload.circleId, token: token(), invited_by_id: user.id, inviter_name: displayName(user), status: 'pending', expires_at: expiresAt() });
}
async function previewInvite(base44, _user, payload) {
  const invite = (await base44.asServiceRole.entities.CircleInvite.filter({ token: cleanText(payload.token, 120), status: 'pending' }, '-created_date', 1))[0];
  if (!invite || new Date(invite.expires_at) <= new Date()) throw new Error('This invitation is invalid or expired.');
  const circle = await getCircle(base44, invite.circle_id);
  return { invite, circle: await circleSummary(base44, circle) };
}
async function addMember(base44, circleId, user, role = 'member') {
  await base44.asServiceRole.entities.CircleMember.create({ circle_id: circleId, user_id: user.id, display_name: displayName(user), username: usernameFor(user), role, status: 'active', joined_at: nowIso() });
  await ensureSharingPreference(base44, circleId, user.id);
  await createJoinActivity(base44, circleId, user);
}
async function joinByCircleCode(base44, user, payload) {
  requireUsername(user);
  const code = normalizeCircleCode(payload.code);
  if (!code) throw new Error('Circle code is required.');
  const circle = (await base44.asServiceRole.entities.Circle.filter({ code }, '-created_date', 1))[0];
  if (!circle || circle.deleted_at) throw new Error('No circle found with that code.');
  const members = await activeMembers(base44, circle.id);
  if (members.length >= MAX_MEMBERS) throw new Error('Circle Full.');
  if (!members.some(m => m.user_id === user.id)) {
    await addMember(base44, circle.id, user);
    await refreshCount(base44, circle.id);
  }
  return { circleId: circle.id };
}
async function acceptInvite(base44, user, payload) {
  requireUsername(user);
  const tokenValue = cleanText(payload.token, 120);
  const invite = tokenValue ? (await base44.asServiceRole.entities.CircleInvite.filter({ token: tokenValue, status: 'pending' }, '-created_date', 1))[0] : await base44.asServiceRole.entities.CircleInvite.get(payload.inviteId);
  if (!invite || invite.status !== 'pending' || new Date(invite.expires_at) <= new Date()) throw new Error('This invitation is invalid or expired.');
  if (invite.invited_user_id && invite.invited_user_id !== user.id) throw new Error('This invitation belongs to another user.');
  const members = await activeMembers(base44, invite.circle_id);
  if (members.length >= MAX_MEMBERS) throw new Error('Circle Full.');
  if (!members.some(m => m.user_id === user.id)) await addMember(base44, invite.circle_id, user);
  await base44.asServiceRole.entities.CircleInvite.update(invite.id, { status: 'accepted', accepted_by_id: user.id });
  await refreshCount(base44, invite.circle_id);
  return { circleId: invite.circle_id };
}
async function declineInvite(base44, user, payload) {
  const invite = payload.inviteId ? await base44.asServiceRole.entities.CircleInvite.get(payload.inviteId) : (await base44.asServiceRole.entities.CircleInvite.filter({ token: cleanText(payload.token, 120), status: 'pending' }, '-created_date', 1))[0];
  if (!invite || (invite.invited_user_id && invite.invited_user_id !== user.id)) throw new Error('Invitation not found.');
  await base44.asServiceRole.entities.CircleInvite.update(invite.id, { status: 'declined' });
  return { success: true };
}
async function leaveCircle(base44, user, payload) {
  const member = await requireMember(base44, payload.circleId, user.id);
  const members = await activeMembers(base44, payload.circleId);
  if (member.role === 'owner' && members.length > 1) {
    const nextOwner = members.filter(m => m.user_id !== user.id).sort((a, b) => new Date(a.joined_at) - new Date(b.joined_at))[0];
    await base44.asServiceRole.entities.CircleMember.update(nextOwner.id, { role: 'owner' });
    await base44.asServiceRole.entities.Circle.update(payload.circleId, { owner_id: nextOwner.user_id, owner_name: nextOwner.display_name });
  }
  if (members.length === 1) {
    await base44.asServiceRole.entities.Circle.update(payload.circleId, { deleted_at: nowIso(), member_count: 0 });
    await base44.asServiceRole.entities.CircleInvite.updateMany({ circle_id: payload.circleId, status: 'pending' }, { $set: { status: 'revoked' } });
  }
  await base44.asServiceRole.entities.CircleMember.update(member.id, { status: 'left', role: 'member' });
  await refreshCount(base44, payload.circleId).catch(() => null);
  return { success: true };
}
async function removeMember(base44, user, payload) {
  await requireOwner(base44, payload.circleId, user.id);
  if (payload.memberUserId === user.id) throw new Error('Use Leave Circle to leave your own circle.');
  const member = await getMembership(base44, payload.circleId, payload.memberUserId);
  if (!member) throw new Error('Member not found.');
  await base44.asServiceRole.entities.CircleModerationAction.create({ circle_id: payload.circleId, actor_user_id: user.id, target_user_id: payload.memberUserId, action: 'remove', status: 'active' });
  await base44.asServiceRole.entities.CircleMember.update(member.id, { status: 'removed' });
  await refreshCount(base44, payload.circleId);
  return { success: true };
}
async function moderationAction(base44, user, payload, action) {
  await requireMember(base44, payload.circleId, user.id);
  if (!payload.targetUserId || payload.targetUserId === user.id) throw new Error('Choose another member.');
  await base44.asServiceRole.entities.CircleModerationAction.create({ circle_id: payload.circleId, actor_user_id: user.id, target_user_id: payload.targetUserId, action, reason: cleanText(payload.reason, 240), status: 'active' });
  return { success: true };
}
async function deleteCircle(base44, user, payload) {
  await requireOwner(base44, payload.circleId, user.id);
  await base44.asServiceRole.entities.Circle.update(payload.circleId, { deleted_at: nowIso(), member_count: 0 });
  await base44.asServiceRole.entities.CircleMember.updateMany({ circle_id: payload.circleId, status: 'active' }, { $set: { status: 'removed' } });
  await base44.asServiceRole.entities.CircleInvite.updateMany({ circle_id: payload.circleId, status: 'pending' }, { $set: { status: 'revoked' } });
  await base44.asServiceRole.entities.CircleJoinRequest.updateMany({ circle_id: payload.circleId, status: 'pending' }, { $set: { status: 'declined' } });
  return { success: true };
}
async function requestJoin(base44, user, payload) {
  requireUsername(user);
  const circle = await getCircle(base44, payload.circleId);
  if (circle.privacy !== 'public') throw new Error('This circle is private.');
  const members = await activeMembers(base44, circle.id);
  if (members.length >= MAX_MEMBERS) throw new Error('Circle Full.');
  if (members.some(m => m.user_id === user.id)) return { success: true };
  const existing = await base44.asServiceRole.entities.CircleJoinRequest.filter({ circle_id: circle.id, user_id: user.id, status: 'pending' }, '-created_date', 1);
  if (!existing[0]) await base44.asServiceRole.entities.CircleJoinRequest.create({ circle_id: circle.id, user_id: user.id, display_name: displayName(user), username: usernameFor(user), status: 'pending' });
  return { success: true };
}
async function reviewJoinRequest(base44, user, payload) {
  await requireOwner(base44, payload.circleId, user.id);
  const request = await base44.asServiceRole.entities.CircleJoinRequest.get(payload.requestId);
  if (!request || request.circle_id !== payload.circleId || request.status !== 'pending') throw new Error('Request not found.');
  if (payload.decision === 'approve') {
    const members = await activeMembers(base44, payload.circleId);
    if (members.length >= MAX_MEMBERS) throw new Error('Circle Full.');
    if (!members.some(m => m.user_id === request.user_id)) {
      await base44.asServiceRole.entities.CircleMember.create({ circle_id: payload.circleId, user_id: request.user_id, display_name: request.display_name, username: request.username, role: 'member', status: 'active', joined_at: nowIso() });
      await ensureSharingPreference(base44, payload.circleId, request.user_id);
      await base44.asServiceRole.entities.CircleActivity.create({ circle_id: payload.circleId, actor_user_id: request.user_id, actor_name: request.display_name, actor_username: request.username, type: 'member_joined', status: 'completed', completed_at: nowIso(), visibility: 'everyone', allow_reactions: false, allow_messages: false });
    }
    await base44.asServiceRole.entities.CircleJoinRequest.update(request.id, { status: 'approved' });
    await refreshCount(base44, payload.circleId);
  } else {
    await base44.asServiceRole.entities.CircleJoinRequest.update(request.id, { status: 'declined' });
  }
  return { success: true };
}

async function updateSharingPreference(base44, user, payload) {
  await requireMember(base44, payload.circleId, user.id);
  const pref = await ensureSharingPreference(base44, payload.circleId, user.id);
  const members = await activeMembers(base44, payload.circleId);
  const memberIds = new Set(members.map(m => m.user_id));
  const cleanSelected = (arr) => Array.isArray(arr) ? arr.filter(id => memberIds.has(id) && id !== user.id).slice(0, MAX_MEMBERS) : [];
  const updates = {
    started_visibility: ['everyone', 'selected', 'nobody'].includes(payload.started_visibility) ? payload.started_visibility : pref.started_visibility,
    completed_visibility: ['everyone', 'selected', 'nobody'].includes(payload.completed_visibility) ? payload.completed_visibility : pref.completed_visibility,
    started_selected_user_ids: cleanSelected(payload.started_selected_user_ids),
    completed_selected_user_ids: cleanSelected(payload.completed_selected_user_ids),
    allow_reactions: payload.allow_reactions !== false,
    allow_messages: payload.allow_messages !== false,
  };
  await base44.asServiceRole.entities.CircleSharingPreference.update(pref.id, updates);
  return { ...pref, ...updates };
}
function activityPayload(user, payload, pref, type, circleId) {
  const completed = type === 'lockin_completed';
  const visibility = completed ? pref.completed_visibility : pref.started_visibility;
  const selected = completed ? pref.completed_selected_user_ids : pref.started_selected_user_ids;
  return {
    circle_id: circleId,
    actor_user_id: user.id,
    actor_name: displayName(user),
    actor_username: usernameFor(user),
    type,
    template_name: cleanText(payload.template_name || payload.category || 'Lockin', 60),
    focus: cleanText(payload.focus, 100),
    duration_minutes: Number(payload.duration_minutes || 0),
    started_at: cleanText(payload.started_at, 40) || nowIso(),
    completed_at: completed ? nowIso() : undefined,
    unlocks_at: cleanText(payload.unlocks_at, 40),
    status: completed ? 'completed' : 'active',
    lock_session_key: cleanText(payload.lock_session_key || payload.lockId, 120),
    visibility: visibility === 'selected' ? 'selected' : 'everyone',
    selected_user_ids: visibility === 'selected' ? (selected || []) : [],
    allow_reactions: pref.allow_reactions !== false,
    allow_messages: pref.allow_messages !== false,
    shared_lockin_id: cleanText(payload.shared_lockin_id, 120),
  };
}
async function shareLockin(base44, user, payload, type) {
  requireUsername(user);
  if (type === 'lockin_completed' && payload.goal_outcome && payload.goal_outcome !== 'yes') return { shared: 0 };
  const memberships = await base44.asServiceRole.entities.CircleMember.filter({ user_id: user.id, status: 'active' }, '-created_date', 100);
  let shared = 0;
  for (const membership of memberships) {
    const pref = await ensureSharingPreference(base44, membership.circle_id, user.id);
    const visibility = type === 'lockin_completed' ? pref.completed_visibility : pref.started_visibility;
    if (visibility === 'nobody') continue;
    const key = cleanText(payload.lock_session_key || payload.lockId, 120);
    if (key) {
      const existing = await base44.asServiceRole.entities.CircleActivity.filter({ circle_id: membership.circle_id, actor_user_id: user.id, type, lock_session_key: key }, '-created_date', 1);
      if (existing[0]) continue;
    }
    await base44.asServiceRole.entities.CircleActivity.create(activityPayload(user, payload, pref, type, membership.circle_id));
    shared++;
  }
  return { shared };
}
async function shareLockinStarted(base44, user, payload) { return await shareLockin(base44, user, payload, 'lockin_started'); }
async function shareLockinCompleted(base44, user, payload) {
  const result = await shareLockin(base44, user, payload, 'lockin_completed');
  const memberships = await base44.asServiceRole.entities.CircleMember.filter({ user_id: user.id, status: 'active' }, '-created_date', 100);
  const key = cleanText(payload.lock_session_key || payload.lockId, 120);
  if (key) {
    for (const membership of memberships) {
      const started = await base44.asServiceRole.entities.CircleActivity.filter({ circle_id: membership.circle_id, actor_user_id: user.id, type: 'lockin_started', lock_session_key: key, status: 'active' }, '-created_date', 5);
      await Promise.all(started.map(a => base44.asServiceRole.entities.CircleActivity.update(a.id, { status: 'completed' })));
    }
  }
  return result;
}
async function toggleReaction(base44, user, payload) {
  const activity = await base44.asServiceRole.entities.CircleActivity.get(payload.activityId);
  if (!activity || !POSITIVE_REACTIONS.includes(payload.emoji)) throw new Error('Reaction unavailable.');
  await requireMember(base44, activity.circle_id, user.id);
  if (!activity.allow_reactions || !['lockin_started', 'lockin_completed'].includes(activity.type)) throw new Error('Reactions are off for this Lockin.');
  const existing = await base44.asServiceRole.entities.CircleReaction.filter({ activity_id: activity.id, user_id: user.id, emoji: payload.emoji }, '-created_date', 1);
  if (existing[0]) await base44.asServiceRole.entities.CircleReaction.delete(existing[0].id);
  else await base44.asServiceRole.entities.CircleReaction.create({ circle_id: activity.circle_id, activity_id: activity.id, user_id: user.id, username: usernameFor(user), emoji: payload.emoji });
  return { activity: await serializeActivity(base44, activity, user.id) };
}
async function addEncouragement(base44, user, payload) {
  const activity = await base44.asServiceRole.entities.CircleActivity.get(payload.activityId);
  if (!activity) throw new Error('Activity not found.');
  await requireMember(base44, activity.circle_id, user.id);
  if (!activity.allow_messages || !['lockin_started', 'lockin_completed'].includes(activity.type)) throw new Error('Encouragement is off for this Lockin.');
  const message = cleanText(payload.message, 100);
  if (!message) throw new Error('Message is required.');
  if (isOffensive(message)) throw new Error('Keep encouragement positive.');
  const existing = await base44.asServiceRole.entities.CircleEncouragement.filter({ activity_id: activity.id, user_id: user.id, status: 'active' }, '-created_date', 1);
  if (existing[0]) await base44.asServiceRole.entities.CircleEncouragement.update(existing[0].id, { message });
  else await base44.asServiceRole.entities.CircleEncouragement.create({ circle_id: activity.circle_id, activity_id: activity.id, user_id: user.id, display_name: displayName(user), username: usernameFor(user), message, status: 'active' });
  return { activity: await serializeActivity(base44, activity, user.id) };
}
async function deleteEncouragement(base44, user, payload) {
  const item = await base44.asServiceRole.entities.CircleEncouragement.get(payload.messageId);
  if (!item || item.user_id !== user.id) throw new Error('Message not found.');
  await base44.asServiceRole.entities.CircleEncouragement.update(item.id, { status: 'deleted' });
  return { success: true };
}
async function reportEncouragement(base44, user, payload) {
  const item = await base44.asServiceRole.entities.CircleEncouragement.get(payload.messageId);
  if (!item) throw new Error('Message not found.');
  await requireMember(base44, item.circle_id, user.id);
  await base44.asServiceRole.entities.CircleModerationAction.create({ circle_id: item.circle_id, actor_user_id: user.id, target_user_id: item.user_id, action: 'report', reason: 'Reported encouragement message', status: 'active' });
  await base44.asServiceRole.entities.CircleEncouragement.update(item.id, { status: 'reported' });
  return { success: true };
}

const LOCKIN_TYPES = ['Homework', 'Work', 'Gym', 'Sleep', 'Custom'];
const REMINDER_MESSAGES = ['Lock in bro 💪', 'Homework time 📚', 'You got this', 'Gym?', 'Ready when you are', "Let's get it", "I'm starting mine too"];

function hhmm(date) { return new Date(date).toTimeString().slice(0, 5); }
async function ensureAccountabilityPreference(base44, userId) {
  const existing = (await base44.asServiceRole.entities.AccountabilityPreference.filter({ user_id: userId }, '-created_date', 1))[0];
  if (existing) return existing;
  return await base44.asServiceRole.entities.AccountabilityPreference.create({
    user_id: userId,
    reminder_mode: 'nobody',
    allowed_user_ids: [],
    allowed_circle_ids: [],
    category_rules: [],
    shared_invite_mode: 'all_circle_members',
    shared_invite_allowed_user_ids: [],
    show_joined_status: true,
    show_started_status: true,
    show_completed_status: true,
    allow_late_join_requests: true,
    muted_user_ids: [],
    notifications: { lockin_invite: true, invite_accepted: true, starting_soon: true, started: true, reminder: true, encouragement: true, completed: true }
  });
}
async function getSharedParticipants(base44, sharedLockinId) {
  return await base44.asServiceRole.entities.SharedLockinParticipant.filter({ shared_lockin_id: sharedLockinId }, 'created_date', 20);
}
async function serializeSharedLockin(base44, item, currentUserId) {
  const participants = await getSharedParticipants(base44, item.id);
  const pulses = await base44.asServiceRole.entities.SharedLockinPulse.filter({ shared_lockin_id: item.id }, '-created_date', 30).catch(() => []);
  const now = new Date();
  const isActiveNow = new Date(item.start_at) <= now && new Date(item.end_at) > now;
  return { ...item, participants, pulses, is_active_now: isActiveNow, current_participant: participants.find(p => p.user_id === currentUserId) || null };
}
function dateKey(date) { return date.toISOString().slice(0, 10); }
function rangeFor(period, startDate, endDate) {
  const now = new Date();
  if (period === 'this_month') return { start: new Date(now.getFullYear(), now.getMonth(), 1), end: new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999) };
  if (period === 'custom') return { start: new Date(`${startDate}T00:00:00`), end: new Date(`${endDate}T23:59:59`) };
  const start = new Date(now); start.setHours(0, 0, 0, 0); start.setDate(now.getDate() - ((now.getDay() + 6) % 7));
  const end = new Date(start); end.setDate(start.getDate() + 6); end.setHours(23, 59, 59, 999);
  return { start, end };
}
async function ensureGoalPreference(base44, circleId, userId) {
  const existing = (await base44.asServiceRole.entities.CircleGoalPreference.filter({ circle_id: circleId, user_id: userId }, '-created_date', 1))[0];
  if (existing) return existing;
  return await base44.asServiceRole.entities.CircleGoalPreference.create({ circle_id: circleId, user_id: userId, show_contributions: true });
}
function goalMatches(goal, activity) {
  if (goal.goal_type === 'total_completed') return true;
  if (goal.goal_type === 'shared_completed') return !!activity.shared_lockin_id;
  const category = goal.goal_type === 'Custom' ? cleanText(goal.custom_category, 60) : goal.goal_type;
  return String(activity.template_name || '').toLowerCase().includes(String(category || '').toLowerCase());
}
async function serializeCircleGoal(base44, goal) {
  if (!goal) return null;
  const activities = await base44.asServiceRole.entities.CircleActivity.filter({ circle_id: goal.circle_id, type: 'lockin_completed' }, '-created_date', 500);
  const start = new Date(`${goal.start_date}T00:00:00`);
  const end = new Date(`${goal.end_date}T23:59:59`);
  const matching = activities.filter(activity => {
    const when = new Date(activity.completed_at || activity.created_date || 0);
    return activity.status === 'completed' && when >= start && when <= end && goalMatches(goal, activity);
  });
  const currentAmount = matching.length;
  if (goal.status === 'active' && currentAmount >= Number(goal.target_amount || 1)) {
    await base44.asServiceRole.entities.CircleGoal.update(goal.id, { status: 'completed', completed_at: nowIso() });
    goal = { ...goal, status: 'completed', completed_at: nowIso() };
  }
  return { ...goal, current_amount: currentAmount };
}
async function activeCircleGoal(base44, circleId) {
  const goals = await base44.asServiceRole.entities.CircleGoal.filter({ circle_id: circleId, status: 'active' }, '-created_date', 5).catch(() => []);
  return goals[0] ? await serializeCircleGoal(base44, goals[0]) : null;
}
async function inviteLockinContext(base44, user, payload) {
  requireUsername(user);
  const memberships = await base44.asServiceRole.entities.CircleMember.filter({ user_id: user.id, status: 'active' }, '-created_date', 100);
  const circles = [];
  for (const membership of memberships) {
    const circle = await base44.asServiceRole.entities.Circle.get(membership.circle_id).catch(() => null);
    if (!circle || circle.deleted_at) continue;
    if (payload.circleId && circle.id !== payload.circleId) continue;
    circles.push({ ...circle, members: (await activeMembers(base44, circle.id)).filter(m => m.user_id !== user.id) });
  }
  const accountability = await ensureAccountabilityPreference(base44, user.id);
  return { circles, username: usernameFor(user), display_name: displayName(user), accountability, reminderMessages: REMINDER_MESSAGES };
}
async function createSharedLockin(base44, user, payload) {
  requireUsername(user);
  const circleId = cleanText(payload.circleId, 80);
  const member = await requireMember(base44, circleId, user.id);
  const members = await activeMembers(base44, circleId);
  const selected = [...new Set((payload.selectedMemberIds || []).map(id => cleanText(id, 80)).filter(Boolean))].filter(id => id !== user.id).slice(0, MAX_MEMBERS - 1);
  if (!selected.length) throw new Error('Choose at least one Circle member.');
  const memberMap = new Map(members.map(m => [m.user_id, m]));
  for (const userId of selected) {
    if (!memberMap.has(userId)) throw new Error('Invite only active Circle members.');
    const targetPref = await ensureAccountabilityPreference(base44, userId);
    if (targetPref.shared_invite_mode === 'off') throw new Error(`${memberMap.get(userId).display_name || 'A member'} is not accepting Shared Lockin invites.`);
    if (targetPref.shared_invite_mode === 'selected_members' && !(targetPref.shared_invite_allowed_user_ids || []).includes(user.id)) throw new Error(`${memberMap.get(userId).display_name || 'A member'} has not allowed Shared Lockin invites from you.`);
  }
  const start = new Date(payload.startAt);
  const end = new Date(payload.endAt);
  if (!start.getTime() || !end.getTime() || end <= start) throw new Error('Choose a valid start and end time.');
  const selectedDays = Array.isArray(payload.selectedDays) ? [...new Set(payload.selectedDays.map(Number).filter(day => day >= 0 && day <= 6))] : [start.getDay()];
  if (!selectedDays.length) throw new Error('Choose at least one day.');
  const dateOption = ['today', 'tomorrow', 'weekdays', 'weekend', 'specific'].includes(payload.dateOption) ? payload.dateOption : 'today';
  const repeatMode = ['one_time', 'every_week'].includes(payload.repeatMode) ? payload.repeatMode : 'one_time';
  const timeMode = ['end_time', 'duration'].includes(payload.timeMode) ? payload.timeMode : 'duration';
  const category = LOCKIN_TYPES.includes(payload.category) ? payload.category : 'Custom';
  const title = cleanText(payload.title || `${category} Lockin`, 80);
  const shared = await base44.asServiceRole.entities.SharedLockin.create({
    circle_id: circleId,
    title,
    category,
    focus: cleanText(payload.focus, 120),
    date: cleanText(payload.date, 10) || start.toISOString().slice(0, 10),
    date_option: dateOption,
    selected_days: selectedDays,
    repeat_mode: repeatMode,
    time_mode: timeMode,
    start_at: start.toISOString(),
    end_at: end.toISOString(),
    duration_minutes: Math.round((end - start) / 60000),
    creator_id: user.id,
    creator_username: usernameFor(user),
    creator_name: displayName(user),
    late_joining: payload.lateJoining === true,
    status: 'scheduled',
    visibility: 'selected',
    allow_reactions: true,
    allow_messages: true
  });
  await base44.asServiceRole.entities.SharedLockinParticipant.create({ shared_lockin_id: shared.id, circle_id: circleId, user_id: user.id, username: usernameFor(user), display_name: displayName(user), invited_by_id: user.id, status: 'joined', joined_at: nowIso(), apps: [], allow_reminders: false });
  for (const userId of selected) {
    const m = memberMap.get(userId);
    await base44.asServiceRole.entities.SharedLockinParticipant.create({ shared_lockin_id: shared.id, circle_id: circleId, user_id: userId, username: m.username, display_name: m.display_name, invited_by_id: user.id, status: 'invited', apps: [], allow_reminders: false });
  }
  return { sharedLockin: await serializeSharedLockin(base44, shared, user.id) };
}
async function getSharedLockin(base44, user, payload) {
  requireUsername(user);
  const shared = await base44.asServiceRole.entities.SharedLockin.get(payload.sharedLockinId);
  if (!shared) throw new Error('Shared Lockin not found.');
  await requireMember(base44, shared.circle_id, user.id);
  const circle = await getCircle(base44, shared.circle_id);
  const data = await serializeSharedLockin(base44, shared, user.id);
  const reminders = await base44.asServiceRole.entities.AccountabilityReminder.filter({ shared_lockin_id: shared.id, to_user_id: user.id, status: 'sent' }, '-created_date', 20);
  const accountability = await ensureAccountabilityPreference(base44, user.id);
  return { sharedLockin: data, circle: await circleSummary(base44, circle), reminders, accountability, reminderMessages: REMINDER_MESSAGES };
}
async function respondSharedLockinInvite(base44, user, payload) {
  requireUsername(user);
  const participant = await base44.asServiceRole.entities.SharedLockinParticipant.get(payload.participantId);
  if (!participant || participant.user_id !== user.id) throw new Error('Invite not found.');
  const shared = await base44.asServiceRole.entities.SharedLockin.get(participant.shared_lockin_id);
  if (!shared) throw new Error('Shared Lockin not found.');
  if (payload.decision === 'decline') {
    await base44.asServiceRole.entities.SharedLockinParticipant.update(participant.id, { status: 'declined', declined_at: nowIso() });
    return { success: true };
  }
  const apps = Array.isArray(payload.apps) ? payload.apps.slice(0, 30).map(a => ({ name: cleanText(a.name, 80), domain: cleanText(a.domain, 120) })).filter(a => a.name) : [];
  if (!apps.length) throw new Error('Choose the apps you want to lock.');
  const start = new Date(shared.start_at);
  const end = new Date(shared.end_at);
  const schedule = await base44.entities.RecurringSchedule.create({
    label: shared.title,
    goal_name: cleanText(payload.privateFocus, 120) || shared.focus || shared.title,
    goal_emoji: shared.category === 'Homework' ? '📚' : shared.category === 'Gym' ? '💪' : shared.category === 'Sleep' ? '🌙' : shared.category === 'Work' ? '💼' : '✨',
    icon_style: 'colorful',
    apps,
    days_of_week: shared.repeat_mode === 'every_week' && Array.isArray(shared.selected_days) && shared.selected_days.length ? shared.selected_days : [start.getDay()],
    start_time: hhmm(start),
    end_time: hhmm(end),
    duration_minutes: shared.duration_minutes,
    reminder_enabled: true,
    is_active: true,
    shared_lockin_id: shared.id,
    shared_lockin_date: shared.date,
    shared_circle_id: shared.circle_id
  });
  await base44.asServiceRole.entities.SharedLockinParticipant.update(participant.id, { status: 'joined', private_focus: cleanText(payload.privateFocus, 120), apps, joined_at: nowIso(), joined_schedule_id: schedule.id, allow_reminders: payload.allowReminders === true });
  return { success: true, scheduleId: schedule.id };
}
async function updateAccountabilityPreference(base44, user, payload) {
  const pref = await ensureAccountabilityPreference(base44, user.id);
  const memberships = await base44.asServiceRole.entities.CircleMember.filter({ user_id: user.id, status: 'active' }, '-created_date', 100);
  const circleIds = new Set(memberships.map(m => m.circle_id));
  const circleMembers = [];
  for (const membership of memberships) circleMembers.push(...await activeMembers(base44, membership.circle_id));
  const allowedUsers = new Set(circleMembers.filter(m => m.user_id !== user.id).map(m => m.user_id));
  const updates = {
    reminder_mode: ['nobody', 'selected_people', 'selected_circles'].includes(payload.reminder_mode) ? payload.reminder_mode : pref.reminder_mode,
    allowed_user_ids: Array.isArray(payload.allowed_user_ids) ? payload.allowed_user_ids.filter(id => allowedUsers.has(id)).slice(0, 50) : pref.allowed_user_ids,
    allowed_circle_ids: Array.isArray(payload.allowed_circle_ids) ? payload.allowed_circle_ids.filter(id => circleIds.has(id)).slice(0, 20) : pref.allowed_circle_ids,
    shared_invite_mode: ['all_circle_members', 'selected_members', 'off'].includes(payload.shared_invite_mode) ? payload.shared_invite_mode : pref.shared_invite_mode,
    shared_invite_allowed_user_ids: Array.isArray(payload.shared_invite_allowed_user_ids) ? payload.shared_invite_allowed_user_ids.filter(id => allowedUsers.has(id)).slice(0, 50) : pref.shared_invite_allowed_user_ids,
    show_joined_status: payload.show_joined_status !== false,
    show_started_status: payload.show_started_status !== false,
    show_completed_status: payload.show_completed_status !== false,
    allow_late_join_requests: payload.allow_late_join_requests !== false,
    notifications: payload.notifications || pref.notifications || {},
    muted_user_ids: Array.isArray(payload.muted_user_ids) ? payload.muted_user_ids.filter(id => allowedUsers.has(id)).slice(0, 50) : pref.muted_user_ids
  };
  await base44.asServiceRole.entities.AccountabilityPreference.update(pref.id, updates);
  return { ...pref, ...updates };
}
function canRemind(pref, fromUserId, circleId, category) {
  if ((pref.muted_user_ids || []).includes(fromUserId)) return false;
  if (pref.reminder_mode === 'selected_people' && !(pref.allowed_user_ids || []).includes(fromUserId)) return false;
  if (pref.reminder_mode === 'selected_circles' && !(pref.allowed_circle_ids || []).includes(circleId)) return false;
  if (pref.reminder_mode === 'nobody') return false;
  const rule = (pref.category_rules || []).find(r => r.user_id === fromUserId);
  return !rule || !Array.isArray(rule.categories) || rule.categories.length === 0 || rule.categories.includes(category);
}
async function sendAccountabilityReminder(base44, user, payload) {
  requireUsername(user);
  const shared = await base44.asServiceRole.entities.SharedLockin.get(payload.sharedLockinId);
  if (!shared) throw new Error('Shared Lockin not found.');
  await requireMember(base44, shared.circle_id, user.id);
  const target = await base44.asServiceRole.entities.SharedLockinParticipant.get(payload.participantId);
  if (!target || target.shared_lockin_id !== shared.id || target.user_id === user.id) throw new Error('Choose a participant.');
  const pref = await ensureAccountabilityPreference(base44, target.user_id);
  if (!canRemind(pref, user.id, shared.circle_id, shared.category)) throw new Error('This member has not allowed reminders from you.');
  const existing = await base44.asServiceRole.entities.AccountabilityReminder.filter({ shared_lockin_id: shared.id, from_user_id: user.id, to_user_id: target.user_id, status: 'sent' }, '-created_date', 1);
  if (existing[0]) throw new Error('You already sent one reminder for this Lockin.');
  const total = await base44.asServiceRole.entities.AccountabilityReminder.filter({ shared_lockin_id: shared.id, to_user_id: target.user_id, status: 'sent' }, '-created_date', 10);
  if (total.length >= 3) throw new Error('Reminder limit reached for this Lockin.');
  const message = cleanText(payload.message, 80);
  if (!message || isOffensive(message)) throw new Error('Keep reminders short and positive.');
  await base44.asServiceRole.entities.AccountabilityReminder.create({ shared_lockin_id: shared.id, circle_id: shared.circle_id, from_user_id: user.id, from_username: usernameFor(user), from_name: displayName(user), to_user_id: target.user_id, message, type: 'reminder', status: 'sent' });
  return { success: true };
}
async function askForEncouragement(base44, user, payload) {
  requireUsername(user);
  const shared = await base44.asServiceRole.entities.SharedLockin.get(payload.sharedLockinId);
  if (!shared) throw new Error('Shared Lockin not found.');
  await requireMember(base44, shared.circle_id, user.id);
  const participants = await getSharedParticipants(base44, shared.id);
  const pref = await ensureAccountabilityPreference(base44, user.id);
  const eligible = participants.filter(p => p.user_id !== user.id && canRemind(pref, p.user_id, shared.circle_id, shared.category)).slice(0, 5);
  if (!eligible.length) throw new Error('Choose who can help keep you on track first.');
  for (const participant of eligible) {
    await base44.asServiceRole.entities.AccountabilityReminder.create({ shared_lockin_id: shared.id, circle_id: shared.circle_id, from_user_id: user.id, from_username: usernameFor(user), from_name: displayName(user), to_user_id: participant.user_id, message: `@${usernameFor(user)} could use a little encouragement for ${shared.category}.`, type: 'encouragement_request', status: 'sent' });
  }
  return { sent: eligible.length };
}
async function updateSharedParticipantStatus(base44, user, payload) {
  const shared = await base44.asServiceRole.entities.SharedLockin.get(payload.sharedLockinId);
  if (!shared) throw new Error('Shared Lockin not found.');
  await requireMember(base44, shared.circle_id, user.id);
  const participant = (await getSharedParticipants(base44, shared.id)).find(p => p.user_id === user.id);
  if (!participant || participant.status === 'invited' || participant.status === 'declined') throw new Error('Join this Lockin before updating status.');
  const status = ['joined', 'ready', 'locked_in', 'completed'].includes(payload.status) ? payload.status : 'joined';
  const updates = { status, last_status_at: nowIso() };
  if (status === 'locked_in') updates.started_at = nowIso();
  if (status === 'completed') updates.completed_at = nowIso();
  await base44.asServiceRole.entities.SharedLockinParticipant.update(participant.id, updates);
  return { sharedLockin: await serializeSharedLockin(base44, shared, user.id) };
}
async function markSharedLockinStarted(base44, user, payload) {
  const shared = await base44.asServiceRole.entities.SharedLockin.get(payload.sharedLockinId);
  if (!shared) throw new Error('Shared Lockin not found.');
  await requireMember(base44, shared.circle_id, user.id);
  const participant = (await getSharedParticipants(base44, shared.id)).find(p => p.user_id === user.id);
  if (!participant || !['joined', 'ready', 'locked_in'].includes(participant.status)) throw new Error('Join this Lockin before starting.');
  await base44.asServiceRole.entities.SharedLockinParticipant.update(participant.id, { status: 'locked_in', started_at: nowIso(), last_status_at: nowIso() });
  if (shared.status === 'scheduled') await base44.asServiceRole.entities.SharedLockin.update(shared.id, { status: 'active' });
  return { success: true };
}
async function updateSharedParticipantApps(base44, user, payload) {
  const shared = await base44.asServiceRole.entities.SharedLockin.get(payload.sharedLockinId);
  if (!shared) throw new Error('Shared Lockin not found.');
  await requireMember(base44, shared.circle_id, user.id);
  const participant = (await getSharedParticipants(base44, shared.id)).find(p => p.user_id === user.id);
  if (!participant || !['joined', 'ready', 'locked_in', 'completed'].includes(participant.status)) throw new Error('Join this Lockin before editing apps.');
  const apps = Array.isArray(payload.apps) ? payload.apps.slice(0, 30).map(a => ({ name: cleanText(a.name, 80), domain: cleanText(a.domain, 120) })).filter(a => a.name) : [];
  if (!apps.length) throw new Error('Choose the apps you want to lock.');
  const privateFocus = cleanText(payload.privateFocus, 120) || participant.private_focus || shared.focus || shared.title;
  let scheduleId = participant.joined_schedule_id;
  const scheduleData = {
    label: shared.title,
    goal_name: privateFocus,
    goal_emoji: shared.category === 'Homework' ? '📚' : shared.category === 'Gym' ? '💪' : shared.category === 'Sleep' ? '🌙' : shared.category === 'Work' ? '💼' : '✨',
    icon_style: 'colorful',
    apps,
    days_of_week: shared.repeat_mode === 'every_week' && Array.isArray(shared.selected_days) && shared.selected_days.length ? shared.selected_days : [new Date(shared.start_at).getDay()],
    start_time: hhmm(shared.start_at),
    end_time: hhmm(shared.end_at),
    duration_minutes: shared.duration_minutes,
    reminder_enabled: true,
    is_active: true,
    shared_lockin_id: shared.id,
    shared_lockin_date: shared.date,
    shared_circle_id: shared.circle_id
  };
  if (scheduleId) await base44.asServiceRole.entities.RecurringSchedule.update(scheduleId, scheduleData).catch(() => { scheduleId = ''; });
  if (!scheduleId) {
    const schedule = await base44.entities.RecurringSchedule.create(scheduleData);
    scheduleId = schedule.id;
  }
  await base44.asServiceRole.entities.SharedLockinParticipant.update(participant.id, { private_focus: privateFocus, apps, joined_schedule_id: scheduleId, last_status_at: nowIso() });
  return { sharedLockin: await serializeSharedLockin(base44, shared, user.id) };
}
async function startSharedLockinEarly(base44, user, payload) {
  const shared = await base44.asServiceRole.entities.SharedLockin.get(payload.sharedLockinId);
  if (!shared || shared.creator_id !== user.id) throw new Error('Only the creator can start this early.');
  if (shared.allow_early_start === false) throw new Error('Early starts are off for this Lockin.');
  const start = new Date();
  const end = new Date(start.getTime() + Number(shared.duration_minutes || 60) * 60000);
  await base44.asServiceRole.entities.SharedLockin.update(shared.id, { start_at: start.toISOString(), end_at: end.toISOString(), date: dateKey(start), status: 'active', started_early_at: start.toISOString() });
  return { sharedLockin: await serializeSharedLockin(base44, { ...shared, start_at: start.toISOString(), end_at: end.toISOString(), date: dateKey(start), status: 'active' }, user.id) };
}
async function completeSharedLockinParticipant(base44, user, payload) {
  const shared = await base44.asServiceRole.entities.SharedLockin.get(payload.sharedLockinId);
  if (!shared) return { success: true };
  await requireMember(base44, shared.circle_id, user.id);
  const participant = (await getSharedParticipants(base44, shared.id)).find(p => p.user_id === user.id);
  if (!participant || participant.status === 'completed') return { success: true };
  await base44.asServiceRole.entities.SharedLockinParticipant.update(participant.id, { status: 'completed', completed_at: nowIso(), last_status_at: nowIso() });
  const pref = await ensureSharingPreference(base44, shared.circle_id, user.id);
  if (pref.completed_visibility !== 'nobody') {
    const key = cleanText(payload.lock_session_key || shared.id, 120);
    const existing = await base44.asServiceRole.entities.CircleActivity.filter({ circle_id: shared.circle_id, actor_user_id: user.id, type: 'lockin_completed', lock_session_key: key }, '-created_date', 1);
    if (!existing[0]) await base44.asServiceRole.entities.CircleActivity.create({ circle_id: shared.circle_id, actor_user_id: user.id, actor_name: displayName(user), actor_username: usernameFor(user), type: 'lockin_completed', template_name: shared.category, focus: cleanText(payload.focus || shared.focus, 100), duration_minutes: shared.duration_minutes, started_at: shared.start_at, completed_at: nowIso(), unlocks_at: shared.end_at, status: 'completed', lock_session_key: key, shared_lockin_id: shared.id, visibility: pref.completed_visibility === 'selected' ? 'selected' : 'everyone', selected_user_ids: pref.completed_visibility === 'selected' ? (pref.completed_selected_user_ids || []) : [], allow_reactions: true, allow_messages: true });
  }
  const joined = (await getSharedParticipants(base44, shared.id)).filter(p => ['joined', 'ready', 'locked_in', 'completed'].includes(p.status));
  if (joined.length && joined.every(p => p.status === 'completed')) await base44.asServiceRole.entities.SharedLockin.update(shared.id, { status: 'completed' });
  return { success: true };
}
async function sendSharedPulse(base44, user, payload) {
  const shared = await base44.asServiceRole.entities.SharedLockin.get(payload.sharedLockinId);
  if (!shared) throw new Error('Shared Lockin not found.');
  await requireMember(base44, shared.circle_id, user.id);
  const participant = (await getSharedParticipants(base44, shared.id)).find(p => p.user_id === user.id && ['joined', 'ready', 'locked_in', 'completed'].includes(p.status));
  if (!participant) throw new Error('Join this Lockin first.');
  const recent = await base44.asServiceRole.entities.SharedLockinPulse.filter({ shared_lockin_id: shared.id, user_id: user.id }, '-created_date', 10);
  if (recent.length >= 5) throw new Error('Encouragement is limited during sessions.');
  const type = payload.type === 'encouragement' ? 'encouragement' : 'reaction';
  const emoji = SESSION_REACTIONS.includes(payload.emoji) ? payload.emoji : undefined;
  const message = SESSION_MESSAGES.includes(payload.message) ? payload.message : undefined;
  if (type === 'reaction' && !emoji) throw new Error('Choose a reaction.');
  if (type === 'encouragement' && !message) throw new Error('Choose an encouragement.');
  await base44.asServiceRole.entities.SharedLockinPulse.create({ shared_lockin_id: shared.id, circle_id: shared.circle_id, user_id: user.id, username: usernameFor(user), display_name: displayName(user), type, emoji, message });
  return { sharedLockin: await serializeSharedLockin(base44, shared, user.id) };
}
async function rescheduleSharedLockin(base44, user, payload) {
  const shared = await base44.asServiceRole.entities.SharedLockin.get(payload.sharedLockinId);
  if (!shared || shared.creator_id !== user.id) throw new Error('Only the creator can reschedule this Lockin.');
  const start = new Date(payload.startAt);
  const end = new Date(payload.endAt);
  if (!start.getTime() || !end.getTime() || end <= start) throw new Error('Choose a valid new time.');
  const updates = { start_at: start.toISOString(), end_at: end.toISOString(), date: dateKey(start), duration_minutes: Math.round((end - start) / 60000), rescheduled_at: nowIso(), status: 'scheduled' };
  await base44.asServiceRole.entities.SharedLockin.update(shared.id, updates);
  const participants = await getSharedParticipants(base44, shared.id);
  for (const participant of participants) {
    if (!participant.joined_schedule_id) continue;
    await base44.asServiceRole.entities.RecurringSchedule.update(participant.joined_schedule_id, { start_time: hhmm(start), end_time: hhmm(end), duration_minutes: updates.duration_minutes, shared_lockin_date: updates.date }).catch(() => null);
  }
  return { sharedLockin: await serializeSharedLockin(base44, { ...shared, ...updates }, user.id) };
}
async function createCircleGoal(base44, user, payload) {
  await requireOwner(base44, payload.circleId, user.id);
  const period = ['this_week', 'this_month', 'custom'].includes(payload.period) ? payload.period : 'this_week';
  const range = rangeFor(period, payload.start_date, payload.end_date);
  const goalType = ['total_completed', 'shared_completed', 'Homework', 'Work', 'Gym', 'Sleep', 'Custom'].includes(payload.goal_type) ? payload.goal_type : 'total_completed';
  const target = Math.max(1, Math.min(999, Number(payload.target_amount || 1)));
  const existing = await base44.asServiceRole.entities.CircleGoal.filter({ circle_id: payload.circleId, status: 'active' }, '-created_date', 5).catch(() => []);
  await Promise.all(existing.map(goal => base44.asServiceRole.entities.CircleGoal.update(goal.id, { status: 'archived' })));
  const goal = await base44.asServiceRole.entities.CircleGoal.create({ circle_id: payload.circleId, title: cleanText(payload.title, 80), goal_type: goalType, custom_category: cleanText(payload.custom_category, 60), target_amount: target, period, start_date: dateKey(range.start), end_date: dateKey(range.end), owner_id: user.id, status: 'active' });
  return { activeGoal: await serializeCircleGoal(base44, goal) };
}
async function updateCircleGoalPrivacy(base44, user, payload) {
  await requireMember(base44, payload.circleId, user.id);
  const pref = await ensureGoalPreference(base44, payload.circleId, user.id);
  await base44.asServiceRole.entities.CircleGoalPreference.update(pref.id, { show_contributions: payload.show_contributions !== false });
  return { ...pref, show_contributions: payload.show_contributions !== false };
}
async function leaveSharedLockinSession(base44, user, payload) {
  const shared = await base44.asServiceRole.entities.SharedLockin.get(payload.sharedLockinId);
  if (!shared) throw new Error('Shared Lockin not found.');
  await requireMember(base44, shared.circle_id, user.id);
  const participant = (await getSharedParticipants(base44, shared.id)).find(p => p.user_id === user.id);
  if (!participant || participant.user_id === shared.creator_id) throw new Error('This session cannot be left here.');
  await base44.asServiceRole.entities.SharedLockinParticipant.update(participant.id, { status: 'declined', last_status_at: nowIso() });
  return { success: true };
}
async function inviteSharedParticipantAgain(base44, user, payload) {
  const participant = await base44.asServiceRole.entities.SharedLockinParticipant.get(payload.participantId);
  if (!participant) throw new Error('Participant not found.');
  const shared = await base44.asServiceRole.entities.SharedLockin.get(participant.shared_lockin_id);
  if (!shared || shared.creator_id !== user.id) throw new Error('Only the creator can invite again.');
  await base44.asServiceRole.entities.SharedLockinParticipant.update(participant.id, { status: 'invited', last_status_at: nowIso() });
  return { success: true };
}
async function removeSharedParticipant(base44, user, payload) {
  const participant = await base44.asServiceRole.entities.SharedLockinParticipant.get(payload.participantId);
  if (!participant) throw new Error('Participant not found.');
  const shared = await base44.asServiceRole.entities.SharedLockin.get(participant.shared_lockin_id);
  if (!shared || shared.creator_id !== user.id || participant.user_id === user.id) throw new Error('Only the creator can remove invited members from this session.');
  await base44.asServiceRole.entities.SharedLockinParticipant.update(participant.id, { status: 'declined', last_status_at: nowIso() });
  return { success: true };
}

const handlers = {
  checkUsernameAvailability,
  updateUsername,
  createCircle,
  listCircles,
  getCircleDetail,
  updateCircle,
  inviteUsername,
  searchInviteUsers,
  inviteUsers,
  createInviteLink,
  previewInvite,
  joinByCircleCode,
  acceptInvite,
  declineInvite,
  leaveCircle,
  removeMember,
  reportMember: (base44, user, payload) => moderationAction(base44, user, payload, 'report'),
  blockMember: (base44, user, payload) => moderationAction(base44, user, payload, 'block'),
  deleteCircle,
  requestJoin,
  reviewJoinRequest,
  updateSharingPreference,
  shareLockinStarted,
  shareLockinCompleted,
  toggleReaction,
  addEncouragement,
  deleteEncouragement,
  reportEncouragement,
  inviteLockinContext,
  createSharedLockin,
  getSharedLockin,
  respondSharedLockinInvite,
  updateSharedParticipantStatus,
  markSharedLockinStarted,
  updateSharedParticipantApps,
  startSharedLockinEarly,
  completeSharedLockinParticipant,
  sendSharedPulse,
  rescheduleSharedLockin,
  leaveSharedLockinSession,
  inviteSharedParticipantAgain,
  removeSharedParticipant,
  createCircleGoal,
  updateCircleGoalPrivacy,
  updateAccountabilityPreference,
  sendAccountabilityReminder,
  askForEncouragement,
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const action = body.action;
    if (!handlers[action]) return Response.json({ error: 'Unsupported circle action.' }, { status: 400 });
    if (action === 'checkUsernameAvailability') {
      const data = await checkUsernameAvailability(base44, null, body.payload || {});
      return Response.json(data);
    }
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const data = await handlers[action](base44, user, body.payload || {});
    return Response.json(data);
  } catch (error) {
    return Response.json({ error: error.message || 'Circle action failed.' }, { status: 500 });
  }
});